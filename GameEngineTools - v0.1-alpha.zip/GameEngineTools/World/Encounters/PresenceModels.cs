﻿// PresenceModels.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.World.Encounters
{
    using System;
    using System.Collections.Generic;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.World.Utils.Time;

    public readonly struct PresenceSegment
    {
        public readonly int CapacityHint;
        public readonly WDateTime End;
        public readonly IHuman Human;
        public readonly Guid PlaceId;
        public readonly WDateTime Start;

        public PresenceSegment(IHuman h, Guid placeId, WDateTime start, WDateTime end, int capacityHint = 12)
        {
            Human = h; PlaceId = placeId; Start = start; End = end; CapacityHint = capacityHint;
        }

        public bool Overlaps(WDateTime a, WDateTime b) => Start < b && End > a;
    }

    public readonly struct SceneBlock
    {
        public readonly int CapacityHint;
        public readonly WDateTime End;
        public readonly List<IHuman> Participants;
        public readonly Guid PlaceId;
        public readonly WDateTime Start;

        public SceneBlock(Guid placeId, WDateTime start, WDateTime end, int capacityHint, List<IHuman> participants)
        {
            PlaceId = placeId; Start = start; End = end; CapacityHint = capacityHint; Participants = participants;
        }

        public WTimeSpan Duration => End - Start;
        public int OccupantCount => Participants?.Count ?? 0;
    }
}
