﻿using System.Linq;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using GameEngineTools.Characters.CharacterModel.Behavior.Planning;
using GameEngineTools.World.Core.Time;
using GameEngineTools.World.Utils.Time;
using GameEngineTools.World.Encounters;
using GameEngineTools.Config;
using System.Collections.Concurrent;
using GameEngineTools.Characters.CharacterModel.Homo;
using Microsoft.Extensions.Options;
using GameEngineTools.Characters.CharacterModel.Events;

namespace GameEngineTools.Characters.CharacterModel.Behavior
{

    public sealed class BehaviorOrchestratorHostedService : BackgroundService
    {
        private readonly ILogger<BehaviorOrchestratorHostedService> _log;
        private readonly IClock _clock;
        private readonly EncounterService _encounters;
        private readonly BehaviorCandidateGenerator _gen;
        private readonly BehaviorEngine _engine;
        private readonly BehaviorCooldowns _cooldowns;
        private readonly IEnumerable<IBehaviorOption> _options;
        private readonly PlanEngine _plans;
        private IEnumerator<BehaviorContext>? _today;
        private WDateOnly? _loadedFor;
        private WDateTime _lastHomeo;

        private readonly BehaviorLoopOptions _loop;
        private readonly ConcurrentQueue<(IHuman a, IHuman b)> _asap = new();

        public BehaviorOrchestratorHostedService(
            ILogger<BehaviorOrchestratorHostedService> log,
            IOptions<BehaviorLoopOptions> loop,
            IEventBus bus,
            IClock clock,
            EncounterService encounters,
            BehaviorCandidateGenerator gen,
            BehaviorEngine engine,
            BehaviorCooldowns cooldowns,
            IEnumerable<IBehaviorOption> options,
            PlanEngine plans)
        {
            _log = log;
            _clock = clock;
            _lastHomeo = _clock.Now;
            _encounters = encounters;
            _gen = gen;
            _engine = engine;
            _cooldowns = cooldowns;
            _options = options;
            _plans = plans;
            _loop = loop.Value;
            WireEvents(bus);
        }

        protected override async Task ExecuteAsync(CancellationToken stop)
        {
            while (!stop.IsCancellationRequested)
            {
                var now = _clock.Now;
                var windowEnd = now + WTimeSpan.FromSeconds(_loop.EncounterLookaheadSeconds);
                var budget = _loop.BurstBudget;

                while (budget > 0 && _asap.TryDequeue(out var pair))
                {
                    TryEvaluate(pair.a, pair.b);
                    budget--;
                }

                var encounters = _encounters
                    .BuildEncountersForDay(now)
                    .Where(e => e.When >= now && e.When <= windowEnd)
                    .OrderBy(e => e.When)
                    .Take(Math.Max(0, budget))
                    .ToArray();

                foreach (var ctx in _gen.BuildContexts(encounters))
                {
                    if (!_plans.TryTickOrStart(ctx, (t, c) => Enact(t, c, ctx.When)))
                    {
                        _ = BehaviorRunner.RunOnce(_engine, ctx, _options, _cooldowns);
                    }
                }

                {
                    // TODO: Později přesunout do dedikované služby??
                    var dt = now - _lastHomeo;
                    if (dt > WTimeSpan.Zero)
                    {
                        var seen = new HashSet<Guid>();
                        foreach (var e in encounters)
                        {
                            if (seen.Add(e.A.DNA)) PsychologyHomeostasis.Tick(e.A, dt);
                            if (seen.Add(e.B.DNA)) PsychologyHomeostasis.Tick(e.B, dt);
                        }
                        _lastHomeo = now;
                    }
                }

                await Task.Delay(NextDelay(), stop);
            }
        }

        private bool Enact(BehaviorType type, BehaviorContext ctx, WDateTime when)
        {
            var opt = _options.FirstOrDefault(o => o.Type == type);
            if (opt is null) return false;
            if (_cooldowns.IsOnCooldown(ctx.Actor, ctx.Target, type, when)) return false;

            // Anti-spam: označ poslední kategorii a nastav kategoriální cooldown
            var cat = BehaviorToCategory(type);
            if (cat is not null)
            {
                if (_cooldowns.IsImmediateRepeat(ctx.Actor, ctx.Target, cat.Value, when)) return false;
                _cooldowns.MarkLastCategory(ctx.Actor, ctx.Target, cat.Value, WTimeSpan.FromMinutes(5), when);
                _cooldowns.BumpCategory(ctx.Actor, ctx.Target, cat.Value, WTimeSpan.FromMinutes(20), when);
            }

            opt.Apply(ctx);
            var effort = Engine.BehaviorScoring.EffortOf(type);
            var minutes = 3 + (int)Math.Round(12 * effort);
            _cooldowns.Bump(ctx.Actor, ctx.Target, type, WTimeSpan.FromMinutes(minutes), when);
            return true;
        }

        private static Relationships.InteractionType? BehaviorToCategory(BehaviorType t) => t switch
        {
            BehaviorType.FlirtLight or BehaviorType.FlirtBold => Relationships.InteractionType.Flirt,
            BehaviorType.ComplimentLight or BehaviorType.ReturnCompliment => Relationships.InteractionType.Compliment,
            BehaviorType.Apologize => Relationships.InteractionType.Apology,
            BehaviorType.Retort or BehaviorType.Confront => Relationships.InteractionType.Argument,
            BehaviorType.InitiateIntimacySoft or BehaviorType.InitiateIntimacyBold or BehaviorType.Kiss or BehaviorType.KissLight
                => Relationships.InteractionType.Touch,
            _ => null
        };

        private TimeSpan NextDelay()
        {
            if (!_loop.UsePoisson) return TimeSpan.FromSeconds(Math.Max(1, _loop.TickSeconds));
            var u = Math.Clamp(Random.Shared.NextDouble(), 1e-9, 1 - 1e-9);
            var lambda = Math.Max(0.001, _loop.BaseRatePerMinute / 60.0); // 1/s
            var deltaSec = -Math.Log(u) / lambda;
            return TimeSpan.FromSeconds(Math.Clamp(deltaSec, 2.0, 30.0));
        }

        private void WireEvents(IEventBus bus)
        {
            bus.Subscribe<EncounterCreatedEvent>(e => _asap.Enqueue((e.A, e.B)));
            bus.Subscribe<PresenceChangedEvent>(e => { if (e.NowSamePlace) _asap.Enqueue((e.Self, e.Other)); });
        }

        private void TryEvaluate(IHuman a, IHuman b)
        {
            var when = _clock.Now;
            var enc = new[] { new Encounter(a, b, when) };
            foreach (var ctx in _gen.BuildContexts(enc))
            {
                if (!_plans.TryTickOrStart(ctx, enact: (t, c) => Enact(t, c, ctx.When)))
                    _ = BehaviorRunner.RunOnce(_engine, ctx, _options, _cooldowns);
            }
        }

    }
}
