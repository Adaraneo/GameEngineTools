﻿// Human.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Homo
{
    using System.Text.Json.Serialization;
    using GameEngineTools;
    using GameEngineTools.Characters.CharacterModel.Behavior.Engine;
    using GameEngineTools.Characters.CharacterModel.Relationships;
    using GameEngineTools.Characters.Homo;

    public interface IHumanResolver
    {
        bool TryGet(Guid id, out IHuman human);
    }

    public interface IHuman
    {
        public double Age { get; set; }
        public HumanPhysiology Body { get; }
        public Dictionary<Guid, RelationshipModel> ExportRelationships { get; set; }
        public GenusType Genus { get; }
        public Name Name { get; set; }
        public Personality Personality { get; }
        public HumanPsychology Psychology { get; }
        public StatusType Status { get; set; }
        public Guid DNA { get; }
    }

    public abstract class Human : IHuman
    {
        private double age;

        private StadiumType stadium;

        private class RelationshipEventArgs : EventArgs
        {
        }

        protected double GetAge()
        {
            return age;
        }

        public Guid DNA => Body.DNA;

        protected void SetAge(double age)
        {
            this.age = age;
            Status = this.age > 0 ? StatusType.Alive : StatusType.Unborn;
            if (age >= 0 && age <= 3)
            {
                stadium = StadiumType.Baby;
            }
            else if (age > 3 && age < 13)
            {
                stadium = StadiumType.Child;
            }
            else if (age >= 13 && age < 18)
            {
                stadium = StadiumType.Teenager;
            }
            else if (age >= 18 && age < 42)
            {
                stadium = StadiumType.Adult;
            }
            else if (age >= 42 && age < 65)
            {
                stadium = StadiumType.MidAged;
            }
            else
            {
                stadium = StadiumType.Old;
            }

            var rnd = new Random();
            if (Body.Genus == GenusType.Female && this.age >= rnd.Next(10, 14) && this.age < rnd.Next(42, 46))
            {
                Body.Cycle.Enabled = true;
            }
            else
            {
                Body.Cycle.Enabled = false;
            }
        }

        [JsonConstructor]
        internal Human(GenusType genus)
        {
            Body = new HumanPhysiology();
            Body.Genus = genus;
            Psychology = new HumanPsychology();
            Personality = new Personality();
        }

        public event EventHandler? RelationshipChanged;

        public double Age { get => GetAge(); set => SetAge(value); }

        public HumanPhysiology Body { get; }

        [JsonInclude]
        [JsonPropertyName("Relationships")]
        public Dictionary<Guid, RelationshipModel> ExportRelationships { get; set; } = new();

        [JsonIgnore]
        public GenusType Genus { get => Body.Genus; }

        public Name Name { get; set; } = new();
        public Personality Personality { get; }
        public HumanPsychology Psychology { get; }
        public StatusType Status { get; set; }

        public void Die()
        {
            Status = StatusType.Dead;
        }

        public StadiumType GetStadium()
        {
            return stadium;
        }
    }
}
