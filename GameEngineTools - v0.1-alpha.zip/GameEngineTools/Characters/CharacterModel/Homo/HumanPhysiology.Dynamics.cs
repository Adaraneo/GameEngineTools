﻿// HumanPhysiology.Dynamics.cs
// VitalSigns, prostředí, dynamika zátěže + realistický Tick s TDEE/WtHR vlivem
namespace GameEngineTools.Characters.Homo
{
    using System;

    public enum CyclePhase
    { None, Menstruation, Follicular, PeriOvulatory, Luteal, PMS }

    public partial class HumanPhysiology
    {
        public ReproductiveCycle Cycle { get; } = new();

        /// <summary>Vitální funkce (okamžitý snapshot).</summary>
        public VitalSigns Vitals { get; } = new();

        /// <summary>Původní wrapper: psychika + prostředí → zátěž → vitály.</summary>
        public void CoupleWithPsychology(HumanPsychology psyche, EnvironmentPhysioInfo env, double activityDemand = 0.0)
        {
            double ComputeExertionFromPsychology(HumanPsychology p) =>
                Math.Clamp(0.3 * p.StressLevel + 0.4 * p.Motivation + 0.2 * p.Focus - 0.1 * p.Fatigue, 0, 1);

            double targetExertion = Math.Clamp(activityDemand + ComputeExertionFromPsychology(psyche), 0.0, 1.0);
            UpdateVitals(targetExertion, env);
        }

        public void Tick(
                    HumanPsychology psyche,
                    EnvironmentPhysioInfo env,
                    double activityDemand,
                    double ageYears,
                    double deltaTimeHours,
                    double? dailyCalorieIntakeKcal = null,
                    bool useMifflin = false)
        {
            // 1) Vypočti účinnou zátěž z psychiky a požadavku
            double psychExertion = Math.Clamp(0.3 * psyche.StressLevel + 0.4 * psyche.Motivation + 0.2 * psyche.Focus - 0.1 * psyche.Fatigue, 0, 1);
            double exertion = Math.Clamp(activityDemand + psychExertion, 0, 1);

            // 2) Aktualizuj vitály (tep, dech, teplota, SpO2, hydratace, tlak)
            UpdateVitals(exertion, env);

            // 3) Energetická bilance za hodinu
            double tdeePerHour = GetTDEE(ageYears, useMifflin) / 24.0;
            // Příjem (pokud není zadán, ber baseline stejný jako TDEE bez zátěžové složky)
            double intakePerHour = (dailyCalorieIntakeKcal ?? (GetTDEE(ageYears, useMifflin))) / 24.0;

            // Zátěžová nadstavba energetického výdeje (exertion ~ 0..1)
            // 0 → TDEE, 1 → ~ +60% nad TDEE/24 (hrubá, ale funkční aproximace)
            double extraExpenditure = tdeePerHour * 0.60 * exertion;

            double kcalBalanceHour = intakePerHour - (tdeePerHour + extraExpenditure); // + = surplus, − = deficit

            // 4) Vliv na únavu (0..1): zátěž zvyšuje, deficit zvyšuje, dobrá hydratace a odpočinek snižují
            double deficitLoad = Math.Max(0, -kcalBalanceHour) / 500.0; // každých ~500 kcal deficitu ~ +1 únavy/den (škálováno po hodinách)
            double hydrationLoad = (1.0 - Vitals.Hydration) * 0.5;        // dehydratace přidává únavu
            double exertionLoad = 0.6 * exertion;                        // okamžitý vliv námahy

            // Regenerace: při nízké zátěži se unava snižuje
            double restFactor = exertion < 0.2 ? 0.15 : 0.02;              // lepší regenerace při nízké zátěži
            // WtHR moduluje regeneraci: 0.45 → bonus, 0.55 → mírná penalizace, ≥0.6 → výraznější penalizace
            double wtHrAdj = Math.Clamp(0.5 - WtHR, -0.10, 0.10);          // (−) horší, (+) lepší
            double hydrationBonus = Vitals.Hydration > 0.9 ? 0.03 : 0.0;   // dobře hydratovaný organismus regeneruje lépe

            double recovery = (restFactor + wtHrAdj + hydrationBonus) * Math.Max(0.0, 1.0 - exertion);

            double fatigueDelta =
                (exertionLoad + deficitLoad + hydrationLoad) * (deltaTimeHours / 1.0)   // zátěž a deficit
                - recovery * (deltaTimeHours / 1.0);                                     // regenerace

            psyche.Fatigue = Math.Clamp(psyche.Fatigue + fatigueDelta, 0, 1);
        }

        public void TickOneDay_Reproductive(Random? rng = null)
        {
            Cycle.TickOneDay(rng);
        }

        /// <summary>Aktualizuj vitály podle zátěže (0..1) a prostředí.</summary>
        public void UpdateVitals(double exertion, EnvironmentPhysioInfo env)
        {
            Vitals.HeartRate = (int)Math.Clamp(60 + 90 * exertion, 40, 220);
            Vitals.RespirationRate = (int)Math.Clamp(12 + 24 * exertion, 6, 50);
            Vitals.Temperature = Math.Clamp(36.6 + 0.7 * exertion + 0.1 * env.AmbientTempDelta, 35.0, 41.5);
            Vitals.OxygenSaturation = Math.Clamp(0.98 - 0.1 * exertion + env.OxygenModifier, 0.6, 1.0);
            Vitals.Hydration = Math.Clamp(Vitals.Hydration - 0.005 * exertion - env.DehydrationRate, 0, 1);
            Vitals.SystolicBP = (int)Math.Clamp(120 + 40 * exertion, 90, 240);
            Vitals.DiastolicBP = (int)Math.Clamp(80 + 20 * exertion, 60, 150);
        }
    }

    public sealed class ReproductiveCycle
    {
        private Random rng = Random.Shared;

        internal void UpdatePhase()
        {
            // jednoduché mapování fází na dny
            if (DayInCycle <= 4) Phase = CyclePhase.Menstruation;
            else if (DayInCycle <= CurrentCycleLength / 2 - 2) Phase = CyclePhase.Follicular;
            else if (DayInCycle <= CurrentCycleLength / 2 + 2) Phase = CyclePhase.PeriOvulatory;
            else if (DayInCycle <= CurrentCycleLength - 5) Phase = CyclePhase.Luteal;
            else Phase = CyclePhase.PMS;

            IsFertileWindow = Phase == CyclePhase.PeriOvulatory;
            IsPMS = Phase == CyclePhase.PMS;

            // update hormonálních hodnot podle fáze
            Estrogen = Phase switch
            {
                CyclePhase.Menstruation => 0.2,
                CyclePhase.Follicular => 0.5 + 0.5 * Math.Sin(Math.PI * (DayInCycle - 4) / (CurrentCycleLength * 0.3)),
                CyclePhase.PeriOvulatory => 1.0,
                CyclePhase.Luteal => 0.6,
                CyclePhase.PMS => 0.35,
                _ => 0.5
            };

            Progesterone = Phase switch
            {
                CyclePhase.Menstruation => 0.2,
                CyclePhase.Follicular => 0.2,
                CyclePhase.PeriOvulatory => 0.4,
                CyclePhase.Luteal => 0.8,
                CyclePhase.PMS => 0.9,
                _ => 0.4
            };

            if (OnHormonalContraception)
            {
                Estrogen = 0.55;
                Progesterone = 0.65;
                IsFertileWindow = false;
                IsPMS = false;
                Phase = CyclePhase.Follicular;
            }
        }

        /// <summary>Skutečná délka aktuálního cyklu (náhodně v rozsahu).</summary>
        public int CurrentCycleLength { get; internal set; }

        public int CycleLengthMax { get; set; } = 32;

        /// <summary>Minimální a maximální délka cyklu (dny).</summary>
        public int CycleLengthMin { get; set; } = 24;

        public int DayInCycle { get; set; } = 1;
        public bool Enabled { get; set; } = true;
        public double Estrogen { get; private set; }
        public bool IsFertileWindow { get; private set; }
        public bool IsPMS { get; private set; }
        public bool OnHormonalContraception { get; set; } = false;
        public CyclePhase Phase { get; private set; } = CyclePhase.None;
        public double Progesterone { get; private set; }

        public void StartNewCycle()
        {
            // náhodná délka mezi min–max
            CurrentCycleLength = rng.Next(CycleLengthMin, CycleLengthMax + 1);
            DayInCycle = 1;
            UpdatePhase();
        }

        public void TickOneDay(Random? externalRng = null)
        {
            if (!Enabled) { Phase = CyclePhase.None; return; }
            rng = externalRng ?? rng;

            if (CurrentCycleLength == 0)
                StartNewCycle();

            DayInCycle++;
            if (DayInCycle > CurrentCycleLength)
            {
                // začíná nový cyklus
                StartNewCycle();
                return;
            }

            UpdatePhase();
        }
    }

    // === Podpůrné hodnotové typy (původní, zachované) ===

    /// <summary>Snapshot vitálních funkcí.</summary>
    public record VitalSigns
    {
        public int HeartRate { get; set; } = 60;          // bpm
        public int RespirationRate { get; set; } = 12;    // /min
        public int SystolicBP { get; set; } = 120;        // mmHg
        public int DiastolicBP { get; set; } = 80;        // mmHg
        public double Temperature { get; set; } = 36.6;   // °C
        /// <summary>Podíl 0–1 (SpO₂).</summary>
        public double OxygenSaturation { get; set; } = 0.98;
        /// <summary>Podíl 0–1 aktuální hydratace.</summary>
        public double Hydration { get; set; } = 1.0;
    }

    /// <summary>Prostředí ovlivňující fyziologii.</summary>
    public record EnvironmentPhysioInfo(
        double AmbientTempDelta = 0,   // Δ°C vůči 36.6
        double OxygenModifier = 0,   // aditivně k SpO₂ (−0.1 .. +0.1)
        double DehydrationRate = 0);  // frakce na tick (0..1)
}
