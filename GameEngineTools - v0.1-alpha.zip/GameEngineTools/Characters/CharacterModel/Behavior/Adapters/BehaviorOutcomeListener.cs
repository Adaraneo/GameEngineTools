﻿// BehaviorOutcomeListener.cs
// Copyright (c) 50PSoftware

using System;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using GameEngineTools.Characters.CharacterModel.Behavior.Engine;
using GameEngineTools.Characters.CharacterModel.Events;
using GameEngineTools.Characters.CharacterModel.Homo;
using GameEngineTools.Characters.CharacterModel.Relationships;
using GameEngineTools.World.Utils.Time;

namespace GameEngineTools.Characters.CharacterModel.Behavior.Adapters
{
    /// <summary>
    /// Vezme RelationshipChangedEvent (ΔLike/ΔTrust/ΔCloseness) a InteractionAppliedEvent (When, Context),
    /// složí reward ~[-1..+1] a zapíše do actor.Psychology.ShortMemory (BehaviorMemory).
    /// Subscribuje se v konstruktoru na IEventBus.
    /// </summary>
    public sealed class BehaviorOutcomeListener
    {
        private readonly ILogger<BehaviorOutcomeListener> _log;
        private readonly IHumanResolver _humans;

        // poslední známé Δ metrik pro (actor,target) – bez času (InteractionAppliedEvent má When)
        private readonly Dictionary<(Guid actor, Guid target), (double dLike, double dTrust, double dClose)> _lastDelta = new();

        public BehaviorOutcomeListener(IEventBus bus, IHumanResolver humans, ILogger<BehaviorOutcomeListener> log)
        {
            _humans = humans;
            _log = log;

            bus.Subscribe<RelationshipChangedEvent>(OnRelationshipChanged);
            bus.Subscribe<InteractionAppliedEvent>(OnInteractionApplied);
        }

        private void OnRelationshipChanged(RelationshipChangedEvent e)
        {
            var key = (e.ActorId, e.TargetId);
            var (dLike, dTrust, dClose) = _lastDelta.TryGetValue(key, out var v) ? v : (0.0, 0.0, 0.0);

            switch (e.ChangeType)
            {
                case "Liking": dLike = e.NewValue - e.OldValue; break;
                case "Trust": dTrust = e.NewValue - e.OldValue; break;
                case "Closeness": dClose = e.NewValue - e.OldValue; break;
                default: return; // ostatní změny pro reward nepočítáme
            }
            _lastDelta[key] = (dLike, dTrust, dClose);
        }

        private void OnInteractionApplied(InteractionAppliedEvent e)
        {
            if (!_humans.TryGet(e.ActorId, out var actor) || actor is null) return;

            // vezmi/vytvoř ShortMemory
            var mem = actor.Psychology.ShortMemory ??= new BehaviorMemory();

            var key = (e.ActorId, e.TargetId);
            double reward = 0.0;

            if (_lastDelta.TryGetValue(key, out var d))
            {
                // kompozitní odměna (laditelné váhy)
                reward = 0.5 * d.dTrust + 0.3 * d.dLike + 0.2 * d.dClose;
            }

            // mírný odpočet za „náročnost/risiko“ interakce (pokud je k dispozici)
            if (e.Context != null)
            {
                var timeOrRiskCost = System.Math.Clamp(e.Context.Value.Risk, 0f, 1f) * 0.15;
                reward -= timeOrRiskCost;
            }

            var bType = MapBehaviorType(e.InteractionType, e.Context);
            mem.ReportOutcome(bType, e.TargetId, reward, e.When);

            ApplyPsycheOutcome(actor, bType, reward, (e.Context?.SocialAudience ?? 0f) * (1f - (e.Context?.Privacy ?? 1f)));

            _log.LogDebug("Outcome: {Type} R={Reward:0.000} {Actor}->{Target} @ {When}",
                bType, reward, e.ActorId, e.TargetId, e.When.ToString("O"));
        }

        private static void ApplyPsycheOutcome(IHuman actor, BehaviorType type, double reward01, double normPressure01)
        {
            reward01 = Math.Max(-1, Math.Min(1, reward01));
            var psy = actor.Psychology;

            double risk = type switch
            {
                BehaviorType.InitiateIntimacySoft or BehaviorType.InitiateIntimacyBold => 0.90,
                BehaviorType.Kiss or BehaviorType.KissLight => 0.75,
                BehaviorType.FlirtBold => 0.60,
                BehaviorType.FlirtLight => 0.35,
                BehaviorType.Confront or BehaviorType.Retort => 0.70,
                _ => 0.25
            };

            // rychlý, ale jemný posun stavů 0..1
            psy.Mood = Math.Clamp(psy.Mood + 0.15 * reward01, 0, 1);
            psy.Confidence = Math.Clamp(psy.Confidence + 0.12 * reward01, 0, 1);
            psy.StressLevel = Math.Clamp(psy.StressLevel + 0.10 * (risk * normPressure01) - 0.08 * reward01, 0, 1);
        }


        private static BehaviorType MapBehaviorType(InteractionType it, InteractionContext? ctx)
        {
            var phys = ctx?.Physicality ?? 0f;
            return it switch
            {
                InteractionType.Flirt => phys >= 0.25f ? BehaviorType.FlirtBold : BehaviorType.FlirtLight,
                InteractionType.Aftercare => BehaviorType.AftercareCuddle,
                InteractionType.Touch => phys >= 0.35f ? BehaviorType.InitiateIntimacyBold : BehaviorType.InitiateIntimacySoft,
                InteractionType.Apology => BehaviorType.Apologize,
                InteractionType.Argument => BehaviorType.Retort,
                InteractionType.Compliment => BehaviorType.ComplimentLight,
                _ => BehaviorType.KeepDistance
            };
        }
    }
}
