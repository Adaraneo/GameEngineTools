﻿// Retort.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// Krátká ostrá reakce (spíš negativní dopad).
    public sealed class Retort : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.Retort;

        public void Apply(in BehaviorContext ctx)
        {
            // Mapujeme na Honesty s výrazně negativním tónem a vyšším rizikem
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Honesty, // ostře podané "říkám pravdu"
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    EmotionalTone = System.Math.Clamp(ctx.Ix.EmotionalTone - 0.50f, -1f, 1f),
                    Depth = ctx.Ix.Depth,
                    Privacy = ctx.Ix.Privacy,
                    Risk = System.Math.Clamp(ctx.Ix.Risk + 0.25f, 0f, 1f),
                    SocialAudience = ctx.Ix.SocialAudience,
                    SharedGoal = ctx.Ix.SharedGoal,
                    Continuity = ctx.Ix.Continuity
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && ctx.Situation == SituationType.InsultReceived;

        public float Utility(in BehaviorContext ctx)
        {
            var psy = ctx.Actor.Psychology;
            var per = ctx.Actor.Personality;
            double A = per.BigFive[BigFiveTrait.Agreeableness];
            // Více pravděpodobné při zvednutém hněvu/stresu a nižší ochotě vycházet vstříc
            double u = 0.05 + 0.40 * psy.Aggression + 0.30 * psy.StressLevel - 0.25 * A
                       + 0.10 * (1.0 - ctx.Ix.Privacy) + 0.05 * ctx.Ix.Risk;
            return Bx.Clamp01(u);
        }
    }
}
