﻿// InitiateIntimacyBold.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// Odvážnější eskalace k sexu (větší nárok na stage/trust).
    public sealed class InitiateIntimacyBold : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.FlirtBold;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Sex,
                When = ctx.When,
                IsMicro = false,
                Context = new InteractionContext
                {
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.40f, -1f, 1f),
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.45f, 0f, 1f),
                    Physicality = Math.Clamp(ctx.Ix.Physicality + 0.80f, 0f, 1f),
                    Warmth = Math.Clamp(ctx.Ix.Warmth + 0.25f, 0f, 1f),
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.15f, 0f, 1f),
                    Privacy = Math.Max(ctx.Ix.Privacy, 0.80f),
                    SocialAudience = 0.0f,
                    SharedGoal = Math.Clamp(ctx.Ix.SharedGoal + 0.15f, 0f, 1f),
                    Continuity = Math.Clamp(ctx.Ix.Continuity + 0.25f, 0f, 1f)
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
        {
            if (ctx.Target is null || !ctx.Rel.HasValue) return false;
            var r = ctx.Rel.Value;
            bool stageOk = r.Stage >= BondStage.Intimate || (r.Stage >= BondStage.Intimate && r.Closeness >= 70f);
            bool trustOk = r.Trust >= 70f;
            bool attractOk = r.Attraction >= 70f;
            bool privacyOk = ctx.Ix.Privacy >= 0.70f && ctx.Ix.SocialAudience <= 0.02f;
            bool toneOk = ctx.Ix.EmotionalTone >= 0.1f;
            bool arousalOk = ctx.Actor.Psychology.Arousal >= 0.55f;
            return stageOk && trustOk && attractOk && privacyOk && toneOk && arousalOk;
        }

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality; var psy = ctx.Actor.Psychology; var r = ctx.Rel!.Value;
            double E = per.BigFive[BigFiveTrait.Extraversion];
            double u = 0.05 + 0.35 * E + 0.30 * (r.Attraction / 100.0) + 0.25 * (r.Closeness / 100.0)
                       + 0.15 * ctx.Ix.Privacy + 0.20 * psy.Arousal - 0.15 * psy.StressLevel - 0.12 * psy.Fatigue;
            return Bx.Clamp01(u);
        }
    }
}
