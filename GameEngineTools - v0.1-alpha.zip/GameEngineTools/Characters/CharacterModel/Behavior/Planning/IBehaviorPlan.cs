﻿// IBehaviorPlan.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Planning
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public enum PlanStatus { NotStarted, Running, Succeeded, Failed }

    public interface IBehaviorPlan
    {
        string Name { get; }
        bool CanStart(BehaviorContext ctx);
        PlanStatus Tick(BehaviorContext ctx, Func<BehaviorType, BehaviorContext, bool> enact);
    }
}
