﻿// DeferReply.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// Zdvořilý odklad – krátké potvrzení a přesun na později.
    public sealed class DeferReply : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.KeepDistance;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.SpendTime,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    Privacy = ctx.Ix.Privacy,
                    Risk = ctx.Ix.Risk,
                    SharedGoal = ctx.Ix.SharedGoal,
                    SocialAudience = ctx.Ix.SocialAudience,
                    Continuity = Math.Clamp(ctx.Ix.Continuity - 0.05f, 0f, 1f),
                    Depth = Math.Clamp(ctx.Ix.Depth - 0.10f, 0f, 1f),
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.00f, -1f, 1f),
                    Warmth = Math.Clamp(ctx.Ix.Warmth + 0.05f, 0f, 1f)
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && ctx.CrowdNoise01 > 0.3f || ctx.Actor.Psychology.Fatigue > 0.6f;

        public float Utility(in BehaviorContext ctx)
        {
            var psy = ctx.Actor.Psychology;
            double u = 0.10 + 0.30 * psy.Fatigue + 0.20 * psy.StressLevel + 0.15 * ctx.NormPressure01
                       - 0.15 * (0.5 + 0.5 * psy.Mood);
            return Bx.Clamp01(u);
        }
    }
}
