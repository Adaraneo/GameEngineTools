﻿// Air.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.MagicSystem
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.GameObjects;

    public class Air : Magic, IMagic
    {
        private void Air_MagicDone(object? sender, MagicArguments e)
        {
            var humanPsychology = e.Affectator.Psychology;
            var humanPhysiology = e.Affectator.Body;
            if (!canCast)
            {
                if (e.Affected is Action a && a.Method.Name.Contains(this.GetType().Name))
                {
                    a.Invoke();
                }
            }
            else
            {
                if (e.Affected is NPC npc)
                {
                    var protection = npc.Protection;
                    var points = e.Affectator.Magic.AffectPoints;
                    npc.DecreaseHealth((protection + points) * 0.3);
                }
            }
        }

        internal Air(Person p) : base(p)
        {
            this.MagicType = MagicType.Air;
            this.MagicDone += Air_MagicDone;
            this.canCast = false;
        }

        public void SetCanCast(bool canCast)
        {
            this.canCast = canCast;
        }
    }
}
