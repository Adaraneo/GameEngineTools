﻿// HumanPhysiologyModel.cs
// Copyright (c) 50PSoftware

// HumanPhysiology.Model.cs
// DTO + mapování pro JSON serializaci/deserializaci HumanPhysiology.

namespace GameEngineTools.Characters.Homo
{
    using System.Text.Json;
    using System.Text.Json.Serialization;
    using GameEngineTools.Characters.CharacterModel;

    public partial class HumanPhysiology
    {
        /// <summary>Default JSON options – enumy jako stringy, hezké odsazení.</summary>
        public static JsonSerializerOptions JsonOptions { get; } = new JsonSerializerOptions
        {
            WriteIndented = true,
            Converters = { new JsonStringEnumConverter() }
        };

        /// <summary>Aplikuj hodnoty z modelu do instance fyziologie.</summary>
        public void ApplyModel(HumanPhysiologyModel m)
        {
            if (m == null) return;

            this.Genus = m.Genus;
            this.Blood = m.Blood;
            this.Rh = m.Rh;

            // Antropometrie
            this.HeightCm = m.HeightCm;
            this.WeightKg = m.WeightKg;

            // Vzhled
            if (m.Appearance != null)
            {
                var a = m.Appearance;

                this.EyeColor = a.EyeColor;
                this.HasHeterochromia = a.HasHeterochromia;

                this.HairColor = a.HairColor;
                this.HairType = a.HairType;
                this.HairDensity = a.HairDensity;
                this.HairLengthCm = a.HairLengthCm;

                this.SkinTone = a.SkinTone;
                this.FaceShape = a.FaceShape;
                this.DominantHand = a.DominantHand;

                this.ChestCm = a.ChestCm;
                this.BustCm = a.BustCm;
                this.UnderbustCm = a.UnderbustCm;
                this.WaistCm = a.WaistCm;
                this.HipsCm = a.HipsCm;
                this.ShoulderBreadthCm = a.ShoulderBreadthCm;
                this.NeckCm = a.NeckCm;
                this.UpperArmCircumferenceCm = a.UpperArmCircumferenceCm;
                this.ThighCircumferenceCm = a.ThighCircumferenceCm;
                this.CalfCircumferenceCm = a.CalfCircumferenceCm;

                if (a.Somatotype != null)
                {
                    this.Somatotype = new Somatotype
                    {
                        Ectomorph = a.Somatotype.Ectomorph,
                        Mesomorph = a.Somatotype.Mesomorph,
                        Endomorph = a.Somatotype.Endomorph
                    };
                    this.Somatotype.Normalize();
                }
            }

            // Životní styl & smysly
            this.RestingHeartRateBpm = m.RestingHeartRateBpm;
            this.Chronotype = m.Chronotype;
            this.SleepNeedHours = m.SleepNeedHours;
            this.MetabolismRate = m.MetabolismRate;
            this.ImmunityLevel = m.ImmunityLevel;
            this.ActivityLevel = m.ActivityLevel;
            this.VisionSphereD = m.VisionSphereD;
            this.HearingThresholdDbHl = m.HearingThresholdDbHl;
            this.Allergies = m.Allergies ?? Array.Empty<string>();
            this.Intolerances = m.Intolerances ?? Array.Empty<string>();

            // Vitály – přepisuj opatrně (je to "snapshot"); ponechávám přímý transfer
            if (m.Vitals != null)
            {
                this.Vitals.HeartRate = m.Vitals.HeartRate;
                this.Vitals.RespirationRate = m.Vitals.RespirationRate;
                this.Vitals.SystolicBP = m.Vitals.SystolicBP;
                this.Vitals.DiastolicBP = m.Vitals.DiastolicBP;
                this.Vitals.Temperature = m.Vitals.Temperature;
                this.Vitals.OxygenSaturation = m.Vitals.OxygenSaturation;
                this.Vitals.Hydration = m.Vitals.Hydration;
            }

            if (m.MenstruationCycle != null && this.Cycle.Enabled)
            {
                this.Cycle.DayInCycle = m.MenstruationCycle.DayInCycle;
                this.Cycle.CycleLengthMin = m.MenstruationCycle.CycleLengthMin;
                this.Cycle.CycleLengthMax = m.MenstruationCycle.CycleLengthMax;
                this.Cycle.CurrentCycleLength = m.MenstruationCycle.CurrentCycleLength;
                this.Cycle.UpdatePhase();
            }
        }

        /// <summary>Export aktuálního fyzio stavu do serializovatelného modelu.</summary>
        public HumanPhysiologyModel ToModel()
        {
            return new HumanPhysiologyModel
            {
                Genus = this.Genus,
                Blood = this.Blood,
                Rh = this.Rh,

                HeightCm = this.HeightCm,
                WeightKg = this.WeightKg,

                Appearance = new AppearanceModel
                {
                    EyeColor = this.EyeColor,
                    HasHeterochromia = this.HasHeterochromia,

                    HairColor = this.HairColor,
                    HairType = this.HairType,
                    HairDensity = this.HairDensity,
                    HairLengthCm = this.HairLengthCm,

                    SkinTone = this.SkinTone,
                    FaceShape = this.FaceShape,
                    DominantHand = this.DominantHand,

                    ChestCm = this.ChestCm,
                    BustCm = this.BustCm,
                    UnderbustCm = this.UnderbustCm,
                    WaistCm = this.WaistCm,
                    HipsCm = this.HipsCm,
                    ShoulderBreadthCm = this.ShoulderBreadthCm,
                    NeckCm = this.NeckCm,
                    UpperArmCircumferenceCm = this.UpperArmCircumferenceCm,
                    ThighCircumferenceCm = this.ThighCircumferenceCm,
                    CalfCircumferenceCm = this.CalfCircumferenceCm,

                    Somatotype = new SomatotypeModel
                    {
                        Ectomorph = this.Somatotype.Ectomorph,
                        Mesomorph = this.Somatotype.Mesomorph,
                        Endomorph = this.Somatotype.Endomorph
                    }
                },

                RestingHeartRateBpm = this.RestingHeartRateBpm,
                Chronotype = this.Chronotype,
                SleepNeedHours = this.SleepNeedHours,
                MetabolismRate = this.MetabolismRate,
                ImmunityLevel = this.ImmunityLevel,
                ActivityLevel = this.ActivityLevel,
                VisionSphereD = this.VisionSphereD,
                HearingThresholdDbHl = this.HearingThresholdDbHl,
                Allergies = this.Allergies ?? Array.Empty<string>(),
                Intolerances = this.Intolerances ?? Array.Empty<string>(),

                Vitals = new VitalSignsModel
                {
                    HeartRate = this.Vitals.HeartRate,
                    RespirationRate = this.Vitals.RespirationRate,
                    SystolicBP = this.Vitals.SystolicBP,
                    DiastolicBP = this.Vitals.DiastolicBP,
                    Temperature = this.Vitals.Temperature,
                    OxygenSaturation = this.Vitals.OxygenSaturation,
                    Hydration = this.Vitals.Hydration
                },

                MenstruationCycle = (this.Cycle.Enabled) ? new MenstruationCycleModel
                {
                    CycleLengthMin = this.Cycle.CycleLengthMin,
                    DayInCycle = this.Cycle.DayInCycle,
                    CycleLengthMax = this.Cycle.CycleLengthMax,
                    CurrentCycleLength = this.Cycle.CurrentCycleLength
                } : null
            };
        }

        #region json Helpers

        //public string ToJson(JsonSerializerOptions? options = null)
        //    => JsonSerializer.Serialize(ToModel(), options ?? JsonOptions);

        //public static HumanPhysiologyModel FromJson(string json, JsonSerializerOptions? options = null)
        //    => JsonSerializer.Deserialize<HumanPhysiologyModel>(json, options ?? JsonOptions)!;

        //public void ApplyModelJson(string json, JsonSerializerOptions? options = null)
        //    => ApplyModel(FromJson(json, options));

        #endregion json Helpers
    }
}

namespace GameEngineTools.Characters.CharacterModel
{
    using System;
    using GameEngineTools; // GenusType
    using GameEngineTools.Characters.Homo;

    public sealed class AppearanceModel
    {
        public double BustCm { get; set; }
        public double CalfCircumferenceCm { get; set; }
        public DominantHand DominantHand { get; set; } = DominantHand.Right;
        public EyeColor EyeColor { get; set; } = EyeColor.Brown;
        public FaceShape FaceShape { get; set; } = FaceShape.Oval;
        public HairColor HairColor { get; set; } = HairColor.Brown;
        public HairDensity HairDensity { get; set; } = HairDensity.Medium;
        public double HairLengthCm { get; set; }
        public HairType HairType { get; set; } = HairType.Straight;
        public bool HasHeterochromia { get; set; }
        public double HipsCm { get; set; }
        public double ChestCm { get; set; }
        public double NeckCm { get; set; }
        public double ShoulderBreadthCm { get; set; }
        public SkinTone SkinTone { get; set; } = SkinTone.Fitzpatrick3;
        public SomatotypeModel Somatotype { get; set; } = new();
        public double ThighCircumferenceCm { get; set; }
        public double UnderbustCm { get; set; }
        public double UpperArmCircumferenceCm { get; set; }
        public double WaistCm { get; set; }
    }

    public sealed class HumanPhysiologyModel
    {
        public ActivityLevel ActivityLevel { get; set; }

        public string[] Allergies { get; set; } = Array.Empty<string>();

        // Vzhled + proporce
        public AppearanceModel Appearance { get; set; } = new();

        public BloodType Blood { get; set; }

        // Jádro / identita
        //public Guid DNA { get; set; }
        public GenusType Genus { get; set; }

        public int HearingThresholdDbHl { get; set; }

        // Antropometrie
        public double HeightCm { get; set; }

        public SleepChronotype Chronotype { get; set; }
        public ImmunityLevel ImmunityLevel { get; set; }
        public string[] Intolerances { get; set; } = Array.Empty<string>();
        public MenstruationCycleModel? MenstruationCycle { get; set; }
        public MetabolismRate MetabolismRate { get; set; }

        // Životní styl & smysly
        public int RestingHeartRateBpm { get; set; }

        public RhFactor Rh { get; set; }
        public double SleepNeedHours { get; set; }
        public double VisionSphereD { get; set; }

        // Vitály (okamžitý stav)
        public VitalSignsModel Vitals { get; set; } = new();

        public double WeightKg { get; set; }
    }

    public sealed class MenstruationCycleModel
    {
        public int CurrentCycleLength { get; set; }
        public int CycleLengthMax { get; set; }
        public int CycleLengthMin { get; set; }
        public int DayInCycle { get; set; }
    }

    public sealed class SomatotypeModel
    {
        public double Ectomorph { get; set; } = 0.34;
        public double Endomorph { get; set; } = 0.33;
        public double Mesomorph { get; set; } = 0.33;
    }

    public sealed class VitalSignsModel
    {
        public int DiastolicBP { get; set; }
        public int HeartRate { get; set; }
        public double Hydration { get; set; }
        public double OxygenSaturation { get; set; }
        public int RespirationRate { get; set; }
        public int SystolicBP { get; set; }
        public double Temperature { get; set; }
        // 0..1
        // 0..1
    }
}
