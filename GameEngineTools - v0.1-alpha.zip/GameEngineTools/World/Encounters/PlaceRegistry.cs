﻿// PlaceRegistry.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.World.Encounters
{
    public sealed class Place : IPlaceLite
    {
        public Place(Guid id, string name, PlaceArchetype archetype, int capacityHint, bool isTransit)
        {
            Id = id; Name = name; Archetype = archetype; CapacityHint = capacityHint; IsTransit = isTransit;
        }

        public PlaceArchetype Archetype { get; }
        public int CapacityHint { get; }
        public Guid Id { get; }
        public bool IsTransit { get; }
        public string Name { get; }

        public override string ToString() => $"{Name} ({Archetype})";
    }

    public sealed class PlaceRegistry
    {
        private readonly Dictionary<Guid, Place> _places = new();
        public IReadOnlyDictionary<Guid, Place> All => _places;

        public Place Add(string name, PlaceArchetype archetype, int capacityHint, bool isTransit = false)
        {
            var p = new Place(Guid.NewGuid(), name, archetype, capacityHint, isTransit);
            _places[p.Id] = p;
            return p;
        }

        public Place Get(Guid id) => _places[id];
    }
}
