﻿// InMemoryKnowledge.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.World.Knowledge
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using GameEngineTools.World.Utils.Time;

    public sealed class InMemoryKnowledge : IKnowledgeLedger
    {
        private readonly List<Observation> _obs = new();

        public float Believe(Guid observerId, Guid subjectId, string claim)
        {
            var relevant = _obs.Where(x => x.SubjectId == subjectId && x.Claim == claim);
            float nope = 1f;
            foreach (var o in relevant)
            {
                var ageDays = Math.Max(0, (int)(WDateTime.Now - o.When).TotalDays);
                var decay = MathF.Exp(-0.02f * ageDays);
                nope *= 1f - Math.Clamp(o.Confidence, 0f, 1f) * decay;
            }
            return 1f - nope;
        }

        public void Record(Observation o) => _obs.Add(o);
    }
}
