﻿// DeflectQuestion.cs
// Copyright (c) 50PSoftware

using GameEngineTools.Characters.CharacterModel.Homo;
using GameEngineTools.Characters.CharacterModel.Relationships;

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    /// Elegantní uhnutí nepohodlné otázce (nesnižuje vztah, sníží hloubku/risk).
    public sealed class DeflectQuestion : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.KeepDistance;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.SpendTime,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    Privacy = ctx.Ix.Privacy,
                    Risk = Math.Max(0f, ctx.Ix.Risk - 0.10f),
                    SharedGoal = ctx.Ix.SharedGoal,
                    SocialAudience = ctx.Ix.SocialAudience,
                    Continuity = ctx.Ix.Continuity,
                    Depth = Math.Max(0f, ctx.Ix.Depth - 0.20f),
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.05f, -1f, 1f),
                    Warmth = Math.Clamp(ctx.Ix.Warmth + 0.00f, 0f, 1f)
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && (ctx.Ix.Depth > 0.5f || ctx.Ix.Risk > 0.4f || ctx.Ix.SocialAudience > 0.3f);

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality; var psy = ctx.Actor.Psychology;
            double C = per.BigFive[BigFiveTrait.Conscientiousness];
            double N = per.BigFive[BigFiveTrait.Neuroticism];
            double u = 0.10 + 0.20 * C + 0.15 * N
                       + 0.15 * ctx.Ix.SocialAudience + 0.15 * ctx.Ix.Risk + 0.10 * ctx.Ix.Depth
                       - 0.10 * (0.5 + 0.5 * psy.Mood);
            return Bx.Clamp01(u);
        }
    }
}
