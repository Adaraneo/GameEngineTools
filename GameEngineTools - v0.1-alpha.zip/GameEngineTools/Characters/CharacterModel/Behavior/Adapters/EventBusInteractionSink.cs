﻿// EventBusInteractionSink.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Adapters
{
    using GameEngineTools.Characters.CharacterModel.Events;
    using GameEngineTools.Logging;
    using GameEngineTools.World.Core.Time;
    using Microsoft.Extensions.Logging;

    public sealed class EventBusInteractionSink : IInteractionSink
    {
        private readonly IEventBus _bus;
        private readonly ILogger<EventBusInteractionSink> _log;

        public EventBusInteractionSink(IEventBus bus, IClock clock, ILogger<EventBusInteractionSink> log)
        {
            _bus = bus;
            _log = log;
        }

        public void Enqueue(InteractionEvent e)
        {
            using var _ = _log.BeginScope(new Dictionary<string, object>()
            {
                ["actor"] = e.From.DNA,
                ["target"] = e.To.DNA,
                ["type"] = e.Type.ToString()
            });

            _log.BehaviorEnqueue(
                e.When.ToString("HH:mm:ss"),
                e.From.DNA.ToString(), e.To.DNA.ToString(), e.Type.ToString(),
                e.Context.Value.Privacy, e.Context.Value.Depth, e.Context.Value.EmotionalTone);

            if (e is null || e.From is null || e.To is null) return;

            var evt = new ScheduledInteractionEvent(
                ActorId: e.From.DNA,
                TargetId: e.To.DNA,
                InteractionType: e.Type,
                Magnitude: e.Magnitude,
                Context: e.Context,
                e.When
            );

            _bus.PublishAsync(evt);
        }
    }
}
