﻿// ScenarioPresenceDecorator.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.World.Encounters.Scenarios
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using GameEngineTools.World.Encounters;
    using GameEngineTools.World.Utils.Time;

    public sealed class ScenarioPresenceDecorator : IWorldPresenceProvider
    {
        private readonly IWorldPresenceProvider _inner;
        private readonly ScenarioBook _scenarios;

        public ScenarioPresenceDecorator(IWorldPresenceProvider inner, ScenarioBook scenarios)
        {
            _inner = inner; _scenarios = scenarios;
        }

        public IEnumerable<PresenceSegment> BuildPresence(WDateTime dayStartUtc, WDateTime dayEndUtc)
        {
            var basePresence = _inner.BuildPresence(dayStartUtc, dayEndUtc);
            var extraPresence = _scenarios.GetExtraPresence(dayStartUtc, dayEndUtc);
            // Jednoduché sloučení (můžeš přidat deduplikaci, když bude třeba)
            return basePresence.Concat(extraPresence);
        }

        public IPlaceLite GetPlace(Guid placeId) => _inner.GetPlace(placeId);
    }
}
