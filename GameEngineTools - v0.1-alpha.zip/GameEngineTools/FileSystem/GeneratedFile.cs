﻿// GeneratedFile.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.FileSystem
{
    using System.Text.Json;
    using System.Text.Json.Serialization;
    using Microsoft.Extensions.Options;
    using GameEngineTools;
    using GameEngineTools.Characters.GameObjects;
    using GameEngineTools.Extensions;
    using GameEngineTools.FileSystem.JsonConverters;

    public sealed class GeneratedFile : IGeneratedFile
    {
        private IGameEngineToolsManager characterManager;
        public GeneratedFile(IGameEngineToolsManager characterManager, IOptions<GeneratedFileOptions> options = null)
        {
            this.characterManager = characterManager;
            if (options != null)
            {
                NPCDirectory = options.Value.NPCDirectory;
                PlayerDirectory = options.Value.PlayerDirectory;
            }
        }
        public string NPCDirectory { get; set; }
        public string PlayerDirectory { get; set; }

        public string Export(PC player)
        {
            var filename = string.Format("{0}.json", player.Person.Body.DNA.ToString());
            var jsonOptions = new JsonSerializerOptions()
            {
                WriteIndented = true,
                ReferenceHandler = ReferenceHandler.IgnoreCycles,
                Converters =
                {
                    new PersonJsonConverter(),
                },
            };

            characterManager.ConvertPersonToDNA(player);

            var jsonObj = JsonSerializer.Serialize(player, jsonOptions);
            StreamWriter file = new StreamWriter(File.Create($"{Path.Combine(PlayerDirectory, filename)}"));
            file.Write(jsonObj);
            file.Close();
            return filename;
        }

        public string Export(NPC npc)
        {
            var filename = string.Format("{0}.json", npc.Person.Body.DNA.ToString());
            var jsonOptions = new JsonSerializerOptions()
            {
                WriteIndented = true,
                ReferenceHandler = ReferenceHandler.IgnoreCycles,
                Converters =
                {
                    new PersonJsonConverter(),
                },
            };

            characterManager.ConvertPersonToDNA(npc);

            var jsonObj = JsonSerializer.Serialize(npc, jsonOptions);
            StreamWriter file = new StreamWriter(File.Create($"{Path.Combine(NPCDirectory, filename)}"));
            file.Write(jsonObj);
            file.Close();
            return filename;
        }

        public void ExportNPPCs(string pathToRootDirectory = null)
        {
            _ = new GenerateFileSystem(pathToRootDirectory);
            var nppcs = characterManager.NPPCs.GetEnumerator();
            nppcs.MoveNext();
            var player = (PC)nppcs.Current;
            Export(player);
            while (nppcs.MoveNext())
            {
                Export((NPC)nppcs.Current);
            }
        }

        public NPC ImportNPC(string filename)
        {
            var jsonOptions = new JsonSerializerOptions()
            {
                Converters =
                {
                    new PersonJsonConverter(),
                },
            };
            StreamReader file = new StreamReader(File.OpenRead($"{Path.Combine(NPCDirectory, filename)}"));
            var npc = JsonSerializer.Deserialize<NPC>(file.ReadToEnd(), jsonOptions);
            file.Close();

            var dna = filename.Substring(0, (filename.Length - new FileInfo(filename).Extension.Length));
            npc.Person.Body.DNA = Guid.Parse(dna);
            NPPC.People.Add(npc.Person);
            return npc;
        }

        public void ImportNPPCs(string pathToRootDirectory = null)
        {
            NPPC.People.Clear();
            characterManager.NPPCs.Clear();
            GenerateFileSystem generateFileSystem = new GenerateFileSystem(pathToRootDirectory);
            try
            {
                var fileName = generateFileSystem.Filenames.GetEnumerator();
                fileName.MoveNext();
                characterManager.NPPCs.Add(ImportPC(fileName.Current));
                while (fileName.MoveNext())
                {
                    characterManager.NPPCs.Add(ImportNPC(fileName.Current));
                }
            }
            catch
            {
                throw;
            }
        }

        public PC ImportPC(string filename)
        {
            var jsonOptions = new JsonSerializerOptions()
            {
                Converters =
                {
                    new PersonJsonConverter(),
                },
            };
            StreamReader file = new StreamReader(File.OpenRead($"{Path.Combine(PlayerDirectory, filename)}"));
            var pc = JsonSerializer.Deserialize<PC>(file.ReadToEnd(), jsonOptions);
            file.Close();

            var dna = filename.Substring(0, (filename.Length - new FileInfo(filename).Extension.Length));
            pc.Person.Body.DNA = Guid.Parse(dna);
            NPPC.People.Add(pc.Person);
            return pc;
        }
    }
}
