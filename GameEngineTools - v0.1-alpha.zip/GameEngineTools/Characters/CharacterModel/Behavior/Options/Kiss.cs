﻿// Kiss.cs
// Copyright (c) 50PSoftware

using GameEngineTools.Characters.CharacterModel.Homo;
using GameEngineTools.Characters.CharacterModel.Relationships;

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    /// Jemné políbení – fyzická eskalace. Bez nové Relationship logiky:
    /// event typ držíme jako Flirt (pokud nemáš InteractionType.Kiss),
    /// a fyzikalitu zvedáme přes kontext.
    public sealed class Kiss : IBehaviorOption
    {
        // Sdílí cooldown s „odvážnějšími“ flirt typy
        public BehaviorType Type => BehaviorType.FlirtBold;

        public void Apply(in BehaviorContext ctx)
        {
            // Pokud nemáš InteractionType.Kiss, použij Flirt a nech Physicality/Depth/Warmth vytáhnout „polibek“ z kontextu.
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Flirt, // nebo InteractionType.Kiss, pokud ho máš
                When = ctx.When,
                IsMicro = false,
                Context = new InteractionContext
                {
                    Privacy = Math.Max(ctx.Ix.Privacy, 0.55f),
                    SocialAudience = 0.0f,
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.12f, 0f, 1f),
                    Warmth = Math.Clamp(ctx.Ix.Warmth + 0.20f, 0f, 1f),
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.20f, -1f, 1f),
                    Physicality = Math.Clamp(ctx.Ix.Physicality + 0.35f, 0f, 1f),
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.05f, 0f, 1f),
                    SharedGoal = Math.Clamp(ctx.Ix.SharedGoal + 0.08f, 0f, 1f),
                    Continuity = Math.Clamp(ctx.Ix.Continuity + 0.12f, 0f, 1f),
                    Surprise = Math.Clamp(ctx.Ix.Surprise + 0.05f, 0f, 1f)
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
        {
            if (ctx.Target is null || !ctx.Rel.HasValue) return false;
            var r = ctx.Rel.Value;

            bool stageOk = r.Stage >= BondStage.Intimate;
            bool trustOk = r.Trust >= 55f;
            bool attractOk = r.Attraction >= 65f;
            bool privacyOk = ctx.Ix.Privacy >= 0.50f && ctx.Ix.SocialAudience <= 0.10f;
            bool toneOk = ctx.Ix.EmotionalTone >= 0.00f;
            bool arousalOk = ctx.Actor.Psychology.Arousal >= 0.35f;

            return stageOk && trustOk && attractOk && privacyOk && toneOk && arousalOk;
        }

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality;
            var psy = ctx.Actor.Psychology;
            var r = ctx.Rel!.Value;

            double E = per.BigFive[BigFiveTrait.Extraversion];

            double u =
                0.05
              + 0.30 * E
              + 0.25 * (r.Attraction / 100.0)
              + 0.20 * (r.Closeness / 100.0)
              + 0.12 * ctx.Ix.Privacy
              + 0.12 * psy.Arousal
              + 0.08 * (0.5 + 0.5 * psy.Mood)
              - 0.10 * psy.StressLevel
              - 0.08 * psy.Fatigue;

            return Bx.Clamp01(u);
        }
    }
}
