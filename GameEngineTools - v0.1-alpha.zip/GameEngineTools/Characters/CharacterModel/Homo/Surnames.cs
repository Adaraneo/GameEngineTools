﻿// Surnames.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Homo
{
    public class Surname
    {
        public string Female { get; set; }
        public string Male { get; set; }
    }
}
