﻿// BehaviorOptionAttribute.cs
// Copyright (c) 50PSoftware

[AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = false)]
public sealed class BehaviorOptionAttribute : Attribute
{
    public bool Enabled { get; }
    public BehaviorOptionAttribute(bool enabled = true) => Enabled = enabled;
}

