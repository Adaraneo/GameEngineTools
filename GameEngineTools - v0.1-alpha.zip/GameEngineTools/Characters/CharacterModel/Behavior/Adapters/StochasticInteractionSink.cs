﻿// StochasticInteractionSink.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Adapters
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Relationships;
    using GameEngineTools.World.Utils.Time;

    public sealed class StochasticInteractionSink : IInteractionSink
    {
        // základní „úspěšnosti“ pro typy interakcí (zbytek padá na 0.9)
        private readonly Dictionary<InteractionType, double> _baseP =
            new()
            {
                [InteractionType.Compliment] = 0.9,
                [InteractionType.SpendTime] = 0.88,
                [InteractionType.Flirt] = 0.85,
                [InteractionType.Cooperation] = 0.9,
                [InteractionType.Honesty] = 0.92
            };

        private readonly IInteractionSink _inner;
        private readonly int _maxJitterSec;
        private readonly Random _rng = Random.Shared;

        public StochasticInteractionSink(IInteractionSink inner, int maxJitterSec = 90)
        { _inner = inner; _maxJitterSec = Math.Max(5, maxJitterSec); }

        public void Enqueue(InteractionEvent e)
        {
            if (!e.Context.HasValue) return;
            var c = e.Context!.Value;

            double baseP = _baseP.TryGetValue(e.Type, out var p) ? p : 0.9;
            // kontextová modulace šance, bez sahání do behavior option
            double pass = baseP
                          * (0.85 + 0.30 * c.Privacy)
                          * (0.90 + 0.20 * (1 - c.SocialAudience))
                          * (0.90 + 0.20 * Math.Max(0f, c.EmotionalTone))
                          * 1.0; // místo pro další modifikátory

            pass = Math.Clamp(pass, 0.25, 0.99);
            if (_rng.NextDouble() >= pass) return; // misfire – event se „nestal“

            // jitter času – víc šumu na veřejnosti / v nízkém soukromí
            double scale = 1.0 + (c.SocialAudience + (1 - c.Privacy));
            var jitter = WTimeSpan.FromSeconds(_rng.NextDouble() * _maxJitterSec * scale);

            // posuň čas a pošli dál
            e.When = e.When + jitter;
            _inner.Enqueue(e);
        }
    }
}
