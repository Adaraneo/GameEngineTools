﻿// BehaviorMemory.cs
// Copyright (c) 50PSoftware

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using GameEngineTools.World.Utils.Time;

namespace GameEngineTools.Characters.CharacterModel.Behavior.Engine
{
    public sealed class BehaviorMemory
    {
        private readonly Dictionary<BehaviorType, (int count, WDateTime last)> _recent = new();
        private readonly Random _rng = new Random();

        // zavolej po každé Apply(option)
        public void Bump(BehaviorType type, WDateTime now)
        {
            if (_recent.TryGetValue(type, out var t))
                _recent[type] = (Math.Min(t.count + 1, 8), now);
            else
                _recent[type] = (1, now);
        }

        // 0..1 jak moc jsme točili tuto volbu poslední dobou
        public double RecentFrequency(BehaviorType type)
        {
            if (!_recent.TryGetValue(type, out var t)) return 0.0;
            // jednoduchý decay přes čas (pár hodin)
            double hours = Math.Max(0.0, (WDateTime.Now - t.last).TotalHours);
            double decay = Math.Min(1.0, hours / 6.0); // za 6h spadne vliv na 0
            double norm = Math.Clamp(t.count / 6.0, 0.0, 1.0);
            return Math.Clamp(norm * (1.0 - decay), 0.0, 1.0);
        }

        public double SmallNoise() => (_rng.NextDouble() - 0.5) * 0.02; // ±0.01

        private readonly record struct PrefKey(BehaviorType Type, Guid? TargetId);
        private sealed class PrefEntry { public double Ema; public int Samples; public WDateTime Last; }
        private readonly ConcurrentDictionary<PrefKey, PrefEntry> _prefs = new();
        private const double Alpha = 0.30; // váha nového signálu v EMA

        /// <summary>Zapíše výsledek chování jako reward ~[-1..+1].</summary>
        public void ReportOutcome(BehaviorType type, Guid? targetId, double reward, WDateTime when)
        {
            var key = new PrefKey(type, targetId);
            var e = _prefs.GetOrAdd(key, _ => new PrefEntry { Ema = reward, Samples = 0, Last = when });
            e.Ema = (1 - Alpha) * e.Ema + Alpha * reward;
            e.Samples++;
            e.Last = when;
        }

        /// <summary>Preferenční posun pro scoring (kladný → navýší utilitu).</summary>
        public double Preference(BehaviorType type, Guid? targetId)
        {
            if (_prefs.TryGetValue(new PrefKey(type, targetId), out var e)) return e.Ema;
            if (_prefs.TryGetValue(new PrefKey(type, null), out var g)) return 0.5 * g.Ema; // fallback na obecný vzor
            return 0.0;
        }
    }
}
