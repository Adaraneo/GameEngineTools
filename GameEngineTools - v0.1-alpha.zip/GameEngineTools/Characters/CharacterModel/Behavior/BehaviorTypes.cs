﻿// BehaviorTypes.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior
{
    // Typy chování – mapují se (když dává smysl) na InteractionType
    public enum BehaviorType
    {
        None = 0,
        PoliteNod,
        GreetWarmly,
        AskOpenQuestion,
        OfferHelp,
        HonestDisclosureLight,
        ComplimentLight,
        Apologize,
        Cooperate,
        KeepDistance,
        Withdraw,
        SetBoundary,
        Refuse,
        Retort,
        FlirtLight,
        FlirtBold,
        SuggestSharedActivity,
        Confront,
        AskForConsent,
        DeclareFeelings,
        Kiss,
        InitiateIntimacy,
        ChangeTopic,
        Cuddle,
        Invite,
        CheckIn,
        BreakPromise,
        Insult,
        InitiateIntimacyBold,
        Lie,
        Aggression,
        KissLight,
        InitiateIntimacySoft,
        KissDeep,
        UndermineInPublic,
        AskForPersonalDisclosureDeep,
        SelfDisclosureDeep,
        ReproachInPublic,
        LongHug,
        AftercareCuddle,
        ReturnCompliment,
        AcknowledgePraise,
        DeescalateConflict,
        DeferReply,
        GracefulExit,
        FriendChat,
        InviteSharedActivity,
        InsultDirect,
        LieWhite,
        RefuseHelp,
        DeflectQuestion
    }

    // Základní typy situací – můžeš libovolně rozšířit
    public enum SituationType
    {
        ChanceEncounter,   // náhodné setkání
        FriendChat,        // přátelský rozhovor
        Conflict,          // spor/napětí
        RequestHelp,       // někdo žádá pomoc
        PraiseReceived,    // přijetí pochvaly
        InsultReceived,    // přijetí urážky
        GroupSetting,      // skupinová scéna
        OneOnOnePrivate,   // soukromý 1:1
        DateLike,          // „randící“ kontext
        WorkTask,          // úkol/práce
        Threat,             // ohrožení/riziko
        Church,
        PublicSquare
    }
}
