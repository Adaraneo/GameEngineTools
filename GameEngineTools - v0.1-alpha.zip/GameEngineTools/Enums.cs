﻿// Enums.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools
{
    #region Homo

    public enum GenusType
    { Male, Female };

    #region Relationship ortogonal enums

    /// <summary>
    /// Druh sociální vazby mezi A→B
    /// </summary>
    public enum BondKind
    {
        Neutral,    // default
        Friend,
        Romantic,
        Family,
        Rival,
        Enemy
    }

    // Fáze/blízkost (rename z RelationshipStageType)
    public enum BondStage
    {
        Stranger, Familiar, Friend, Intimate,
        Romantic,
        Acquaintance
    }

    // Doplňkové tagy (to, co dřív „přebývalo“ v RelationshipType)
    [Flags]
    public enum BondTag
    {
        None = 0,
        Acquaintance = 1 << 0,   // známost
        Close = 1 << 1,   // „close friend“
        Best = 1 << 2,   // „best friend“
        Partner = 1 << 3,   // romantický partner
        Ex = 1 << 4,   // ex-romantická vazba
        Colleague = 1 << 5,
        GuildMate = 1 << 6,
        Commander = 1 << 7,
        Family = 1 << 8,
        Crush = 1 << 9,   // zamilovanost
    }

    // Civilní stav osoby (náhrada za RelationshipStatusType; patří na Person)
    public enum CivilStatus
    {
        Single, InRelationship, Engaged, Married, Divorced, Widowed
    }

    public enum KinshipRole
    {
        Unknown, Father, Mother, Brother, Sister, Son, Daughter, Uncle, Aunt,
        Nephew, Niece, Cousin, Grandfather, Grandmother, Grandson, Granddaughter,
        Husband,
        Wife,
        Partner
    }

    #endregion Relationship ortogonal enums

    public enum StadiumType
    { Baby, Child, Teenager, Adult, MidAged, Old };

    public enum StatusType
    { Unborn, Alive, Dead };

    #endregion Homo

    #region Magic

    public enum MagicType
    { Water, Air, Fire, Earth, Unknown }

    #endregion Magic
}
