﻿// RelationshipManager.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships
{
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using GameEngineTools.Characters.CharacterModel.Behavior;
    using GameEngineTools.Characters.CharacterModel.Events;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Logging;
    using GameEngineTools.World.Core.Time;
    using GameEngineTools.World.Utils.Time;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Centrální správa vztahů mezi postavami.
    /// </summary>
    public sealed partial class RelationshipManager
    {
        private readonly ILogger<RelationshipManager> _log;
        public RelationshipManager(IClock clock, ILogger<RelationshipManager> log, IEventBus bus)
        {
            AttachClock(clock);
            _log = log;
            AttachEventBus(bus);
        }

        public void AttachClock(IClock clock) => this.clock = clock;

        private readonly ConcurrentDictionary<(IHuman from, IHuman to), Relationship> _relationships = new();

        private enum KinshipCategory
        { None, Parent, Child, Sibling, Spouse }

        private IEventBus? _bus;
        public void AttachEventBus(IEventBus bus) => _bus = bus;

        // Epsilon pro „viditelnou“ změnu
        private const float DeltaEpsilon = 0.001f;

        private static KinshipCategory ToCategory(KinshipRole role) => role switch
        {
            KinshipRole.Father or KinshipRole.Mother => KinshipCategory.Parent,
            KinshipRole.Son or KinshipRole.Daughter => KinshipCategory.Child,
            KinshipRole.Brother or KinshipRole.Sister => KinshipCategory.Sibling,
            KinshipRole.Husband or KinshipRole.Wife => KinshipCategory.Spouse,
            _ => KinshipCategory.None
        };

        private (double likeBias, double trustBias, double attractionBias, double closenessBias) ComputeBiases(IHuman a, IHuman b)
        {
            // Big Five 0..1 (pokud máš jinak, uprav)
            double Oa = a.Personality.BigFive[BigFiveTrait.Openness];
            double Ca = a.Personality.BigFive[BigFiveTrait.Conscientiousness];
            double Ea = a.Personality.BigFive[BigFiveTrait.Extraversion];
            double Aa = a.Personality.BigFive[BigFiveTrait.Agreeableness];
            double Na = a.Personality.BigFive[BigFiveTrait.Neuroticism];

            // Lehce zohledníme i cílovou osobu
            double Ab = b.Personality.BigFive[BigFiveTrait.Agreeableness];
            double Eb = b.Personality.BigFive[BigFiveTrait.Extraversion];

            // Heuristiky (držím střed 0.5, rozpětí cca ±0.2)
            double likeBias = Clamp(0.5 + 0.25 * (Aa - 0.5) + 0.10 * (Ab - 0.5));
            double trustBias = Clamp(0.5 + 0.25 * (Ca - 0.5) - 0.20 * (Na - 0.5));
            double attractionBias = Clamp(0.5 + 0.20 * (Oa - 0.5) + 0.15 * (Ea - 0.5) + 0.05 * (Eb - 0.5));
            double closenessBias = Clamp(0.5 + 0.20 * (Ea - 0.5) + 0.15 * (Aa - 0.5) - 0.15 * (Na - 0.5));

            return (likeBias, trustBias, attractionBias, closenessBias);

            double Clamp(double v) => Math.Max(0.0, Math.Min(1.0, v));
        }

        private KinshipRole GetReciprocalKinship(IHuman a, IHuman b, KinshipRole role) => role switch
        {
            KinshipRole.Father => b.Genus == GenusType.Female ? KinshipRole.Daughter : KinshipRole.Son,
            KinshipRole.Mother => b.Genus == GenusType.Female ? KinshipRole.Daughter : KinshipRole.Son,
            KinshipRole.Son => a.Genus == GenusType.Female ? KinshipRole.Mother : KinshipRole.Father,
            KinshipRole.Daughter => a.Genus == GenusType.Female ? KinshipRole.Mother : KinshipRole.Father,
            KinshipRole.Brother => b.Genus == GenusType.Female ? KinshipRole.Sister : KinshipRole.Brother,
            KinshipRole.Sister => b.Genus == GenusType.Female ? KinshipRole.Sister : KinshipRole.Brother,
            KinshipRole.Husband => KinshipRole.Wife,
            KinshipRole.Wife => KinshipRole.Husband,
            KinshipRole.Partner => KinshipRole.Partner,
            _ => KinshipRole.Unknown
        };

        /// <summary>
        /// Volitelná validace vztahu mezi dvěma postavami.
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="newRole"></param>
        /// <exception cref="InvalidOperationException"></exception>
        private void ValidateKinship(IHuman a, IHuman b, KinshipRole newRole)
        {
            if (newRole is KinshipRole.Father or KinshipRole.Mother)
                if (a.Age <= b.Age)
                    throw new InvalidOperationException("Parent must be older than child.");

            if (TryGetRelationship(a, b, out var existing) && existing is not null)
            {
                var oldRole = existing.Kinship;
                if (oldRole != KinshipRole.Unknown && oldRole != newRole)
                {
                    var oldCat = ToCategory(oldRole);
                    var newCat = ToCategory(newRole);

                    // Povolit změnu role uvnitř stejné kategorie (např. Brother <-> Sister)
                    if (oldCat != newCat)
                        throw new InvalidOperationException($"Kinship conflict: {oldRole} vs {newRole}");
                }

                // Ochrana proti romantice mezi blízkými příbuznými
                var cat = ToCategory(newRole);
                if (cat is KinshipCategory.Parent or KinshipCategory.Child or KinshipCategory.Sibling)
                {
                    if (existing.Kind == BondKind.Romantic || (existing.Tags & BondTag.Partner) != 0)
                        throw new InvalidOperationException("Romance not allowed for close kin.");
                }
            }
        }

        internal Relationship EnsureRelationship(IHuman from, IHuman to)
        {
            if (!_relationships.TryGetValue((from, to), out var relationship))
            {
                relationship = new Relationship(from, to);
                var (likeBias, trustBias, attractionBias, closenessBias) = ComputeBiases(from, to);
                relationship.SetBiases(likeBias, trustBias, attractionBias, closenessBias);
                _relationships[(from, to)] = relationship;
            }

            return relationship;
        }

        internal IEnumerable<(IHuman To, Relationship Rel)> EnumerateFrom(IHuman from)
        {
            foreach (var kv in _relationships)
            {
                if (ReferenceEquals(kv.Key.from, from))
                    yield return (kv.Key.to, kv.Value);
            }
        }

        /// <summary>
        /// Vráti roli A→B
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        internal KinshipRole GetKinship(IHuman a, IHuman b) => TryGetRelationship(a, b, out var r) ? r.Kinship : KinshipRole.Unknown;

        private IClock clock;

        /// <summary>
        /// Nastaví kinship obousměrně a bezpečně
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="role"></param>
        /// <exception cref="ArgumentNullException"></exception>
        /// <exception cref="InvalidOperationException"></exception>
        internal void SetKinship(IHuman a, IHuman b, KinshipRole role)
        {
            if (a == null || b == null) throw new ArgumentNullException();
            if (ReferenceEquals(a, b)) throw new InvalidOperationException("Self-kinship is not allowed.");
            ValidateKinship(a, b, role);

            var ab = GetRelationship(a, b);
            var ba = GetRelationship(b, a);

            ab.SetKinship(role);

            var reciprocal = GetReciprocalKinship(a, b, role);
            ba.SetKinship(reciprocal);
            _bus?.PublishAsync(new FamilyChangedEvent(a.DNA, b.DNA, "Changed")); // nebo "Remove" podle tvé větve změny
            _log.RelFamilyChanged(clock.Now.ToString("O"), a.DNA.ToString(), b.DNA.ToString(), "Changed");
        }

        private readonly struct RelSnapshot
        {
            public readonly float Like;
            public readonly float Trust;
            public readonly float Attraction;
            public readonly float Closeness;
            public readonly BondStage Stage;

            public RelSnapshot(float like, float trust, float attraction, float closeness, BondStage stage)
            {
                Like = like; Trust = trust; Attraction = attraction; Closeness = closeness; Stage = stage;
            }
        }

        private static RelSnapshot Snapshot(Relationship rel)
            => new(
                like: rel.Liking,
                trust: rel.Trust,
                attraction: rel.Attraction,
                closeness: rel.Closeness,
                stage: rel.Stage
            );

        private void PublishDiffs(IHuman from, IHuman to, RelSnapshot before, RelSnapshot after)
        {
            if (_bus is null) return;

            void changed(string changeType, float oldV, float newV)
            {
                if (MathF.Abs(newV - oldV) > DeltaEpsilon)
                    _bus.PublishAsync(new RelationshipChangedEvent(from.DNA, to.DNA, changeType, oldV, newV));
            }

            changed("Liking", before.Like, after.Like);
            changed("Trust", before.Trust, after.Trust);
            changed("Attraction", before.Attraction, after.Attraction);
            changed("Closeness", before.Closeness, after.Closeness);

            if (before.Stage != after.Stage)
                _bus.PublishAsync(new RelationshipThresholdReachedEvent(from.DNA, to.DNA, after.Stage.ToString()));
        }

        public void Decay(IHuman from, IHuman to, WTimeSpan deltaTime)
        {
            if (!TryGetRelationship(from, to, out var relationship) || relationship is null) return;

            var before = Snapshot(relationship);
            relationship.DecayAxes(clock, deltaTime);
            var after = Snapshot(relationship);

            PublishDiffs(from, to, before, after);

            _log.RelDecayApplied(clock.Now.ToString("O"), from.DNA.ToString(), to.DNA.ToString(), deltaTime.TotalSeconds,
                before.Like, after.Like,
                before.Trust, after.Trust,
                before.Attraction, after.Attraction,
                before.Closeness, after.Closeness,
                before.Stage.ToString(), after.Stage.ToString());
            if (before.Stage != after.Stage)
                _log.RelStageChanged(clock.Now.ToString("O"), from.DNA.ToString(), to.DNA.ToString(),
                    before.Stage.ToString(), after.Stage.ToString());
        }

        /// <summary>
        /// Umožní aplikovat interakci mezi dvěma postavami.
        /// </summary>
        public void ApplyInteraction(IHuman from, IHuman to, InteractionType interaction, float baseEffect = 1f, InteractionContext? context = null)
        {
            var mag = RelationshipTools.GetInteractionMagnitude(interaction);
            var relationship = GetRelationship(from, to);
            var before = Snapshot(relationship);

            relationship.ApplyInteraction(clock, interaction, mag * baseEffect, context ?? InteractionContexts.BuildContextFor(interaction));

            var after = Snapshot(relationship);

            PublishDiffs(from, to, before, after);
            _bus?.PublishAsync(new InteractionAppliedEvent(from.DNA, to.DNA, interaction, clock.Now, context));

            var when = clock.Now;
            using(_log.BeginScope(new Dictionary<string, object>()
            {
                ["from"] = from.DNA,
                ["to"] = to.DNA,
                ["type"] = interaction.ToString()
            }))
            {
                _log.RelInteractionApplied(when.ToString("O"), from.DNA.ToString(), to.DNA.ToString(), interaction.ToString(), mag,
                    before.Like, after.Like,
                    before.Trust, after.Trust,
                    before.Attraction, after.Attraction,
                    before.Closeness, after.Closeness,
                    before.Stage.ToString(), after.Stage.ToString());
            }

            if (before.Stage != after.Stage)
                _log.RelStageChanged(when.ToString("O"), from.DNA.ToString(), to.DNA.ToString(),
                    before.Stage.ToString(), after.Stage.ToString());
        }

        /// <summary>
        /// Vrátí hodnoty vztahu oběma směry jako text.
        /// </summary>
        public string DescribeMutualRelationship(IHuman a, IHuman b)
        {
            var (ab, ba) = GetMutualRelationship(a, b);
            return $"{ab}\n{ba}";
        }

        /// <summary>
        /// Vrátí všechny existující vztahy.
        /// </summary>
        public IEnumerable<Relationship> GetAllRelationships() => _relationships.Values;

        /// <summary>
        /// Získá vztahy oběma směry mezi dvěma postavami.
        /// </summary>
        public (Relationship fromTo, Relationship toFrom) GetMutualRelationship(IHuman a, IHuman b)
        {
            return (GetRelationship(a, b), GetRelationship(b, a));
        }

        /// <summary>
        /// Získá vztah mezi dvěma postavami. Pokud neexistuje, vytvoří ho.
        /// </summary>
        public Relationship GetRelationship(IHuman from, IHuman to) => EnsureRelationship(from, to);

        /// <summary>
        /// Zjistí, zda existuje vztah mezi dvěma postavami.
        /// </summary>
        public bool HasRelationship(IHuman from, IHuman to) => _relationships.ContainsKey((from, to));

        /// <summary>
        /// Odebere konkrétní vztah (např. reset).
        /// </summary>
        public bool RemoveRelationship(IHuman from, IHuman to) => _relationships.Remove((from, to), out var rel);

        public bool TryGetRelationship(IHuman from, IHuman to, out Relationship? relationship)
        {
            return _relationships.TryGetValue((from, to), out relationship);
        }
    }
}
