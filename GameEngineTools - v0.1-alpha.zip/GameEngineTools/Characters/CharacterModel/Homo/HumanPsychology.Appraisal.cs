﻿// HumanPsychology.Appraisal.cs
// Copyright (c) 50PSoftware
// Appraisal + emoce (epizody)

namespace GameEngineTools.Characters.Homo
{
    using System;
    using System.Collections.Generic;
    using System.Text.Json.Serialization;

    public enum EmotionType
    { Joy, Sadness, Anger, Fear, Shame, Pride, Gratitude, Relief }

    public record EmotionEpisode(EmotionType Type, double Intensity, double HalfLifeHours, Guid Source);

    public partial class HumanPsychology
    {
        private readonly List<EmotionEpisode> activeEmotions = new();

        private void DecayEmotions(double dtHours)
        {
            for (int i = activeEmotions.Count - 1; i >= 0; i--)
            {
                var e = activeEmotions[i];
                double decay = Math.Pow(0.5, dtHours / e.HalfLifeHours);
                double newIntensity = e.Intensity * decay;
                if (newIntensity < 0.05)
                    activeEmotions.RemoveAt(i);
                else
                    activeEmotions[i] = e with { Intensity = newIntensity };
            }
        }

        /// <summary>Aktivní emoční epizody s rozpadem.</summary>
        [JsonIgnore]
        public IReadOnlyList<EmotionEpisode> ActiveEmotions => activeEmotions.AsReadOnly();

        /// <summary>Přiřaď novou emoční epizodu.</summary>
        public void ApplyEmotion(EmotionType type, double intensity, TimeSpan halfLife, Guid? source = null)
        {
            activeEmotions.Add(new EmotionEpisode(type,
                Math.Clamp(intensity, 0, 1),
                halfLife.TotalHours,
                source ?? Guid.Empty));
        }

        /// <summary>Appraisal jednoduché události → emoce.</summary>
        public void Appraise(double valence, double control, double certainty)
        {
            // valence −1..+1, control 0..1, certainty 0..1
            if (valence > 0.4)
                ApplyEmotion(EmotionType.Joy, valence, TimeSpan.FromHours(2));
            else if (valence < -0.4 && control < 0.3)
                ApplyEmotion(EmotionType.Fear, -valence, TimeSpan.FromHours(3));
            else if (valence < -0.4 && control > 0.6)
                ApplyEmotion(EmotionType.Anger, -valence, TimeSpan.FromHours(2));
        }
    }
}
