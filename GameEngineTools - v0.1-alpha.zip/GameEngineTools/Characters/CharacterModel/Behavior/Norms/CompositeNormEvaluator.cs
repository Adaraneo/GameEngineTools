﻿// CompositeNormEvaluator.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Norms
{
    public sealed class CompositeNormEvaluator : INormEvaluator
    {
        private readonly IReadOnlyList<INormEvaluator> _parts;
        public CompositeNormEvaluator(params INormEvaluator[] parts) { _parts = parts; }

        public double Evaluate(BehaviorType type, in BehaviorContext ctx)
        {
            double sum = 0.0;
            foreach (var p in _parts) sum += p.Evaluate(type, in ctx);
            return sum < -1.0 ? -1.0 : sum; // bezpečný clamp
        }
    }
}

