﻿// BehaviorServicesExtensions.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior
{
    using System.Linq;
    using System.Reflection;
    using GameEngineTools.Characters.CharacterModel.Behavior.Adapters;
    using GameEngineTools.Characters.CharacterModel.Behavior.Engine;
    using GameEngineTools.Characters.CharacterModel.Behavior.Norms;
    using GameEngineTools.Characters.CharacterModel.Behavior.Planning;
    using GameEngineTools.Characters.CharacterModel.Events;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.GameObjects;
    using GameEngineTools.Config;
    using GameEngineTools.World.Encounters;
    using GameEngineTools.World.Encounters.Scenarios;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    public static class BehaviorServicesExtensions
    {
        public static IServiceCollection AddDefaultBehaviorOptions(this IServiceCollection services)
        {
            foreach (var opt in BehaviorRegistry.Default)
                services.AddSingleton<IBehaviorOption>(opt);
            return services;
        }

        public static IServiceCollection AddBehaviorSimulation(this IServiceCollection services, IConfiguration cfg)
        {
            services.AddBehaviorSimulation();
            services.AddOptions<BehaviorTuningOptions>()
                .Bind(cfg.GetSection("BehaviorTuningOptions"))
                .ValidateOnStart()
                .PostConfigure(BehaviorScoring.SetTuning);

            services.AddOptions<BehaviorLoopOptions>().Bind(cfg.GetSection("BehaviorLoopOptions")).ValidateOnStart();

            return services;
        }

        /// <summary>
        /// Zaregistruje všechny konkrétní třídy, které implementují IBehaviorOption,
        /// z daných assemblies. Lze filtrovat/přeskakovat kurátorovaný seznam.
        /// </summary>
        public static IServiceCollection AddBehaviorOptionsFromAssemblies(
            this IServiceCollection services,
            IEnumerable<Assembly>? assemblies = null,
            IEnumerable<Type>? excludeTypes = null,
            Func<Type, bool>? predicate = null,
            bool requireAttributeGate = false)
        {
            var optionType = typeof(IBehaviorOption);
            var asmList = (assemblies?.Any() == true)
                ? assemblies!.Distinct().ToArray()
                : new[] { typeof(BehaviorEngine).Assembly }; // default: tahle assembly

            var excluded = new HashSet<Type>(excludeTypes ?? Enumerable.Empty<Type>());
            var seen = new HashSet<Type>();

            foreach (var asm in asmList)
            {
                foreach (var t in asm.GetTypes())
                {
                    if (seen.Contains(t)) continue;
                    if (!optionType.IsAssignableFrom(t)) continue;
                    if (t.IsAbstract || t.IsInterface || t.IsGenericTypeDefinition) continue;
                    if (excluded.Contains(t)) continue;

                    if (requireAttributeGate)
                    {
                        var gate = t.GetCustomAttribute<BehaviorOptionAttribute>();
                        if (gate is null || gate.Enabled is false) continue;
                    }

                    if (predicate != null && !predicate(t)) continue;

                    // DI si zavolá ctor sám – pokud má dependencies, musí být registrované.
                    services.AddSingleton(typeof(IBehaviorOption), t);
                    seen.Add(t);
                }
            }

            return services;
        }

        private static IServiceCollection AddBehaviorSimulation(
            this IServiceCollection services)
        {
            // Core
            services.AddSingleton<BehaviorEngine>();
            services.AddSingleton<INormEvaluator>(sp =>
            {
                var simple = new SimpleNormEvaluator();
                var placeAware = new PlaceAwareNormEvaluator();
                var sitauational = new ArchetypeNormEvaluator();
                return new CompositeNormEvaluator(simple, placeAware, sitauational);
            });
            services.AddSingleton<BehaviorCooldowns>();
            services.AddSingleton<IRelationshipSnapshotProvider, RelationshipSnapshotAdapter>();

            services.AddSingleton<IGoalSignalProvider, SimpleGoalSignalProvider>();

            services.AddSingleton<EventBusInteractionSink>();
            #region Keyed

            // base sink
            services.AddKeyedSingleton<IInteractionSink>("base", (sp, key) => sp.GetRequiredService<EventBusInteractionSink>());

            // stochastic -> base
            services.AddKeyedSingleton<IInteractionSink>("stochastic", (sp, key) =>
                new StochasticInteractionSink(sp.GetRequiredKeyedService<IInteractionSink>("base"), 90));

            services.AddSingleton<IInteractionSink>(sp => sp.GetRequiredKeyedService<IInteractionSink>("stochastic"));
            #endregion

            services.AddSingleton<GameObjectsPeopleProvider>();
            services.AddSingleton<IPeopleProvider>(sp => sp.GetRequiredService<GameObjectsPeopleProvider>());


            services.AddBehaviorOptionsFromAssemblies(
                new[] { typeof(BehaviorEngine).Assembly });

            // Encounters & místa
            services.AddSingleton<PlaceRegistry>();
            services.AddSingleton<ScenarioBook>();
            // Roster -> presence provider (z NPPC.People). Až budeš mít World layer, vyměň tento provider.
            services.AddSingleton<IWorldPresenceProvider>(sp =>
            new StandalonePresenceProvider(
                sp.GetRequiredService<GameObjectsPeopleProvider>(),
                sp.GetRequiredService<PlaceRegistry>()));
            services.AddSingleton<EncounterService>();
            services.AddSingleton<IEncounterSource, EncounterSourceAdapter>();

            // Planning
            services.AddSingleton<ActivePlans>();
            services.AddSingleton<PlanEngine>();

            //TODO: Add behavior plans like:
            services.AddSingleton<IBehaviorPlan, Behavior.Planning.RepairPlan>();
            services.AddSingleton<IBehaviorPlan, Behavior.Planning.AffiliationPlan>();
            services.AddSingleton<IBehaviorPlan, Behavior.Planning.DateInvitePlan>();

            // Orchestrátor – vlastní smyčka
            services.AddHostedService<BehaviorOrchestratorHostedService>();

            services.AddSingleton<BehaviorOutcomeListener>();

            services.AddSingleton<BehaviorCandidateGenerator>();
            return services;
        }

    }
}
