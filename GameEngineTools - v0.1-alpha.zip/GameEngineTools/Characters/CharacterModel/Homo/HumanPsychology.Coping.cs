﻿// HumanPsychology.Coping.cs
// Copyright (c) 50PSoftware
// Coping styles & aplikace

namespace GameEngineTools.Characters.Homo
{
    using GameEngineTools.Characters.CharacterModel.Homo;

    public enum CopingStyle
    { ProblemFocused, EmotionFocused, Avoidance, SeekSupport }

    public partial class HumanPsychology
    {
        /// <summary>Dominantní coping styl (baseline).</summary>
        public CopingStyle CopingPreference { get; set; } = CopingStyle.ProblemFocused;

        /// <summary>Aplikuje coping – mírné změny stresu/anxiety podle stylu.</summary>
        public void ApplyCoping(CopingStyle style, double dtHours)
        {
            switch (style)
            {
                case CopingStyle.ProblemFocused:
                    StressLevel = Clamp01(StressLevel - 0.05 * dtHours);
                    break;

                case CopingStyle.EmotionFocused:
                    Anxiety = Clamp01(Anxiety - 0.04 * dtHours);
                    break;

                case CopingStyle.Avoidance:
                    Fatigue = Clamp01(Fatigue - 0.02 * dtHours);
                    break;

                case CopingStyle.SeekSupport:
                    SocialDrive = Clamp01(SocialDrive + 0.05 * dtHours);
                    break;
            }
        }

        /// <summary>Zvolí coping styl podle osobnosti a appraisal výsledku.</summary>
        public CopingStyle SelectCoping(double control, Personality? p = null)
        {
            if (p != null)
            {
                var snap = ReadPersonality(p);
                // vyšší svědomitost → spíš problem-focused
                if (snap.Conscientiousness > 0.6 && control > 0.4)
                    return CopingStyle.ProblemFocused;
                // vyšší přívětivost → seek support
                if (snap.Agreeableness > 0.6)
                    return CopingStyle.SeekSupport;
                // vyšší neuroticismus → emotion-focused
                if (snap.Neuroticism > 0.6)
                    return CopingStyle.EmotionFocused;
            }
            return CopingPreference;
        }
    }
}
