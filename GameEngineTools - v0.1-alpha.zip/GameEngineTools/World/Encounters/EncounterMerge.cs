﻿// EncounterMerge.cs
// Copyright (c) 50PSoftware

using System;
using System.Collections.Generic;
using System.Linq;
using GameEngineTools.World.Utils.Time;

namespace GameEngineTools.World.Encounters
{
    public static class EncounterMerge
    {
        /// <summary>
        /// Slije forced a organic, odstraní duplicity okolo stejného času/osob/místa.
        /// </summary>
        /// <param name="organic"></param>
        /// <param name="forced"></param>
        /// <param name="dedupWindow"></param>
        /// <param name="forcedWins"></param>
        /// <returns></returns>
        public static List<Encounter> Merge(
            IEnumerable<Encounter> organic,
            IEnumerable<Encounter> forced,
            WTimeSpan dedupWindow,
            bool forcedWins = true)
        {
            // indexuj forced podle (pair, timebucket, place) → forced má přednost
            var bucket = new Dictionary<(Guid, Guid, long, Guid?), Encounter>();

            static (Guid lo, Guid hi) Pair(Guid a, Guid b) => a.CompareTo(b) < 0 ? (a, b) : (b, a);
            static long Tkey(WDateTime t, WTimeSpan window) => (long)Math.Floor(t.Ticks / (double)window.Ticks);

            foreach (var f in forced)
            {
                var key = (Pair(f.A.DNA, f.B.DNA).Item1, Pair(f.A.DNA, f.B.DNA).Item2, Tkey(f.When, dedupWindow), f.PlaceId);
                bucket[key] = f with { Source = EncounterSource.Forced }; // forced má prim
            }

            var merged = new List<Encounter>(bucket.Values);

            foreach (var o in organic)
            {
                var key = (Pair(o.A.DNA, o.B.DNA).Item1, Pair(o.A.DNA, o.B.DNA).Item2, Tkey(o.When, dedupWindow), o.PlaceId);
                if (bucket.ContainsKey(key))
                {
                    if (!forcedWins) merged.Add(o); // výjimečně povolit oba
                    continue;
                }
                merged.Add(o);
            }

            // stabilní pořadí: čas, Forced před Organic, fallback podle tagu
            return merged.OrderBy(e => e.When)
                         .ThenByDescending(e => e.Source)
                         .ThenBy(e => e.Tag ?? "")
                         .ToList();
        }
    }
}
