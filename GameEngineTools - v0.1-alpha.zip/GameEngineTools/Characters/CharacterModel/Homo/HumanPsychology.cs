﻿// HumanPsychology.cs
// Copyright (c) 50PSoftware
// Hlavní partial: interocepce + hysterese + napojení na config a nelinearity.

namespace GameEngineTools.Characters.Homo
{
    using System;
    using System.Text.Json.Serialization;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Config;
    using GameEngineTools.World.Utils.Time;

    public partial class HumanPsychology
    {
        private HysteresisGate highFatigueGate;

        private HysteresisGate highStressGate;

        private static double GetLocalHour()
        {
            var now = WDateTime.Now;
            return now.Hour + now.Minute / 60.0;
        }

        private static double SafeGet(Personality p, BigFiveTrait traitType)
        {
            try { return Math.Clamp(p.GetBigFiveTrait(traitType), 0, 1); } catch { return 0.5; }
        }

        /// <summary>
        /// Čtení rysů osobnosti (0..1) z tvé třídy Personaliy – uprav volání podle svého API.
        /// </summary>
        internal PersonalitySnapshot ReadPersonality(Personality p) => new PersonalitySnapshot
        {
            Openness = SafeGet(p, BigFiveTrait.Openness),
            Conscientiousness = SafeGet(p, BigFiveTrait.Conscientiousness),
            Extraversion = SafeGet(p, BigFiveTrait.Extraversion),
            Agreeableness = SafeGet(p, BigFiveTrait.Agreeableness),
            Neuroticism = SafeGet(p, BigFiveTrait.Neuroticism)
        };

        internal struct PersonalitySnapshot
        {
            public double Openness, Conscientiousness, Extraversion, Agreeableness, Neuroticism;
        }

        public HumanPsychology()
        {
            ApplyConfig(PsychophysConfig.Default());
        }

        public double Aggression { get; set; } = 0.05;

        public double Anxiety { get; set; } = 0.15;

        public double Arousal { get; set; } = 0.50;

        [JsonIgnore] public double ArousalDecayPerHour => 0.12;

        //  0..1
        public double Confidence { get; set; } = 0.55;

        [JsonIgnore] public PsychophysConfig Config { get; private set; } = PsychophysConfig.Default();

        public double Curiosity { get; set; } = 0.55;

        public double Fatigue { get; set; } = 0.20;

        [JsonIgnore] public double FatiguePerHighExertionHour => 0.35;

        public double Focus { get; set; } = 0.60;

        public double Hunger { get; set; } = 0.20;

        // --- NOVĚ: Interocepční citlivost (0..1) ---
        /// <summary>Jak silně psychika reaguje na stavy těla.</summary>
        public double InteroceptionSensitivity { get; set; } = 0.60;

        [JsonIgnore] public bool IsHighFatigue => highFatigueGate.State;

        // --- Hysterese stavy ---
        [JsonIgnore] public bool IsHighStress => highStressGate.State;

        // --- Nové afektivní/homeostatické proměnné ---
        public double Mood { get; set; } = 0.10;

        [JsonIgnore] public double MoodReversionPerHour => 0.08 * (0.5 + Resilience);

        public double Motivation { get; set; } = 0.60;

        public double Pain { get; set; } = 0.00;

        public double Resilience { get; set; } = 0.60;

        // −1..+1
        public double SelfControl { get; set; } = 0.55;

        public double SleepDebtHours { get; set; } = 0.0;

        public double SocialDrive { get; set; } = 0.50;

        // --- Parametry dynamiky (základ) ---
        [JsonIgnore] public double StressDecayPerHour => 0.10 * (0.5 + Resilience);

        // --- Původní kanály ---
        public double StressLevel { get; set; } = 0.15;

        public double Thirst { get; set; } = 0.15;

        // === Circadián (beze změny, jen šum přidán) ===
        public void ApplyCircadianModulation(HumanPhysiology phys, double localHour, double dtHours)
        {
            (double s, double e) = phys.Chronotype switch
            {
                SleepChronotype.Lark => (7, 15),
                SleepChronotype.Neutral => (10, 18),
                SleepChronotype.Owl => (13, 21),
                _ => (10, 18)
            };

            bool inPeak = (s <= e) ? (localHour >= s && localHour <= e)
                                   : (localHour >= s || localHour <= e);

            if (inPeak)
            {
                Arousal = Clamp01(Arousal + 0.06 * dtHours + SmallNoise(Config.NoiseSigma));
                Fatigue = Clamp01(Fatigue - 0.05 * dtHours);
                Mood = Clamp11(Mood + 0.02 * dtHours);
            }
            else
            {
                Arousal = Clamp01(Arousal - 0.03 * dtHours + SmallNoise(Config.NoiseSigma));
            }
        }

        public void ApplyConfig(PsychophysConfig cfg)
        {
            Config = cfg ?? PsychophysConfig.Default();
            // reinit hysterese podle configu
            highStressGate = new HysteresisGate(Config.HighStressOn, Config.HighStressOff, highStressGate.State);
            highFatigueGate = new HysteresisGate(Config.HighFatigueOn, Config.HighFatigueOff, highFatigueGate.State);
        }

        public void ApplyCycleModulation(HumanPhysiology phys)
        {
            var c = phys?.Cycle;
            if (c is null || !c.Enabled) return;

            // Interocepční brána: citlivější jedinci víc „cítí“ fáze
            double sens = InteroceptionSensitivity; // 0..1
            double scale = 0.6 + 0.6 * sens;        // 0.6..1.2

            // PMS: lehce horší nálada, více stresu/úzkosti, menší tolerance
            if (c.IsPMS)
            {
                Mood = Math.Clamp(Mood - 0.10 * scale, -1.0, 1.0);
                StressLevel = Math.Clamp(StressLevel + 0.08 * scale, 0.0, 1.0);
                Anxiety = Math.Clamp(Anxiety + 0.06 * scale, 0.0, 1.0);
                Confidence = Math.Clamp(Confidence - 0.04 * scale, 0.0, 1.0);
            }

            // Periovulace: lehce víc arousal, menší sociální bariéra
            if (c.Phase == CyclePhase.PeriOvulatory)
            {
                Arousal = Math.Clamp(Arousal + 0.10 * scale, 0.0, 1.0);
                SocialDrive = Math.Clamp(SocialDrive + 0.05 * scale, 0.0, 1.0);
                Mood = Math.Clamp(Mood + 0.04 * scale, -1.0, 1.0);
            }

            // Menstruace: únava/bolest → drobný pokles energie vnímán jako „fatigue“
            if (c.Phase == CyclePhase.Menstruation)
            {
                Fatigue = Math.Clamp(Fatigue + 0.06 * scale, 0.0, 1.0);
            }
        }

        public double ComputeExertionFromPsychology()
        {
            double baseMix = 0.3 * StressLevel + 0.4 * Motivation + 0.2 * Focus - 0.1 * Fatigue;
            double penalties =
                0.05 * Math.Max(0, SleepDebtHours / 8.0) +
                0.06 * Hunger +
                0.06 * Thirst +
                0.05 * Anxiety +
                0.05 * Pain;

            double bonus = 0.05 * Math.Max(0, Mood);
            return Clamp01(baseMix + bonus - penalties);
        }

        /// <summary>Jednorázové „nasazení“ vlivu osobnosti do baseline (volat při initu postavy).</summary>
        public void PersonalityInfluence(Personality? personality)
        {
            if (personality is null) return;
            var r = ReadPersonality(personality);

            SocialDrive = Clamp01(Lerp(SocialDrive, 0.3 + 0.7 * r.Extraversion, 0.7));
            Mood = Clamp11(Mood + 0.10 * (r.Extraversion - 0.5));
            Arousal = Clamp01(Arousal + 0.10 * (r.Extraversion - 0.5));

            Anxiety = Clamp01(Lerp(Anxiety, 0.2 + 0.7 * r.Neuroticism, 0.6));
            StressLevel = Clamp01(StressLevel + 0.15 * (r.Neuroticism - 0.5));
            Resilience = Clamp01(Resilience * (0.95 - 0.3 * (r.Neuroticism - 0.5)));
            Confidence = Clamp01(Confidence - 0.20 * (r.Neuroticism - 0.5));

            SelfControl = Clamp01(Lerp(SelfControl, 0.3 + 0.7 * r.Conscientiousness, 0.7));
            Focus = Clamp01(Lerp(Focus, 0.3 + 0.7 * r.Conscientiousness, 0.6));

            Aggression = Clamp01(Aggression - 0.20 * (r.Agreeableness - 0.5));
            SocialDrive = Clamp01(SocialDrive + 0.10 * (r.Agreeableness - 0.5));

            Curiosity = Clamp01(Lerp(Curiosity, 0.3 + 0.7 * r.Openness, 0.7));
            Mood = Clamp11(Mood + 0.08 * (r.Openness - 0.5));
        }

        // === Spánek (S-křivka kvality, interocepce, WtHR vliv) ===
        public void Sleep(double hours, double quality, HumanPhysiology phys)
        {
            hours = Math.Max(0, hours);
            quality = Clamp01(quality);

            // S-křivka účinku kvality kolem 0.5
            double qEff = Config.SleepRecoveryBase * (0.5 + 0.5 * Sigmoid(quality, Config.SleepQualitySlope, 0.5));
            // lepší hydratace → lepší spánek; lepší WtHR → malý bonus
            double wtHrBonus = (phys.WtHR <= Config.WtHRGood) ? 0.02 : (phys.WtHR >= Config.WtHRBad ? -0.02 : 0.0);
            double effective = hours * (qEff * (0.8 + 0.2 * phys.Vitals.Hydration + wtHrBonus));

            Fatigue = Clamp01(Fatigue - effective);
            StressLevel = Clamp01(StressLevel - 0.08 * effective);
            Anxiety = Clamp01(Anxiety - 0.06 * effective);
            Mood = Clamp11(Mood + 0.05 * effective);

            // Spánkový dluh – přibliž ke 0
            double need = Math.Max(0, phys.SleepNeedHours - hours);
            SleepDebtHours = Math.Max(0, SleepDebtHours - (hours - need));
        }

        // === Hlavní psychologický Tick (hysterese + šum + interocepce) ===
        public void Tick(
            HumanPhysiology phys,
            double ageYears,
            double dtHours,
            double exertion,                         // 0..1 – stejný jako u fyzia
            double? dailyCalorieIntakeKcal = null,
            Personality? personality = null)
        {
            // bazální návraty
            StressLevel = Clamp01(StressLevel - StressDecayPerHour * dtHours + SmallNoise(Config.NoiseSigma));
            Arousal = Clamp01(Arousal - ArousalDecayPerHour * dtHours);
            Mood = Clamp11(Mood - Math.Sign(Mood) * MoodReversionPerHour * dtHours);

            // fyzio vstupy (nelineárně, interocepce)
            UpdateFromPhysiology(phys, ageYears, dtHours, dailyCalorieIntakeKcal);
            ApplyCircadianModulation(phys, GetLocalHour(), dtHours);

            // Exertion → únava; mírná zátěž zlepšuje náladu
            Fatigue = Clamp01(Fatigue + exertion * FatiguePerHighExertionHour * dtHours);
            if (exertion > 0.15 && exertion < 0.6)
                Mood = Clamp11(Mood + 0.03 * dtHours);

            // Hysterese „HighFatigue“
            highFatigueGate.Update(Fatigue);
            if (highFatigueGate.State)
            {
                Focus = Clamp01(Focus - 0.10 * dtHours); // ve vysoké únavě padá focus rychleji
                StressLevel = Clamp01(StressLevel + 0.03 * dtHours);
            }

            // Hunger/Thirst → stres/focus
            StressLevel = Clamp01(StressLevel + (0.20 * Hunger + 0.20 * Thirst) * dtHours);
            Focus = Clamp01(Focus - (0.25 * Hunger + 0.15 * Thirst + 0.20 * Fatigue) * dtHours);

            // Doznívání událostí + coping
            DecayEmotions(dtHours);
            var coping = SelectCoping(control: 0.5, personality);
            ApplyCoping(coping, dtHours);

            // Jemná online modulace osobností
            if (personality is not null)
            {
                var p = ReadPersonality(personality);
                StressLevel = Clamp01(StressLevel + 0.05 * (p.Neuroticism - 0.5) * dtHours);
                Focus = Clamp01(Focus + 0.04 * (p.Conscientiousness - 0.5) * (1.0 - Fatigue) * dtHours);
                SocialDrive = Clamp01(SocialDrive + 0.05 * (p.Extraversion - 0.5) * dtHours);
            }

            ApplyCycleModulation(phys);
        }

        // === INTEGRACE S FYZIOLOGIÍ (s nelinearitami a interocepcí) ===
        public void UpdateFromPhysiology(HumanPhysiology phys, double ageYears, double dtHours, double? dailyCalorieIntakeKcal = null)
        {
            // 1) Žízeň z hydratace (nelineárně, S-křivka kolem prahu)
            double hyd = phys.Vitals.Hydration;                 // 0..1
            double thirstTarget = Sigmoid(1.0 - hyd,
                                          k: Config.HydrationStressSlope,
                                          x0: 1.0 - Config.HydrationStressThreshold); // vyšší „1-hyd“ => větší žízeň
            // Interocepce škáluje „kolik“ se přiblížíme k targetu
            Thirst = Clamp01(Lerp(Thirst, thirstTarget, 0.5 * InteroceptionSensitivity));

            // 2) Energetika (TDEE + zátěž proxy z HR) → Hunger
            double tdee = phys.GetTDEE(ageYears);
            double perHour = tdee / 24.0;
            double intakePerHour = (dailyCalorieIntakeKcal ?? tdee) / 24.0;
            double exertionProxy = Math.Clamp((phys.Vitals.HeartRate - 60.0) / 90.0, 0, 1);
            double extraExp = perHour * 0.60 * exertionProxy;
            double kcalBalanceHour = intakePerHour - (perHour + extraExp); // + surplus, − deficit

            // Hlad roste nelineárně s deficitem (S-křivka), s lehkou váhou z interocepce
            double deficit = Math.Max(0, -kcalBalanceHour) * (24.0 / Config.DeficitToHungerKcal); // převod / den
            double hungerKick = Tanh01(deficit, k: Config.HungerStressSlope, x0: 0.5) - 0.5; // ~0..+0.5
            Hunger = Clamp01(Hunger + (0.10 * exertionProxy + hungerKick) * InteroceptionSensitivity * dtHours
                                      - 0.05 * hyd * dtHours);

            // 3) Arousal/Mood – nelineárně a interoceptivně
            double arousalTarget = Clamp01(0.4 + 0.5 * exertionProxy
                                              - 0.25 * Fatigue
                                              - 0.2 * Thirst
                                              - 0.1 * Hunger);
            Arousal = Clamp01(Lerp(Arousal, arousalTarget, ArousalDecayPerHour * dtHours * (0.5 + InteroceptionSensitivity)));

            // WtHR (kondice) – z fyzia – moduluje náladu/stres
            double wtHrAdj = 0.0;
            if (phys.WtHR > 0.0001)
            {
                if (phys.WtHR <= Config.WtHRGood) wtHrAdj = Config.WtHRImpact;
                else if (phys.WtHR >= Config.WtHRBad) wtHrAdj = -Config.WtHRImpact;
            }

            double moodShift = (0.18 * (hyd - 0.7) + 0.10 * (0.5 - Hunger) - 0.10 * Pain - 0.10 * Anxiety + wtHrAdj)
                               * (0.5 + InteroceptionSensitivity);
            Mood = Clamp11(Mood + moodShift * dtHours + SmallNoise(Config.NoiseSigma));

            // 4) Stres – nelineární reakce na diskomfort + hysterese
            double stressDrive = Clamp01(0.10
                                         + 0.40 * Thirst
                                         + 0.30 * Hunger
                                         + 0.30 * Pain
                                         + 0.15 * (1.0 - hyd));
            // menší reakce, pokud Resilience vysoká
            stressDrive *= (1.0 - 0.25 * Resilience);

            // hysterese „HighStress“
            highStressGate.Update(stressDrive);
            if (highStressGate.State)
                stressDrive += 0.05; // setrvačnost ve vysokém stresu

            StressLevel = Clamp01(Lerp(StressLevel, stressDrive, 0.4 * dtHours) + SmallNoise(Config.NoiseSigma));
        }
    }
}
