﻿// OfferHelp.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    public sealed class OfferHelp : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.OfferHelp;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Cooperation,
                When = ctx.When,
                IsMicro = false,
                Context = new InteractionContext
                {
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.15f, 0f, 1f),
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.10f, -1f, 1f),
                    SharedGoal = Math.Clamp(ctx.Ix.SharedGoal + 0.30f, 0f, 1f),
                    Privacy = ctx.Ix.Privacy,
                    Continuity = ctx.Ix.Continuity,
                    Risk = ctx.Ix.Risk,
                    SocialAudience = ctx.Ix.SocialAudience,
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && (ctx.Situation == SituationType.RequestHelp || ctx.Ix.SharedGoal > 0.2f);

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality;
            var psy = ctx.Actor.Psychology;
            double A = per.BigFive[BigFiveTrait.Agreeableness];
            double C = per.BigFive[BigFiveTrait.Conscientiousness];

            double u = 0.10 + 0.30 * A + 0.25 * C + 0.20 * ctx.Ix.SharedGoal
                       + 0.15 * (ctx.Rel?.Liking ?? 50f) / 100.0
                       - 0.20 * psy.Fatigue - 0.15 * psy.StressLevel;
            return Bx.Clamp01(u);
        }
    }
}
