﻿// RepairPlan.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Planning
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public sealed class RepairPlan : IBehaviorPlan
    {
        private int _i;
        private static readonly BehaviorType[] Seq = new[]
        { BehaviorType.DeescalateConflict, BehaviorType.Apologize, BehaviorType.OfferHelp, BehaviorType.CheckIn };

        public string Name => "RepairPlan";
        public bool CanStart(BehaviorContext ctx)
            => ctx.Rel?.HasActiveConflict == true && (ctx.Rel?.Trust ?? 0) >= 20f;

        public PlanStatus Tick(BehaviorContext ctx, Func<BehaviorType, BehaviorContext, bool> enact)
        {
            while (_i < Seq.Length)
            {
                if (!enact(Seq[_i], ctx)) return PlanStatus.Failed;
                _i++;
            }
            return PlanStatus.Succeeded;
        }
    }
}
