﻿// EncounterSourceAdapter.cs
// Copyright (c) 50PSoftware

// Path: Characters/CharacterModel/Behavior/Encounters/EncounterSourceAdapter.cs
using GameEngineTools.World.Utils.Time;

namespace GameEngineTools.World.Encounters
{
    // Jednoduchý adaptér nad EncounterService: denní cache → „get near now“
    public interface IEncounterSource
    {
        IEnumerable<Encounter> GetNear(WDateTime nowUtc, WTimeSpan window);
    }

    public sealed class EncounterSourceAdapter : IEncounterSource
    {
        private readonly EncounterService _svc;
        private List<Encounter> _cache = new();
        private WDateTime _cachedDayStart;

        public EncounterSourceAdapter(EncounterService svc) => _svc = svc;

        public IEnumerable<Encounter> GetNear(WDateTime nowUtc, WTimeSpan window)
        {
            var dayStart = new WDateTime(nowUtc.Year, nowUtc.Month, nowUtc.Day, 0, 0, 0);
            if (_cache.Count == 0 || _cachedDayStart != dayStart)
            {
                _cachedDayStart = dayStart;
                _cache = _svc.BuildEncountersForDay(dayStart).ToList();
            }

            var from = nowUtc - window;
            var to = nowUtc + window;
            return _cache.Where(e => e.When >= from && e.When <= to);
        }
    }
}
