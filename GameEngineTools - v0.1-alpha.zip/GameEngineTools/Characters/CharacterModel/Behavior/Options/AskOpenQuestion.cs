﻿// AskOpenQuestion.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    public sealed class AskOpenQuestion : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.AskOpenQuestion;

        public void Apply(in BehaviorContext ctx)
        {
            // Mapujeme na SpendTime s lehce vyšší Depth + Warmth
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.SpendTime,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.20f, 0f, 1f),
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.10f, -1f, 1f),
                    Privacy = ctx.Ix.Privacy,
                    SharedGoal = ctx.Ix.SharedGoal,
                    SocialAudience = ctx.Ix.SocialAudience,
                    Continuity = ctx.Ix.Continuity,
                    Risk = ctx.Ix.Risk
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx) => ctx.Target is not null;

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality;
            var psy = ctx.Actor.Psychology;
            var (O, C, E, A, N) = Bx.ReadBigFive(per);

            double mood = 0.5 + 0.5 * psy.Mood;                 // -1..1 -> 0..1
            double socialDrive = psy.SocialDrive;               // 0..1
            double fatigue = psy.Fatigue;                       // 0..1
            double stress = psy.StressLevel;                    // 0..1

            double u = 0.20 + 0.25 * E + 0.20 * A + 0.15 * mood + 0.20 * socialDrive
                       - 0.15 * fatigue - 0.15 * stress - 0.10 * ctx.CrowdNoise01
                       + 0.10 * ctx.Goals.AffiliationNeed01;

            return Bx.Clamp01(u);
        }
    }
}
