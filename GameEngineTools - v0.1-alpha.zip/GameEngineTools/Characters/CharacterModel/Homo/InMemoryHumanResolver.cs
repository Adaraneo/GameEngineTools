﻿// inMemoryHumanResolver.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Homo
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public sealed class InMemoryHumanResolver : IHumanResolver
    {
        private readonly ConcurrentDictionary<Guid, IHuman> _map = new();
        public bool TryGet(Guid id, out IHuman human) => _map.TryGetValue(id, out human);
        public void Add(IHuman h) => _map[h.DNA] = h;
        public void Remove(IHuman h) => _map.TryRemove(h.DNA, out _);
    }
}
