﻿// NonPlayableCharacter.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.GameObjects
{
    using GameEngineTools.Characters.CharacterModel.Homo;

    /// <summary>
    /// Non-playable character
    /// </summary>
    public class NPC : NPPC
    {
        public NPC() : base()
        {
        }

        public NPC(int maxHealth, Person person) : base(maxHealth, person)
        {
        }
    }
}
