﻿// Water.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.MagicSystem
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.GameObjects;

    public class Water : Magic, IMagic
    {
        private void Water_MagicDone(object? sender, MagicArguments e)
        {
            var humanPsychology = e.Affectator.Psychology;
            var humanPhysiology = e.Affectator.Body;
            if (!canCast)
            {
                if (e.Affected is Action a && a.Method.Name.Contains(this.GetType().Name))
                {
                    a.Invoke();
                }
            }
            else
            {
                if (e.Affected is NPC npc)
                {
                    var protection = npc.Protection;
                    var points = e.Affectator.Magic.AffectPoints;
                    npc.DecreaseHealth((protection + points) * 0.3);
                }
            }
        }

        internal Water(Person p) : base(p)
        {
            this.MagicType = MagicType.Water;
            this.MagicDone += Water_MagicDone;
            this.canCast = false;
        }

        public void SetCanCast(bool canCast)
        {
            this.canCast = canCast;
        }
    }
}
