﻿// BondRulesOptions.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Config
{
    using GameEngineTools.World.Utils.Time;
    public sealed class BondRulesOptions
    {
        public float FriendMinCloseness { get; set; } = 50f;
        public float FriendMinLiking { get; set; } = 30f;
        public float FriendMinTrust { get; set; } = 20f;

        public float FamiliarMinCloseness { get; set; } = 20f;
        public float FamiliarMinLiking { get; set; } = 5f;
        public float FamiliarMinTrust { get; set; } = -10f;

        public float IntimateMinCloseness { get; set; } = 70f;
        public float IntimateMinLiking { get; set; } = 50f;
        public float IntimateMinTrust { get; set; } = 35f;
        public float IntimateMinAttraction { get; set; } = 50f;

        public float PartnerAddMinCloseness { get; set; } = 60f;
        public float PartnerAddMinLiking { get; set; } = 45f;
        public float PartnerAddMinTrust { get; set; } = 30f;
        public float PartnerAddMinAttraction { get; set; } = 40f;

        public float PartnerBreakMaxCloseness { get; set; } = 45f;
        public float PartnerBreakMaxLiking { get; set; } = 25f;
        public float PartnerBreakMaxTrust { get; set; } = 15f;
        public float PartnerBreakMaxAttraction { get; set; } = 22f;

        public float EnemyMaxLiking { get; set; } = -25f;
        public float EnemyMaxTrust { get; set; } = -30f;

        public float RivalMinCloseness { get; set; } = 25f;
        public float RivalMaxLiking { get; set; } = -15f;

        public WTimeSpan PartnerMinDuration { get; set; } = WTimeSpan.FromDays(30);
        public float StageEmaDays { get; set; } = 4f;
        public float AsymmetryInertia { get; set; } = 0.80f; // 0..1 (1 = bez dorovnání)
    }
}
