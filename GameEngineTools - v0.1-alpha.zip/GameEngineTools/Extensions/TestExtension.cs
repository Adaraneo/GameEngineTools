﻿// TestExtension.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Extensions
{
    using System.Data;
    using System.Text;
    using GameEngineTools;
    using GameEngineTools.Characters.CharacterModel.Events;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;
    using GameEngineTools.Characters.GameObjects;
    using GameEngineTools.World.Utils.Time;

    public static class TestExtension
    {
        internal static string WithWho(this CivilStatus status, in RelationshipManager relationshipManager, in IHuman person, bool withDNA = false)
        {
            string information = null;
            Person other = null;
            string fullName = null;
            RelationshipModel relations = null;
            foreach (var relation in person.ExportRelationships.Values)
            {
                if (relation.Kind == BondKind.Romantic)
                {
                    relations = relation;
                }
            }

            switch (status)
            {
                case CivilStatus.InRelationship:
                case CivilStatus.Engaged:
                case CivilStatus.Married:
                    other = (Person)relationshipManager.EnumerateFrom(person).Where(x => x.Rel.Kind == BondKind.Romantic && x.Rel.Tags == BondTag.Partner).Select(p => p.To).FirstOrDefault()!;
                    break;
            }

            fullName = other == null ? string.Empty : other.Name.ToString() + " " + other.Surname;
            information = other == null ? string.Empty : (withDNA ? fullName + "\n\tDNA: " + other.Body.DNA : fullName);
            return information;
        }

        public static List<NPPC> CreateFamilyForPlayer(this GameEngineToolsManager instance, PC player)
        {
            throw new NotImplementedException();
        }

        public static void DoMagic(this NPPC caster, params object[] tagrets)
        {
            if (caster != null)
            {
                foreach (var target in tagrets)
                {
                    caster.DoMagic(target);
                }
            }
        }

        public static Dictionary<IHuman, RelationshipModel> GetRelationshipModels(this RelationshipManager relationshipManager, in IHuman person)
        {
            return relationshipManager.EnumerateFrom(person).ToDictionary(k => k.To, v => v.Rel.GetModel());
        }

        public static string PrintInfo(this NPPC nppc, in RelationshipManager relationshipManager, bool basicInfo = true, bool withDNA = false)
        {
            var sbResult = new StringBuilder();
            var person = nppc.Person;
            var name = person.Name;
            sbResult.AppendLine($"Name: {(string.IsNullOrEmpty(name.Familiar[0]) ? name.Original : name.Familiar[new Random().Next(0, name.Familiar.Length)])} {person.Surname}");
            sbResult.AppendLine($"Age: {person.Age}");

            if (!basicInfo)
            {
                sbResult.AppendLine($"Status: {person.Status}");
                sbResult.AppendLine($"Stadium: {person.GetStadium()}");
                if (person.GetStadium() != StadiumType.Baby && person.GetStadium() != StadiumType.Child)
                {
                    sbResult.AppendLine($"Relationship status: {person.CivilStatus}");
                }

                if (person.CivilStatus == CivilStatus.InRelationship || person.CivilStatus == CivilStatus.Engaged || person.CivilStatus == CivilStatus.Married)
                {
                    sbResult.AppendLine($"\tWith: {person.CivilStatus.WithWho(relationshipManager, person, withDNA)}");
                }

                var sbTemp = new StringBuilder();
                foreach (var physioInfo in nppc.Person.Body.GetType().GetProperties())
                {
                    var pName = physioInfo.Name;
                    var pValue = physioInfo.GetValue(nppc.Person.Body);
                    if (pName.ToLowerInvariant() == "somatotype")
                    {
                        var somtypes = nppc.Person.Body.Somatotype;
                        var tmpSB = new StringBuilder();
                        foreach (var somtype in somtypes.GetType().GetProperties())
                        {
                            tmpSB.AppendFormat("\t{0}: {1}\n", somtype.Name, somtype.GetValue(somtypes));
                        }

                        pValue = tmpSB.ToString();
                    }
                    else if (pName.ToLowerInvariant() == "cycle")
                    {
                        var mcvals = nppc.Person.Body.Cycle;
                        if (!mcvals.Enabled) continue;
                        var tmpMC = new StringBuilder();
                        foreach (var mc in mcvals.GetType().GetProperties())
                        {
                            tmpMC.AppendFormat("\t{0}: {1}\n", mc.Name, mc.GetValue(mcvals));
                        }

                        pValue = tmpMC.ToString();
                    }

                    sbTemp.AppendFormat("{0}: {1}\n", pName, pValue);
                }

                sbResult.AppendLine(string.Format("PHYSIOLOGY:\n{0}", sbTemp.ToString()));
                sbTemp.Clear();
                foreach (var psychoInfo in nppc.Person.Psychology.GetType().GetProperties())
                {
                    sbTemp.AppendFormat("{0}: {1}\n", psychoInfo.Name, psychoInfo.GetValue(nppc.Person.Psychology));
                }

                sbResult.AppendLine(string.Format("PSYCHOLOGY:\n{0}", sbTemp.ToString()));
                sbTemp.Clear();
                foreach (var personalityInfo in nppc.Person.Personality.GetType().GetProperties())
                {
                    var pName = personalityInfo.Name;
                    var pValue = personalityInfo.GetValue(nppc.Person.Personality);
                    if (pName.ToLowerInvariant() == "bigfive")
                    {
                        pValue = string.Join(", ", ((Dictionary<BigFiveTrait, double>)pValue!).Select(kv => $"{kv.Key}: {kv.Value:F2}"));
                    }
                    else if (pName.ToLowerInvariant() == "traits")
                    {
                        pValue = string.Join(", ", ((HashSet<PersonalityTrait>)pValue!).Select(pt => pt.ToString()));
                    }
                    else if (pName.ToLowerInvariant() == "values")
                    {
                        pValue = string.Join(", ", ((List<CoreValue>)pValue!).Select(cv => cv.ToString()));
                    }
                    else if (pName.ToLowerInvariant() == "fears")
                    {
                        pValue = string.Join(", ", ((List<Fear>)pValue!).Select(f => f.Name));
                    }
                    else if (pName.ToLowerInvariant() == "hobbies")
                    {
                        pValue = string.Join(", ", ((List<Hobby>)pValue!).Select(h => h.Name));
                    }
                    else if (pName.ToLowerInvariant() == "experiences")
                    {
                        pValue = string.Join(", ", ((List<Experience>)pValue!).Select(e => e.Name));
                    }
                    else if (pName.ToLowerInvariant() == "morality")
                    {
                        pValue = string.Join(", ", (pValue as MoralProfile)!.Scores.Select(md => $"{md.Key}: {md.Value:F2}"));
                    }

                    sbTemp.AppendFormat("\t{0}: {1}\n", pName, pValue);
                }

                sbResult.AppendLine(string.Format("PERSONALITY:\n{0}", sbTemp.ToString()));
                sbTemp.Clear();
            }

            return sbResult.ToString();
        }

        /// <summary>
        /// Creates significant other for player.
        /// </summary>
        /// <param name="instance">GameEngineTools manager instance.</param>
        /// <param name="forPlayer">Player.</param>
        /// <returns>Random person for player.</returns>
        public static Person RandomizePerson(this IGameEngineToolsManager instance, PC forPlayer)
        {
            Person significantOther = null;
            switch (forPlayer.Person.Genus)
            {
                case GenusType.Male:
                    significantOther = instance.RandomizePerson(forPlayer.Person.Age - 4, forPlayer.Person.Age + 2, genus: GenusType.Female);
                    break;

                case GenusType.Female:
                    significantOther = instance.RandomizePerson(forPlayer.Person.Age + 1, forPlayer.Person.Age + 10, genus: GenusType.Male);
                    break;
            }

            return significantOther!;
        }
    }
}
