﻿// AftercareCuddle.cs
// Copyright (c) 50PSoftware

using GameEngineTools.Characters.CharacterModel.Homo;
using GameEngineTools.Characters.CharacterModel.Relationships;

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    /// Měkké „přistání“ po intimnějším okamžiku (chlazení rizika, udržení tepla).
    /// Nevyžaduje, aby bezprostředně předcházelo Sex – stačí vysoká Physicality/Depth + soukromí.
    public sealed class AftercareCuddle : IBehaviorOption
    {
        // Zařadíme mezi "návrh sdílené aktivity" → sdílí cooldown s jemnými sociálními volbami
        public BehaviorType Type => BehaviorType.Cuddle;

        public void Apply(in BehaviorContext ctx)
        {
            // Jemné SpendTime: snížení Risk/Physicality, zvýšení Warmth/Continuity/SharedGoal,
            // udržíme Depth, posuneme Tone do plusu.
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.SpendTime,
                When = ctx.When,
                IsMicro = false,
                Context = new InteractionContext
                {
                    Privacy = Math.Max(ctx.Ix.Privacy, 0.70f),
                    SocialAudience = 0.0f,
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.10f, 0f, 1f),
                    Warmth = Math.Clamp(ctx.Ix.Warmth + 0.25f, 0f, 1f),
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.20f, -1f, 1f),
                    Risk = Math.Max(0f, ctx.Ix.Risk - 0.10f),
                    Physicality = Math.Max(0f, ctx.Ix.Physicality - 0.20f),
                    SharedGoal = Math.Clamp(ctx.Ix.SharedGoal + 0.15f, 0f, 1f),
                    Continuity = Math.Clamp(ctx.Ix.Continuity + 0.20f, 0f, 1f),
                    Surprise = ctx.Ix.Surprise
                }
            };

            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
        {
            if (ctx.Target is null || !ctx.Rel.HasValue) return false;
            var r = ctx.Rel.Value;

            bool stageOk = r.Stage >= BondStage.Intimate;           // přirozenější až od romantiky výš
            bool privacyOk = ctx.Ix.Privacy >= 0.60f && ctx.Ix.SocialAudience <= 0.05f;
            bool softState = (ctx.Ix.Physicality >= 0.60f || ctx.Ix.Depth >= 0.55f);
            bool toneOk = ctx.Ix.EmotionalTone >= -0.10f;          // i po smíšeném pocitu dává smysl
            return stageOk && privacyOk && softState && toneOk;
        }

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality;
            var psy = ctx.Actor.Psychology;
            var r = ctx.Rel!.Value;

            double A = per.BigFive[BigFiveTrait.Agreeableness];
            double u =
                0.10
              + 0.25 * A
              + 0.20 * (r.Closeness / 100.0)
              + 0.15 * (r.Trust / 100.0)
              + 0.15 * ctx.Ix.Privacy
              + 0.10 * (0.5 + 0.5 * psy.Mood)
              - 0.10 * psy.Fatigue; // když je únava, aftercare pořád dává smysl

            return Bx.Clamp01(u);
        }
    }
}
