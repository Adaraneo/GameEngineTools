﻿// INormEvaluator.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Norms
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public interface INormEvaluator
    {
        /// <summary>
        /// Vrať zápornou penalizaci (0 až záporné hodnoty). Signature držíme jednoduché: jen BehaviorType + BehaviorContext.
        /// Interně můžeš použít cokoliv z ctx (NormPressure01, CrowdNoise01, apod.).
        /// </summary>
        double Evaluate(BehaviorType type, in BehaviorContext ctx);
    }
}
