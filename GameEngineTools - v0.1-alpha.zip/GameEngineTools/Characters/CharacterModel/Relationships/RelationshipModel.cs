﻿// RelationshipModel.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships
{
    using System;
    using GameEngineTools.World.Utils.Time;

    public sealed class RelationshipModel
    {
        public float Attraction { get; set; } = 0f;
        public double AttractionBias { get; set; } = 0.5;
        public float Closeness { get; set; } = 0f;
        public double ClosenessBias { get; set; } = 0.5;
        public float Compatibility { get; set; } = 0f;
        public float Friction { get; set; } = 1f;
        public BondKind Kind { get; set; } = BondKind.Neutral;
        public KinshipRole KinshipRole { get; set; } = KinshipRole.Unknown;
        public WDateTime? LastInteraction { get; set; }
        public WDateTime LastUpdate { get; set; } = WDateTime.Now;
        public double LikeBias { get; set; } = 0.5;
        public float Liking { get; set; } = 0f;
        public float MaxAttraction { get; set; } = 100f;
        public float MaxCloseness { get; set; } = 100f;
        public float MaxLiking { get; set; } = 100f;
        public float MaxTrust { get; set; } = 100f;
        public float MinAttraction { get; set; } = 0f;
        public float MinCloseness { get; set; } = -100f;
        public float MinLiking { get; set; } = -100;
        public float MinTrust { get; set; } = -100f;
        public float PhysicalAffinity { get; set; } = 0.5f;
        public float SecurityBuffer { get; set; } = 0f;
        public BondStage Stage { get; set; } = BondStage.Stranger;
        public BondTag Tags { get; set; } = BondTag.None;
        public float Trust { get; set; } = 0f;
        public double TrustBias { get; set; } = 0.5;
        public WDateTime? TrustLockoutUntil { get; set; }
    }
}
