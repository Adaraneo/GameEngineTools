﻿// Person.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Homo
{
    using System.Text.Json.Serialization;
    using GameEngineTools;
    using GameEngineTools.MagicSystem;

    public sealed class Person : Human
    {
        private Magic magic;
        private Surname surname;

        private void InitContainers()
        {
            CivilStatus = CivilStatus.Single;
            Psychology.PersonalityInfluence(Personality);
        }

        /// <summary>
        /// Minimal constructor pro JSON deserializaci. Vyplní jen nezbytné údaje,
        /// zbytek si volající doplní ručně.
        /// </summary>
        [JsonConstructor]
        internal Person(MagicType magicType, double age, GenusType genus) : base(genus)
        {
            SetAge(age);
            switch (magicType)
            {
                case MagicType.Fire:
                    magic = new Fire(this);
                    break;

                case MagicType.Water:
                    magic = new Water(this);
                    break;

                case MagicType.Air:
                    magic = new Air(this);
                    break;

                case MagicType.Earth:
                    magic = new Earth(this);
                    break;
            }
            InitContainers();
        }

        internal Person(
            Name name,
            Surname surname,
            GenusType genus,
            MagicType magic,
            double ageYears = 0,
            double heightCm = 170,
            double weightKg = 70) : this(magic, ageYears, genus)
        {
            Name = name;
            this.surname = surname;

            Body.HeightCm = heightCm;
            Body.WeightKg = weightKg;

            InitContainers();
        }

        internal static Person Female(Name name, Surname surname, MagicType magic, double ageYears = 0, double heightCm = 49, double weightKg = 3.2)
        {
            var female = new Person(name, surname, GenusType.Female, magic, ageYears, heightCm, weightKg);
            return female;
        }

        internal static Person Male(Name name, Surname surname, MagicType magic, double ageYears = 0, double heightCm = 50, double weightKg = 3.4)
        {
            var male = new Person(name, surname, GenusType.Male, magic, ageYears, heightCm, weightKg);
            return male;
        }

        internal Surname GetSurname()
        {
            return surname;
        }

        internal void SetSurname(Surname surname)
        {
            this.surname = surname;
        }

        [JsonInclude]
        public CivilStatus CivilStatus { get; set; } = CivilStatus.Single;

        public Magic Magic
        {
            get => magic;
        }

        public string Surname => Genus == GenusType.Male
                                    ? surname.Male
                                    : surname.Female;

        public bool Equals(Person other)
        {
            if (other == null)
            {
                return false;
            }

            if (Body.DNA == other.Body.DNA)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override bool Equals(object? obj)
        {
            if (obj == null || !(obj is Person))
            {
                return false;
            }
            else
            {
                return Equals((Person)obj);
            }
        }

        public string GetMagicName()
        {
            return magic.ToString();
        }

        public override string ToString()
        {
            return $"{Name} {Surname}";
        }
    }
}
