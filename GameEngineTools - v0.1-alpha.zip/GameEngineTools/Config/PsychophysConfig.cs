﻿// PsychophysConfig.cs
// Copyright (c) 50PSoftware
// Globální koeficienty pro psychofyziologii

namespace GameEngineTools.Config
{
    using System.Text.Json;

    public class PsychophysConfig
    {
        // --- Hlad / deficit ---
        public double DeficitToHungerKcal { get; set; } = 700.0;

        public double HighFatigueOff { get; set; } = 0.55;

        public double HighFatigueOn { get; set; } = 0.75;

        public double HighStressOff { get; set; } = 0.50;

        // --- Hysterese (zap./vyp. hranice) ---
        public double HighStressOn { get; set; } = 0.70;

        // kolik kcal deficitu == +1.0 hladu / den
        public double HungerStressSlope { get; set; } = 6.0;

        public double HydrationStressSlope { get; set; } = 8.0;

        // --- Hydratace / žízeň / stres ---
        public double HydrationStressThreshold { get; set; } = 0.70; // když hydratace < 0.70, roste stres nelineárně

        // nad 0.70 zapni „HighStress“
        // pod 0.50 vypni
        // --- Šum (volitelné) ---
        public double NoiseSigma { get; set; } = 0.01;

        public double SleepQualitySlope { get; set; } = 8.0;

        // ostrost S-křivky
        // --- Spánek / únava ---
        public double SleepRecoveryBase { get; set; } = 0.12;         // recovery / hod kvalitního spánku (před vahou S-křivky)

        // kvalita spánku → účinek (S-křivka kolem 0.5)

        public double WtHRBad { get; set; } = 0.60;

        // --- WtHR (kondice) => regenerace/stres (použito v psycho) ---
        public double WtHRGood { get; set; } = 0.45;

        public double WtHRImpact { get; set; } = 0.10;               // ± rozsah vlivu na regeneraci/stres

        // typická amplituda additivního šumu / tick

        public static PsychophysConfig Default() => new PsychophysConfig();

        public static PsychophysConfig FromJson(string json)
        {
            try { return JsonSerializer.Deserialize<PsychophysConfig>(json) ?? Default(); }
            catch { return Default(); }
        }
    }
}
