﻿// Names.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Homo
{
    public class Name
    {
        public string[] Familiar { get; set; }
        public string Original { get; set; }

        public override string ToString()
        {
            return Original;
        }
    }
}
