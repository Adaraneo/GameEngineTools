﻿// BehaviorLoopOptions.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Config
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public sealed class BehaviorLoopOptions
    {
        // základní pevný tik (když nepoužiješ Poisson)
        public int TickSeconds { get; set; } = 10;           // 10 s
                                                             // kolik interakcí/rozhodnutí maximálně na jeden tik
        public int BurstBudget { get; set; } = 8;
        // jak dlouho dopředu ještě považovat encounter za „živý“
        public int EncounterLookaheadSeconds { get; set; } = 45;
        // zapnout Poisson místo pevné periody
        public bool UsePoisson { get; set; } = true;
        // základní intenzita (události/min) pro výpočet ∆t ~ Exp(λ)
        public double BaseRatePerMinute { get; set; } = 6.0; // průměrně co 10 s
    }
}
