﻿// StandalonePresenceProvider.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.World.Encounters
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.GameObjects;
    using GameEngineTools.World.Utils.Time;

    /// <summary>
    /// Jednoduchý provider: z rosteru lidí a registru míst vygeneruje denní přítomnosti.
    /// </summary>
    public sealed class StandalonePresenceProvider : IWorldPresenceProvider
    {
        private readonly IPeopleProvider _people;
        private readonly PlaceRegistry _places;

        public StandalonePresenceProvider(IPeopleProvider people, PlaceRegistry places)
        {
            _people = people;
            _places = places;
        }

        public IEnumerable<PresenceSegment> BuildPresence(WDateTime dayStartUtc, WDateTime dayEndUtc)
        {
            // 3–4 bloky za den, výběr místa lehce biasnutý osobností
            foreach (var h in _people.GetAll())
            {
                var (O, C, E, A, N) = ReadBigFive(h.Personality);

                // základní časy
                var t0 = dayStartUtc.AddHours(8 + Jitter(0.5));
                var t1 = t0.AddHours(3 + Jitter(0.7));
                var t2 = t1.AddHours(3 + Jitter(0.7));
                var t3 = t2.AddHours(3 + Jitter(0.7));

                // místa podle osobnosti (E→Cafe/Park, C→Office/Workshop, O→Park/Church, A→Cafe/Home)
                var morning = PickWorkish(E, C);
                var midday = PickSocial(E, A);
                var afternoon = PickCreativeOrPark(O, E);
                var evening = PickQuiet(O, A, N);

                yield return new PresenceSegment(h, morning.Id, t0, t1, morning.CapacityHint);
                yield return new PresenceSegment(h, midday.Id, t1, t2, midday.CapacityHint);
                yield return new PresenceSegment(h, afternoon.Id, t2, t3, afternoon.CapacityHint);
                yield return new PresenceSegment(h, evening.Id, t3, dayEndUtc.AddHours(-1), evening.CapacityHint);
            }

            // lokální pickery (volí z existujících míst v registru)
            Place PickWorkish(double E, double C)
            {
                var pool = _places.All.Values.Where(p =>
                    p.Archetype is PlaceArchetype.Office or PlaceArchetype.Workshop or PlaceArchetype.RehearsalRoom).ToList();
                if (pool.Count == 0) pool = _places.All.Values.ToList();

                // conscientiousness preferuje work místa
                return Weighted(pool, p => p.Archetype is PlaceArchetype.Office or PlaceArchetype.Workshop ? 0.6 + 0.6 * C : 0.2 + 0.2 * C);
            }

            Place PickSocial(double E, double A)
            {
                var pool = _places.All.Values.Where(p =>
                    p.Archetype is PlaceArchetype.Cafe or PlaceArchetype.Corridor or PlaceArchetype.PublicSquare).ToList();
                if (pool.Count == 0) pool = _places.All.Values.ToList();

                return Weighted(pool, p => p.Archetype switch
                {
                    PlaceArchetype.Cafe => 0.5 + 0.5 * E + 0.2 * A,
                    PlaceArchetype.Corridor => 0.3 + 0.3 * E,
                    _ => 0.2 + 0.2 * E
                });
            }

            Place PickCreativeOrPark(double O, double E)
            {
                var pool = _places.All.Values.Where(p =>
                    p.Archetype is PlaceArchetype.Park or PlaceArchetype.RehearsalRoom or PlaceArchetype.Church).ToList();
                if (pool.Count == 0) pool = _places.All.Values.ToList();

                return Weighted(pool, p => p.Archetype switch
                {
                    PlaceArchetype.Park => 0.5 + 0.4 * O + 0.2 * E,
                    PlaceArchetype.RehearsalRoom => 0.4 + 0.4 * O,
                    PlaceArchetype.Church => 0.3 + 0.3 * O,
                    _ => 0.2
                });
            }

            Place PickQuiet(double O, double A, double N)
            {
                var pool = _places.All.Values.Where(p =>
                    p.Archetype is PlaceArchetype.Home or PlaceArchetype.Park or PlaceArchetype.Church).ToList();
                if (pool.Count == 0) pool = _places.All.Values.ToList();

                // vyšší neuroticism → domů/park; vyšší openness → kostel/park (klid)
                return Weighted(pool, p => p.Archetype switch
                {
                    PlaceArchetype.Home => 0.4 + 0.4 * N + 0.2 * (1 - A),
                    PlaceArchetype.Park => 0.4 + 0.3 * N + 0.2 * O,
                    PlaceArchetype.Church => 0.3 + 0.3 * O + 0.1 * (1 - N),
                    _ => 0.2
                });
            }

            // helpers
            double Jitter(double max) => (Random.Shared.NextDouble() * 2 - 1) * max; // ±max hodin
            (double O, double C, double E, double A, double N) ReadBigFive(Personality p)
                => (p.BigFive[BigFiveTrait.Openness], p.BigFive[BigFiveTrait.Conscientiousness],
                    p.BigFive[BigFiveTrait.Extraversion], p.BigFive[BigFiveTrait.Agreeableness],
                    p.BigFive[BigFiveTrait.Neuroticism]);

            Place Weighted(List<Place> items, Func<Place, double> w)
            {
                var weights = items.Select(w).Select(x => Math.Max(0.01, x)).ToArray();
                double sum = weights.Sum();
                double roll = Random.Shared.NextDouble() * sum;
                for (int i = 0; i < items.Count; i++)
                {
                    roll -= weights[i];
                    if (roll <= 0) return items[i];
                }
                return items[^1];
            }
        }

        public IPlaceLite GetPlace(Guid placeId) => _places.Get(placeId);
    }
}
