﻿// DeescalateConflict.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// Záměrně sníží teplotu – krátké ujištění, že nechci konflikt, a posun pryč.
    public sealed class DeescalateConflict : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.Refuse; // blízko "odmítnutí sporu"

        public void Apply(in BehaviorContext ctx)
        {
            // Zvolím "čistou" upřímnost s pozitivnějším tónem a nízkým rizikem (např. „teď ne, nechci se hádat“)
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Honesty,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    EmotionalTone = System.Math.Clamp(ctx.Ix.EmotionalTone + 0.10f, -1f, 1f),
                    Depth = System.Math.Clamp(ctx.Ix.Depth - 0.05f, 0f, 1f),
                    Privacy = System.Math.Max(ctx.Ix.Privacy, 0.5f),
                    Risk = System.Math.Max(0f, ctx.Ix.Risk - 0.10f),
                    SocialAudience = 0f,
                    SharedGoal = ctx.Ix.SharedGoal,
                    Continuity = ctx.Ix.Continuity
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && ctx.Situation == SituationType.InsultReceived;

        public float Utility(in BehaviorContext ctx)
        {
            var psy = ctx.Actor.Psychology;
            var per = ctx.Actor.Personality;
            double A = per.BigFive[BigFiveTrait.Agreeableness];
            double C = per.BigFive[BigFiveTrait.Conscientiousness];

            double u = 0.10 + 0.30 * A + 0.20 * C + 0.20 * (1.0 - psy.StressLevel)
                       + 0.10 * ctx.Ix.Privacy + 0.10 * (ctx.Rel?.Trust ?? 50f) / 100.0
                       - 0.10 * psy.Aggression;
            return Bx.Clamp01(u);
        }
    }
}
