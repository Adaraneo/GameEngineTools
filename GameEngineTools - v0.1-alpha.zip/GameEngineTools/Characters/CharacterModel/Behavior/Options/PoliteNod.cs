﻿// PoliteNod.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    public sealed class PoliteNod : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.PoliteNod;

        public void Apply(in BehaviorContext ctx)
        {
            // Zdvořilé kývnutí – žádná přímá Interaction; jen malý „mikroleak“ by šel řešit později.
            // Zatím nic neposíláme do vztahů.
        }

        public bool IsApplicable(in BehaviorContext ctx) => ctx.Target is not null;

        public float Utility(in BehaviorContext ctx)
        {
            var p = ctx.Actor.Psychology;
            // Základ: bezpečná defaultní volba v těžkém prostředí / nízké energii
            double baseU = 0.35;
            baseU += -0.10 * p.StressLevel + -0.10 * p.Fatigue + 0.05 * (1 - ctx.NormPressure01);
            return Bx.Clamp01(baseU);
        }
    }
}
