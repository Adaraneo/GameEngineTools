﻿// ReturnComplimen.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// <summary>
    /// Reakce na pochvalu: vrátím jemný kompliment zpět.
    /// </summary>
    public sealed class ReturnCompliment : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.ComplimentLight;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Compliment,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.25f, -1f, 1f),
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.10f, 0f, 1f),
                    Privacy = ctx.Ix.Privacy,
                    Risk = ctx.Ix.Risk,
                    SocialAudience = ctx.Ix.SocialAudience,
                    SharedGoal = ctx.Ix.SharedGoal,
                    Continuity = Math.Clamp(ctx.Ix.Continuity + 0.10f, 0f, 1f),
                    Physicality = Math.Clamp(ctx.Ix.Physicality + 0.05f, 0f, 1f)
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && ctx.Situation == SituationType.PraiseReceived;

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality;
            var psy = ctx.Actor.Psychology;
            double E = per.BigFive[BigFiveTrait.Extraversion];
            double A = per.BigFive[BigFiveTrait.Agreeableness];

            double liking = (ctx.Rel?.Liking ?? 50f) / 100.0;

            double u = 0.15
                     + 0.25 * E
                     + 0.20 * A
                     + 0.15 * liking
                     + 0.15 * (0.5 + 0.5 * psy.Mood)
                     + 0.15 * ctx.Goals.AffiliationNeed01
                     - 0.10 * psy.StressLevel;

            return Bx.Clamp01(u);
        }
    }
}
