﻿// RelationshipsDecayBackgroundService.cs
// Copyright (c) 50PSoftware

using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using GameEngineTools.Logging;
using GameEngineTools.World.Core.Time;
using GameEngineTools.World.Utils.Time;

namespace GameEngineTools.Characters.CharacterModel.Relationships.Decay
{
    public sealed class RelationshipsDecayBackgroundService : BackgroundService
    {
        private readonly RelationshipManager _rm;
        private readonly IClock _clock;
        private readonly RelationshipsDecayOptions _opt;
        private readonly ILogger<RelationshipsDecayBackgroundService> _log;

        public RelationshipsDecayBackgroundService(
            RelationshipManager rm,
            IClock clock,
            IOptions<RelationshipsDecayOptions> opt,
            ILogger<RelationshipsDecayBackgroundService> log)
        {
            _rm = rm;
            _clock = clock;
            _opt = opt.Value;
            _log = log;
        }

        public override Task StartAsync(CancellationToken cancellationToken)
        {
            _log.LogInformation(LogIds.RelDecayStarted,"{Service} starting…", nameof(RelationshipsDecayBackgroundService));
            return base.StartAsync(cancellationToken);
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            _log.LogInformation(LogIds.RelDecayStarted, "{Service} stopping…", nameof(RelationshipsDecayBackgroundService));
            return base.StopAsync(cancellationToken);
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            var last = _clock.Now;

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    var now = _clock.Now;
                    var dt = now - last;

                    if (dt <= WTimeSpan.Zero)
                    {
                        // nic k dělání (čas neposkočil/přetočen zpět)
                    }
                    else
                    {
                        // ochraň catch-up
                        if (dt > _opt.MaxCatchUp) dt = _opt.MaxCatchUp;

                        // rozkouskuj na pevné kroky (stabilnější výsledky)
                        var step = _opt.DecayStep;
                        while (dt > WTimeSpan.Zero)
                        {
                            var chunk = dt > step ? step : dt;
                            _rm.TickDecay(_clock, chunk); // viz partial níže
                            dt -= chunk;
                        }

                        last = now;
                    }
                }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                {
                    // Graceful shutdown
                    break;
                }
                catch (Exception ex)
                {
                    _log.LogError(LogIds.RelDecayFailed, ex, "Error in {Service} while processing relationship decay.\n{Message}", nameof(RelationshipsDecayBackgroundService), ex.Message);
                }

                try
                {
                    await Task.Delay((int)_opt.WakeInterval.TotalSeconds * 1000, stoppingToken);
                }
                catch (TaskCanceledException) { /* shutdown */ }
            }
        }
    }
}

