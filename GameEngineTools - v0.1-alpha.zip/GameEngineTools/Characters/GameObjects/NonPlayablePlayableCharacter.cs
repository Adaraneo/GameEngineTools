﻿// NonPlayablePlayableCharacter.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.GameObjects
{
    using System.Text.Json.Serialization;
    using GameEngineTools.Armory;
    using GameEngineTools.Characters.CharacterModel.Homo;

    /// <summary>
    /// Non-Playable/Playable Character
    /// </summary>
    public abstract class NPPC
    {
        [JsonInclude]
        [JsonPropertyName("Armor")]
        private ArmorSet armor;

        private double health;

        [JsonInclude]
        [JsonPropertyName("Protection")]
        private double protection;

        internal NPPC()
        { }

        internal NPPC(double maxHealth, Person person)
        {
            this.protection = 0;
            MaxHealth = maxHealth;
            Health = MaxHealth;
            this.Person = person;
            People.Add(person);
        }

        [JsonIgnore]
        public static List<Person> People { get; } = new List<Person>();

        [JsonIgnore]
        public ArmorSet Armor
        {
            get
            {
                return armor;
            }
            set
            {
                this.armor = value;
                this.protection = armor.Protection;
            }
        }

        [JsonInclude]
        public double Health
        {
            get
            {
                return this.health;
            }
            private set
            {
                this.health = value;
            }
        }

        public double MaxHealth { get; set; }

        public Person Person { get; set; }

        [JsonIgnore]
        public double Protection
        {
            get
            {
                return this.protection;
            }
        }

        [JsonIgnore]
        public SpeechProfile Speech { get; } = new();

        [JsonIgnore]
        public StatusType Status => Person.Status;

        public Weapon Weapon { get; set; }

        public virtual void DecreaseHealth(double amount)
        {
            this.health -= amount;
            if (this.health <= 0)
            {
                this.Person.Die();
            }
        }

        public bool Equals(NPPC other)
        {
            if (other == null)
            {
                return false;
            }

            if (this.Person.Equals(other.Person))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override bool Equals(object? obj)
        {
            if (obj == null || (!(obj is NPPC)))
            {
                return false;
            }
            else
            {
                return Equals(obj as NPPC);
            }
        }

        public virtual void IncreaseHealth(double amount)
        {
            this.health += amount;
            if (health > MaxHealth)
            {
                this.health = MaxHealth;
            }
        }
    }
}
