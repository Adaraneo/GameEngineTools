﻿// PlanEngine.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Planning
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public sealed class PlanEngine
    {
        private readonly IEnumerable<IBehaviorPlan> _plans;
        private readonly ActivePlans _active;
        public PlanEngine(IEnumerable<IBehaviorPlan> plans, ActivePlans active) { _plans = plans; _active = active; }

        public bool TryTickOrStart(BehaviorContext ctx, Func<BehaviorType, BehaviorContext, bool> enact)
        {
            if (_active.TryGet(ctx.Actor.DNA, out var running))
            {
                var s = running.Tick(ctx, enact);
                if (s is PlanStatus.Succeeded or PlanStatus.Failed) _active.Complete(ctx.Actor.DNA);
                return true;
            }

            var candidate = _plans.FirstOrDefault(p => p.CanStart(ctx));
            if (candidate is null) return false;

            _active.Start(ctx.Actor.DNA, candidate);
            var s2 = candidate.Tick(ctx, enact);
            if (s2 is PlanStatus.Succeeded or PlanStatus.Failed) _active.Complete(ctx.Actor.DNA);
            return true;
        }
    }
}
