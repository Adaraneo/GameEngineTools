﻿// BondStageVector.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships
{
    using System.Collections.Generic;

    public class BondStageVector
    {
        public record BondStageVectorAxes(float ClosenessMin, float LikingMin, float TrustMin, float? AttractionMin);
        public Dictionary<BondStage, BondStageVectorAxes> Axes { get; set; }
    }
}
