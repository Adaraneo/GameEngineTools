﻿// RefuseHelp.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// <summary>
    /// Zdvořilé odmítnutí pomoci (reakce na RequestHelp nebo situace se slabým shared goal).
    /// </summary>
    public sealed class RefuseHelp : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.Refuse;

        public void Apply(in BehaviorContext ctx)
        {
            // Odmítnutí mapujeme na "Honesty" s mírně negativním tónem a vyšším rizikem.
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Honesty,
                When = ctx.When,
                IsMicro = false,
                Context = new InteractionContext
                {
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone - 0.10f, -1f, 1f),
                    Depth = Math.Clamp(ctx.Ix.Depth - 0.05f, 0f, 1f),
                    Privacy = Math.Max(ctx.Ix.Privacy, 0.4f),
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.10f, 0f, 1f),
                    SocialAudience = ctx.Ix.SocialAudience,
                    SharedGoal = ctx.Ix.SharedGoal,
                    Continuity = ctx.Ix.Continuity
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && (ctx.Situation == SituationType.RequestHelp || ctx.Ix.SharedGoal < 0.25f);

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality;
            var psy = ctx.Actor.Psychology;

            double C = per.BigFive[BigFiveTrait.Conscientiousness];
            double A = per.BigFive[BigFiveTrait.Agreeableness];

            // K odmítnutí táhne únava/stres/nízka motivace, slabý společný cíl, nízká sympatie/trust
            double liking = (ctx.Rel?.Liking ?? 50f) / 100.0;
            double trust = (ctx.Rel?.Trust ?? 50f) / 100.0;

            double u = 0.05
                     + 0.30 * psy.Fatigue
                     + 0.25 * psy.StressLevel
                     + 0.15 * (1.0 - ctx.Ix.SharedGoal)
                     + 0.10 * (1.0 - liking)
                     + 0.10 * (1.0 - trust)
                     - 0.10 * A
                     - 0.10 * C
                     - 0.10 * ctx.Goals.AffiliationNeed01;

            return Bx.Clamp01(u);
        }
    }
}
