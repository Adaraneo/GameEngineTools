﻿// ArchetypeNormEvaluator.cs
// Copyright (c) 50PSoftware
// ArchetypeNormEvaluator.cs
// Penalizace/bonifikace podle situace (SituationType)
namespace GameEngineTools.Characters.CharacterModel.Behavior.Norms
{
    public sealed class ArchetypeNormEvaluator : INormEvaluator
    {
        public double Evaluate(BehaviorType type, in BehaviorContext ctx)
        {
            // jemně smícháme se „soukromím“ a „publikem“, když je k dispozici
            double priv = ctx.Ix.Privacy;           // 0..1
            double audience = ctx.Ix.SocialAudience;// 0..1

            double s = 0.0;
            switch (ctx.Situation)
            {
                case SituationType.WorkTask:
                    if (type is BehaviorType.Kiss or BehaviorType.KissLight
                                or BehaviorType.InitiateIntimacySoft or BehaviorType.InitiateIntimacyBold)
                        s -= 0.70 + 0.20 * audience;
                    if (type is BehaviorType.FlirtLight or BehaviorType.FlirtBold)
                        s -= 0.45 + 0.20 * audience;
                    if (type is BehaviorType.HonestDisclosureLight or BehaviorType.SelfDisclosureDeep)
                        s -= 0.25 * audience;
                    break;

                case SituationType.GroupSetting:
                    if (type is BehaviorType.SelfDisclosureDeep)
                        s -= 0.40 + 0.20 * audience;
                    if (type is BehaviorType.Confront or BehaviorType.UndermineInPublic or BehaviorType.Retort)
                        s -= 0.50 + 0.25 * audience;
                    break;

                case SituationType.Church: // když ti to takto klasifikuje profil
                case SituationType.PublicSquare:
                    if (type is BehaviorType.Kiss or BehaviorType.InitiateIntimacySoft or BehaviorType.InitiateIntimacyBold)
                        s -= 0.60 + 0.25 * audience;
                    break;

                case SituationType.OneOnOnePrivate:
                    if (type is BehaviorType.SelfDisclosureDeep)
                        s += +0.10 + 0.20 * priv; // malá bonifikace v soukromí
                    if (type is BehaviorType.InitiateIntimacySoft or BehaviorType.KissLight)
                        s += +0.05 + 0.15 * priv;
                    break;

                case SituationType.DateLike:
                    if (type is BehaviorType.FlirtLight or BehaviorType.ReturnCompliment) s += 0.10;
                    break;
            }

            // clamp do [-1..0] (INormEvaluator definuje „penalizaci“, záporné je horší; kladné tu ořežeme na 0)
            return s < 0 ? s : 0.0;
        }
    }
}

