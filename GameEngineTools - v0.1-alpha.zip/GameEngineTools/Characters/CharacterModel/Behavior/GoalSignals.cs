﻿// GoalSignals.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior
{
    using GameEngineTools.Characters.CharacterModel.Homo;

    public interface IGoalSignalProvider
    {
        /// Vypočti měkké cíle pro aktéra v daném kontextu (může využít rel k cíli, ale nemusí).
        BehaviorGoals GetGoals(IHuman actor, RelationshipSnapshotForBehavior? relToTarget);
    }

    /// Základ: afiliační potřeba z Psych + vztahu k cíli (čím menší closeness, tím větší "chuť" ji zvyšovat).
    public sealed class SimpleGoalSignalProvider : IGoalSignalProvider
    {
        public BehaviorGoals GetGoals(IHuman actor, RelationshipSnapshotForBehavior? relToTarget)
        {
            var psy = actor.Psychology;
            // SocialDrive je 0..1, Mood je -1..1 -> 0..1
            double mood01 = 0.5 + 0.5 * psy.Mood;
            double closeness01 = relToTarget.HasValue ? relToTarget.Value.Closeness / 100.0 : 0.5;
            double need = 0.55 * psy.SocialDrive + 0.20 * (1.0 - closeness01) + 0.15 * mood01 + 0.10 * (1.0 - psy.StressLevel);
            return new BehaviorGoals((float)System.Math.Clamp(need, 0.0, 1.0));
        }
    }
}
