﻿// Observation.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.World.Knowledge
{
    using GameEngineTools.World.Utils.Time;

    public sealed record Observation(Guid WitnessId, Guid SubjectId, string Claim, float Confidence, WDateTime When);
}
