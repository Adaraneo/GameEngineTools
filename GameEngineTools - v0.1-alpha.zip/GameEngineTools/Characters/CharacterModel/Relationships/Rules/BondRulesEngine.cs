﻿// BondRulesEngine.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships.Rules
{
    using Microsoft.Extensions.Options;
    using GameEngineTools.Characters.CharacterModel.Events;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.World.Core.Time;
    using GameEngineTools.World.Utils.Time;
    using Microsoft.Extensions.Logging;
    using GameEngineTools.Logging;
    using GameEngineTools.Config;

    public sealed class BondRulesEngine
    {
        private readonly RelationshipManager rm;
        private readonly IClock clock;
        private readonly IEventBus bus;
        private readonly BondRulesOptions opt;
        private readonly ILogger<BondRulesEngine> log;

        public BondRulesEngine(RelationshipManager rm, IClock clock, IEventBus bus, IOptions<BondRulesOptions> options, ILogger<BondRulesEngine> log)
        {
            this.rm = rm;
            this.clock = clock;
            this.bus = bus;
            this.opt = options.Value;
            this.log = log;
        }

        public void Apply(IEnumerable<Relationship> rels, WDateTime now)
        {
            // 1) Stage z os (s EMA/hysterezí)
            var thresholds = GetThresholds();

            foreach (var r in rels)
            {
                var prevStage = r.Stage;
                var prevKind = r.Kind;

                r.UpdateEma(r.StageHoldDays);
                r.EvaluateStage(thresholds, opt.StageEmaDays);

                HandlePartnership(r, now);       // Partner / Ex
                HandleNegativeMilestones(r, now); // Enemy / Rival

                if (r.Stage != prevStage)
                {
                    bus.PublishAsync(new RelationshipStageChangedEvent(now, r, prevStage, r.Stage));
                    log.RelStageChanged(now.ToString("O"), r.From.DNA.ToString(), r.To.DNA.ToString(),
                        prevStage.ToString(), r.Stage.ToString());
                }
                if (r.Kind != prevKind)
                    bus.PublishAsync(new RelationshipKindChangedEvent(now, r, prevKind, r.Kind));
            }

            // 2) Měkké dorovnání asymetrie (volitelné)
            if (opt.AsymmetryInertia is >= 0f and < 1f) SoftenAsymmetry(rels, opt.AsymmetryInertia);
        }

        public BondStageVector GetThresholds() => new()
        {
            Axes = new()
            {
                { BondStage.Friend,    new(opt.FriendMinCloseness,    opt.FriendMinLiking,    opt.FriendMinTrust, null) },
                { BondStage.Familiar,  new(opt.FamiliarMinCloseness, opt.FamiliarMinLiking, opt.FamiliarMinTrust, null) },
                { BondStage.Intimate,  new(opt.IntimateMinCloseness, opt.IntimateMinLiking, opt.IntimateMinTrust, opt.IntimateMinAttraction) },
                { BondStage.Stranger,  new(float.MinValue, float.MinValue, float.MinValue, null) }
            }
        };

        private void HandlePartnership(Relationship rel, WDateTime now)
        {
            if (!rm.TryGetRelationship(rel.To, rel.From, out var back)) return;

            bool cycleGate(Relationship r)
            {
                var cy = r.To?.Body?.Cycle;
                if (cy is { Enabled: true })
                {
                    var trustReq = opt.PartnerAddMinTrust + (cy.IsPMS ? 3f : 0f);
                    if (r.Trust < trustReq) return false;
                }
                return true;
            }

            // penalizace prahů podle Repair.Debt (0..1)
            float debtA = rel.Repair?.Debt ?? 0f;   // A -> B
            float debtB = back.Repair?.Debt ?? 0f;  // B -> A
            float trustPenA = 1f + 0.40f * debtA;   // až +40 % na trust
            float trustPenB = 1f + 0.40f * debtB;
            float attractPenA = 1f + 0.20f * debtA; // až +20 % na attraction
            float attractPenB = 1f + 0.20f * debtB;

            bool addGate =
                MeetsAddAxes(rel) &&
                rel.Attraction >= opt.PartnerAddMinAttraction * attractPenA &&
                rel.Trust >= opt.PartnerAddMinTrust * trustPenA &&
                cycleGate(rel) &&
                MeetsAddAxes(back) &&
                back.Attraction >= opt.PartnerAddMinAttraction * attractPenB &&
                back.Trust >= opt.PartnerAddMinTrust * trustPenB &&
                cycleGate(back) &&
                IsRomanceAllowed(rel) && IsRomanceAllowed(back);


            if (addGate)
            {
                var oldA = rel.Kind; var oldB = back.Kind;
                rel.SetKind(BondKind.Romantic); rel.AddTags(BondTag.Partner); rel.MarkPartnerAddedNow(clock);
                back.SetKind(BondKind.Romantic); back.AddTags(BondTag.Partner); back.MarkPartnerAddedNow(clock);
            }
            else
            {
                var hasA = (rel.Tags & BondTag.Partner) != 0;
                var hasB = (back.Tags & BondTag.Partner) != 0;

                if (hasA || hasB)
                {
                    bool bothLow =
                        MeetsBreakAxes(rel) && rel.Attraction <= opt.PartnerBreakMaxAttraction &&
                        MeetsBreakAxes(back) && back.Attraction <= opt.PartnerBreakMaxAttraction;

                    bool cooldownOk =
                        (!hasA || rel.CanLosePartnerTag(clock, opt.PartnerMinDuration)) &&
                        (!hasB || back.CanLosePartnerTag(clock, opt.PartnerMinDuration));

                    if (bothLow && cooldownOk)
                    {
                        if (hasA) { rel.RemoveTags(BondTag.Partner); rel.AddTags(BondTag.Ex); rel.SetKind(BondKind.Neutral); rel.ClearPartnerSince(); }
                        if (hasB) { back.RemoveTags(BondTag.Partner); back.AddTags(BondTag.Ex); back.SetKind(BondKind.Neutral); back.ClearPartnerSince(); }
                    }
                }
                else
                {
                    // Friend/Familiar → Friend kind; jinak Neutral
                    if (thresholdsFor(rel.Stage, out var ks) &&
                        rel.Closeness >= ks.ClosenessMin && rel.Liking >= ks.LikingMin && rel.Trust >= ks.TrustMin &&
                        (rel.Stage is BondStage.Friend or BondStage.Familiar))
                        rel.SetKind(BondKind.Friend);
                    else
                        rel.SetKind(BondKind.Neutral);
                }
            }

            bool thresholdsFor(BondStage s, out (float ClosenessMin, float LikingMin, float TrustMin) t)
            {
                t = s switch
                {
                    BondStage.Friend => (opt.FriendMinCloseness, opt.FriendMinLiking, opt.FriendMinTrust),
                    BondStage.Familiar => (opt.FamiliarMinCloseness, opt.FamiliarMinLiking, opt.FamiliarMinTrust),
                    _ => default
                };
                return s is BondStage.Friend or BondStage.Familiar;
            }
        }

        private void HandleNegativeMilestones(Relationship r, WDateTime now)
        {
            if (r.Trust <= opt.EnemyMaxTrust && r.Liking <= opt.EnemyMaxLiking)
            {
                r.SetKind(BondKind.Enemy);
                r.RemoveTags(BondTag.Partner);
            }
            else if (r.Closeness >= opt.RivalMinCloseness && r.Liking <= opt.RivalMaxLiking)
            {
                r.SetKind(BondKind.Rival);
                r.RemoveTags(BondTag.Partner);
            }
        }

        private bool MeetsAddAxes(Relationship r) =>
            r.Closeness >= opt.PartnerAddMinCloseness &&
            r.Liking >= opt.PartnerAddMinLiking &&
            r.Trust >= opt.PartnerAddMinTrust;

        private bool MeetsBreakAxes(Relationship r) =>
            r.Closeness <= opt.PartnerBreakMaxCloseness ||
            r.Liking <= opt.PartnerBreakMaxLiking ||
            r.Trust <= opt.PartnerBreakMaxTrust;

        private static bool IsRomanceAllowed(Relationship r)
        {
            if (r.From.Age < 18 || r.To.Age < 18) return false;
            return r.Kinship is not (KinshipRole.Father or KinshipRole.Mother
                                   or KinshipRole.Son or KinshipRole.Daughter
                                   or KinshipRole.Brother or KinshipRole.Sister);
        }

        private static void SoftenAsymmetry(IEnumerable<Relationship> rels, float k)
        {
            var byPair = new Dictionary<(IHuman, IHuman), Relationship>();
            foreach (var r in rels) byPair[(r.From, r.To)] = r;

            var seen = new HashSet<(IHuman, IHuman)>();
            foreach (var kv in byPair)
            {
                var (from, to) = kv.Key;
                if (seen.Contains((to, from))) continue;
                if (!byPair.TryGetValue((to, from), out var ba)) continue;

                var ab = kv.Value;
                float avgL = 0.5f * (ab.Liking + ba.Liking);
                float avgT = 0.5f * (ab.Trust + ba.Trust);
                float avgC = 0.5f * (ab.Closeness + ba.Closeness);

                ab.SetLiking(k * ab.Liking + (1f - k) * avgL);
                ba.SetLiking(k * ba.Liking + (1f - k) * avgL);

                ab.SetTrust(k * ab.Trust + (1f - k) * avgT);
                ba.SetTrust(k * ba.Trust + (1f - k) * avgT);

                ab.SetCloseness(k * ab.Closeness + (1f - k) * avgC);
                ba.SetCloseness(k * ba.Closeness + (1f - k) * avgC);

                seen.Add((from, to));
            }
        }
    }

}
