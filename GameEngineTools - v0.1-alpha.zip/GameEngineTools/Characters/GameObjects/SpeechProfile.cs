﻿// SpeechProfile.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.GameObjects
{
    public class SpeechProfile
    {
        public double Boldness { get; set; } = 0.5;
        public double Eloquence { get; set; } = 0.5; // slovní plynulost

        // říká věci na rovinu?
        public double Honesty { get; set; } = 0.5;   // pravdomluvnost

        public double Warmth { get; set; } = 0.5;    // emocionální tón
    }
}
