﻿// FlirtBold.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    public sealed class FlirtBold : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.FlirtBold;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Flirt,
                When = ctx.When,
                IsMicro = false,
                Context = new InteractionContext
                {
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.30f, -1f, 1f),
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.20f, 0f, 1f),
                    Physicality = Math.Clamp(ctx.Ix.Physicality + 0.25f, 0f, 1f),
                    Privacy = ctx.Ix.Privacy,
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.15f, 0f, 1f),
                    SocialAudience = 0f,
                    SharedGoal = ctx.Ix.SharedGoal,
                    Continuity = ctx.Ix.Continuity
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
        {
            if (ctx.Target is null || !ctx.Rel.HasValue) return false;
            var rel = ctx.Rel.Value;
            return rel.Stage >= BondStage.Friend && rel.Attraction > 40f && ctx.Ix.Privacy >= 0.5f && ctx.Ix.SocialAudience <= 0.2f;
        }

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality;
            var psy = ctx.Actor.Psychology;
            var rel = ctx.Rel!.Value;

            double riskOk = 1.0 - ctx.Ix.Risk;
            double u = 0.05 + 0.65 * (rel.Attraction / 100.0) + 0.15 * per.BigFive[Homo.BigFiveTrait.Extraversion]
                       + 0.15 * psy.Arousal + 0.10 * ctx.Ix.Privacy + 0.05 * riskOk
                       - 0.25 * psy.StressLevel;
            return Bx.Clamp01(u);
        }
    }
}
