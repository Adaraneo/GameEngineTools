﻿// HumanPhysiology.Metrics.cs
// Odvozené metriky, BMR/TDEE, životní styl, smysly
namespace GameEngineTools.Characters.Homo
{
    using System;
    using System.Text.Json.Serialization;
    using GameEngineTools; // GenusType

    public enum ActivityLevel
    { Sedentary, Light, Moderate, High, Athlete }

    /// <summary>ABO blood group.</summary>
    public enum BloodType
    { A, B, AB, O }

    public enum ImmunityLevel
    { Low, Average, High }

    public enum MetabolismRate
    { Slow, Average, Fast }

    public enum RhFactor
    { Negative, Positive }

    public enum SleepChronotype
    { Lark, Neutral, Owl }

    public partial class HumanPhysiology
    {
        private Guid dna;

        private static double SafeRatio(double a, double b) => b <= 1e-6 ? 0.0 : a / b;

        private TorsoSilhouette ComputeTorsoSilhouette()
        {
            // jednoduchá silueta podle rozdílů (cm); prahy si můžeš dát do Configu
            double bw = BustCm - WaistCm;
            double hw = HipsCm - WaistCm;

            if (bw >= 22 && hw >= 22 && Math.Abs(BustCm - HipsCm) <= 7) return TorsoSilhouette.Hourglass;
            if (bw >= 22 && BustCm > HipsCm + 7) return TorsoSilhouette.TopHourglass;
            if (hw >= 22 && HipsCm > BustCm + 7) return TorsoSilhouette.BottomHourglass;
            if (BustCm >= HipsCm + 9) return TorsoSilhouette.InvertedTriangle;
            if (HipsCm >= BustCm + 9) return TorsoSilhouette.Triangle;
            return TorsoSilhouette.Straight;
        }

        internal static double ActivityLevelFactor(ActivityLevel level) => level switch
        {
            ActivityLevel.Sedentary => 1.2,
            ActivityLevel.Light => 1.375,
            ActivityLevel.Moderate => 1.55,
            ActivityLevel.High => 1.725,
            ActivityLevel.Athlete => 1.9,
            _ => 1.3
        };

        public enum TorsoSilhouette
        { Straight, Triangle, InvertedTriangle, Hourglass, TopHourglass, BottomHourglass }

        public ActivityLevel ActivityLevel { get; set; } = ActivityLevel.Light;
        public string[] Allergies { get; set; } = Array.Empty<string>();
        public BloodType Blood { get; set; }

        [JsonIgnore]
        public double BMI => HeightCm > 0 ? WeightKg / Math.Pow(HeightCm / 100d, 2) : 0;

        /// <summary>Du Bois BSA (m²).</summary>
        [JsonIgnore]
        public double BSA =>
            (WeightKg > 0 && HeightCm > 0) ? 0.007184 * Math.Pow(WeightKg, 0.425) * Math.Pow(HeightCm, 0.725) : 0.0;

        public double BustDelta => Math.Max(0, BustCm - UnderbustCm);
        public double BustToHip => SafeRatio(BustCm, HipsCm);
        public double BustToWaist => SafeRatio(BustCm, WaistCm);
        // rozdíl bust–underbust

        [JsonIgnore]
        public Guid DNA
        {
            get => dna == Guid.Empty ? dna = Guid.NewGuid() : dna;
            set => dna = value;
        }

        /// <summary>Hrubý odhad VO₂max (ml/kg/min) z RHR a aktivity.</summary>
        [JsonIgnore]
        public double EstimatedVO2Max
        {
            get
            {
                double baseVo2 = 35.0;
                double hrAdj = (70 - RestingHeartRateBpm) * 0.4;
                double actAdj = ActivityLevel switch
                {
                    ActivityLevel.Sedentary => -2.0,
                    ActivityLevel.Light => 0.0,
                    ActivityLevel.Moderate => 3.0,
                    ActivityLevel.High => 6.0,
                    ActivityLevel.Athlete => 10.0,
                    _ => 0.0
                };
                return Math.Max(15.0, baseVo2 + hrAdj + actAdj);
            }
        }

        public GenusType Genus { get; set; }

        /// <summary>Prahová hodnota sluchu (dB HL; průměr řečových frekvencí).</summary>
        public int HearingThresholdDbHl { get; set; } = 15;

        /// <summary>Výška (cm).</summary>
        public double HeightCm { get; set; }

        public SleepChronotype Chronotype { get; set; } = SleepChronotype.Neutral;
        public ImmunityLevel ImmunityLevel { get; set; } = ImmunityLevel.Average;
        public string[] Intolerances { get; set; } = Array.Empty<string>();
        public MetabolismRate MetabolismRate { get; set; } = MetabolismRate.Average;

        // Životní styl & smysly
        public int RestingHeartRateBpm { get; set; } = 65;

        public RhFactor Rh { get; set; }
        public double SleepNeedHours { get; set; } = 7.5;
        public TorsoSilhouette TorsoShape => ComputeTorsoSilhouette();

        /// <summary>Refrakce (D; záporné=myopie, kladné=hyperopie).</summary>
        public double VisionSphereD { get; set; } = -0.25;

        /// <summary>Hmotnost (kg).</summary>
        public double WeightKg { get; set; }

        // Odvozené proporční metriky
        [JsonIgnore] public double WHR => HipsCm > 0 ? WaistCm / HipsCm : 0;

        [JsonIgnore] public double WtHR => HeightCm > 0 ? WaistCm / HeightCm : 0;

        /// <summary>Harris–Benedict BMR (kcal/den) – zachovávám původní.</summary>
        public double GetBMR(double ageYears) =>
            Genus == GenusType.Male
                ? 88.36 + (13.4 * WeightKg) + (4.8 * HeightCm) - (5.7 * ageYears)
                : 447.6 + (9.2 * WeightKg) + (3.1 * HeightCm) - (4.3 * ageYears);

        /// <summary>Mifflin–St Jeor BMR (kcal/den) – volitelně přesnější.</summary>
        public double GetBMR_Mifflin(double ageYears) =>
            Genus == GenusType.Male
                ? 10 * WeightKg + 6.25 * HeightCm - 5 * ageYears + 5
                : 10 * WeightKg + 6.25 * HeightCm - 5 * ageYears - 161;

        /// <summary>TDEE = BMR * activityFactor.</summary>
        public double GetTDEE(double ageYears, bool useMifflin = false)
        {
            var bmr = useMifflin ? GetBMR_Mifflin(ageYears) : GetBMR(ageYears);
            return bmr * ActivityLevelFactor(ActivityLevel);
        }
    }
}
