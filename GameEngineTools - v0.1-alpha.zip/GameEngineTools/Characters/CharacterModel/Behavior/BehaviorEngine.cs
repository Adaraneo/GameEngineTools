﻿// BehaviorEngine.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior
{
    using System.Linq;
    using System.Collections.Generic;
    using GameEngineTools.Characters.CharacterModel.Behavior.Engine;
    using GameEngineTools.Characters.CharacterModel.Behavior.Norms;
    using GameEngineTools.Logging;
    using Microsoft.Extensions.Logging;

    internal static class Bx // pár helperů
    {
        public static float Clamp01(double v) => (float)(v < 0 ? 0 : (v > 1 ? 1 : v));

        public static float Mix(double a, double b, double t) => (float)(a + (b - a) * Clamp01(t));

        public static (double O, double C, double E, double A, double N) ReadBigFive(Homo.Personality p)
            => (p.BigFive[Homo.BigFiveTrait.Openness],
                p.BigFive[Homo.BigFiveTrait.Conscientiousness],
                p.BigFive[Homo.BigFiveTrait.Extraversion],
                p.BigFive[Homo.BigFiveTrait.Agreeableness],
                p.BigFive[Homo.BigFiveTrait.Neuroticism]);
    }

    public interface IBehaviorOption
    {
        BehaviorType Type { get; }

        void Apply(in BehaviorContext ctx);

        bool IsApplicable(in BehaviorContext ctx);

        float Utility(in BehaviorContext ctx);
    }

    public sealed class BehaviorEngine
    {
        private readonly INormEvaluator _norms;
        private readonly ILogger<BehaviorEngine> _log;

        public BehaviorEngine(INormEvaluator norms, ILogger<BehaviorEngine> log)
        { _norms = norms; _log = log; }
        public IBehaviorOption? Select(BehaviorContext ctx, IEnumerable<IBehaviorOption> options)
        {
            return SelectWithTrace(ctx, options, out _);
        }

        public IBehaviorOption? SelectWithTrace(BehaviorContext ctx, IEnumerable<IBehaviorOption> options, out List<(IBehaviorOption opt, float u)> scored)
        {
            var mem = ctx.Actor.Psychology.ShortMemory ?? new BehaviorMemory();
            IBehaviorOption? best = null;
            var bestScore = double.NegativeInfinity;
            scored = new();

            foreach (var opt in options)
            {
                if (!opt.IsApplicable(ctx)) continue;
                double s = BehaviorScoring.Score(ctx, opt, mem);
                s += _norms.Evaluate(opt.Type, ctx);
                scored.Add((opt, (float)s));
                if (_log.IsEnabled(LogLevel.Debug))
                    _log.BehaviorCandidate(opt, (float)s);
                if (s > bestScore) { bestScore = s; best = opt; }
            }

            if (best != null && scored.Count > 1 && Random.Shared.NextDouble() < BehaviorScoring.Epsilon)
            {
                var ranked = scored.OrderByDescending(s => s.u).ToList();
                int k = Math.Min(3, ranked.Count);
                best = ranked[Random.Shared.Next(k)].opt;
            }

            if (best != null)
            {
                mem.Bump(best.Type, ctx.When);
                ctx.Actor.Psychology.ShortMemory = mem;
            }

            if (_log.IsEnabled(LogLevel.Debug))
                _log.BehaviorDecision(ctx, scored, best);

            return best;
        }
    }
}
