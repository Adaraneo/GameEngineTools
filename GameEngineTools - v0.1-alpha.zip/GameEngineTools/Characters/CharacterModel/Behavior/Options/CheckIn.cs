﻿// CheckIn.cs
// Copyright (c) 50PSoftware

using GameEngineTools.Characters.CharacterModel.Homo;
using GameEngineTools.Characters.CharacterModel.Relationships;

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    /// Jemné „vše v pohodě?“ – podpůrný ping.
    public sealed class CheckIn : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.AskOpenQuestion;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.SpendTime,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    Privacy = Math.Clamp(ctx.Ix.Privacy + 0.05f, 0f, 1f),
                    Risk = ctx.Ix.Risk,
                    SharedGoal = ctx.Ix.SharedGoal,
                    SocialAudience = ctx.Ix.SocialAudience,
                    Continuity = Math.Clamp(ctx.Ix.Continuity + 0.05f, 0f, 1f),
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.08f, 0f, 1f),
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.10f, -1f, 1f),
                    Warmth = Math.Clamp(ctx.Ix.Warmth + 0.10f, 0f, 1f)
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null;

        public float Utility(in BehaviorContext ctx)
        {
            var psy = ctx.Actor.Psychology; var per = ctx.Actor.Personality;
            double A = per.BigFive[BigFiveTrait.Agreeableness];
            double u = 0.10 + 0.25 * A + 0.20 * psy.SocialDrive + 0.10 * (0.5 + 0.5 * psy.Mood)
                       - 0.10 * ctx.CrowdNoise01 - 0.08 * psy.Fatigue;
            return Bx.Clamp01(u);
        }
    }
}
