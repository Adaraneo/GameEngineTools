﻿// DateInvitePlan.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Planning
{
    public sealed class DateInvitePlan : IBehaviorPlan
    {
        private int _i;
        private static readonly BehaviorType[] Seq =
            { BehaviorType.SuggestSharedActivity, BehaviorType.AskForConsent, BehaviorType.InviteSharedActivity };

        public string Name => "DateInvite";

        public bool CanStart(BehaviorContext ctx)
        {
            var rel = ctx.Rel;
            if (ctx.Target is null || rel is null) return false;
            if (rel.Value.HasActiveConflict) return false;

            var trust01 = rel.Value.Trust / 100f;
            var close01 = rel.Value.Closeness / 100f;

            // minimální prahy + nekonfliktní prostředí
            return trust01 >= 0.40f && close01 >= 0.30f && ctx.NormPressure01 <= 0.80f;
        }

        public PlanStatus Tick(BehaviorContext ctx, Func<BehaviorType, BehaviorContext, bool> enact)
        {
            while (_i < Seq.Length)
            {
                if (!enact(Seq[_i], ctx)) return PlanStatus.Failed;
                _i++;
            }
            return PlanStatus.Succeeded;
        }
    }
}

