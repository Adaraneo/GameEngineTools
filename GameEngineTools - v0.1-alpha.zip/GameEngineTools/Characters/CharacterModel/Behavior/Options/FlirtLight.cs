﻿// FlirtLight.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    public sealed class FlirtLight : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.FlirtLight;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Flirt,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.20f, -1f, 1f),
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.10f, 0f, 1f),
                    Physicality = Math.Clamp(ctx.Ix.Physicality + 0.10f, 0f, 1f),
                    Privacy = ctx.Ix.Privacy,
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.10f, 0f, 1f),
                    SocialAudience = ctx.Ix.SocialAudience,
                    SharedGoal = ctx.Ix.SharedGoal,
                    Continuity = ctx.Ix.Continuity
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
        {
            if (ctx.Target is null || !ctx.Rel.HasValue) return false;
            var rel = ctx.Rel.Value;
            return rel.Stage >= BondStage.Friend && rel.Attraction > 20f && ctx.Ix.Privacy >= 0.3f;
        }

        public float Utility(in BehaviorContext ctx)
        {
            var psy = ctx.Actor.Psychology;
            var per = ctx.Actor.Personality;
            double E = per.BigFive[Homo.BigFiveTrait.Extraversion];

            var rel = ctx.Rel!.Value;
            double u = 0.05 + 0.55 * (rel.Attraction / 100.0) + 0.20 * E
                       + 0.10 * psy.Arousal - 0.20 * psy.StressLevel + 0.05 * ctx.Ix.Privacy;
            return Bx.Clamp01(u);
        }
    }
}
