﻿// HumanPhysiology.Appearance.cs
// Copyright (c) 50PSoftware
namespace GameEngineTools.Characters.Homo
{
    public enum DominantHand
    { Left, Right, Ambidextrous }

    // Lokální podpůrné typy pro vzhled
    public enum EyeColor
    { Brown, Blue, Green, Hazel, Gray, Amber, Heterochromia }

    public enum FaceShape
    { Oval, Round, Square, Diamond, Heart, Oblong }

    public enum HairColor
    { Black, Brown, Blonde, Auburn, Red, Gray, White, Dyed }

    public enum HairDensity
    { Sparse, Medium, Dense }

    public enum HairType
    { Straight, Wavy, Curly, Coily }

    public enum SkinTone
    { Fitzpatrick1, Fitzpatrick2, Fitzpatrick3, Fitzpatrick4, Fitzpatrick5, Fitzpatrick6 }

    /// <summary>Somatotyp: ektomorf/mezomorf/endomorf.</summary>
    public struct Somatotype
    {
        public double Ectomorph { get; set; }
        public double Endomorph { get; set; }
        public double Mesomorph { get; set; }

        public static Somatotype Default() => new Somatotype { Ectomorph = 0.34, Mesomorph = 0.33, Endomorph = 0.33 };

        public void Normalize()
        {
            var sum = Ectomorph + Mesomorph + Endomorph;
            if (sum <= 0) { Ectomorph = 0.34; Mesomorph = 0.33; Endomorph = 0.33; return; }
            Ectomorph /= sum; Mesomorph /= sum; Endomorph /= sum;
        }
    }

    public partial class HumanPhysiology
    {
        // Krev/DNA/pohlaví a základní antropometrie jsou v jiných partial souborech – tady vzhled a proporce

        // Proporce
        /// <summary>
        /// obvod hrudníku.
        /// </summary>
        public double BustCm { get; set; }

        public double CalfCircumferenceCm { get; set; }
        public DominantHand DominantHand { get; set; } = DominantHand.Right;
        public EyeColor EyeColor { get; set; } = EyeColor.Brown;
        public FaceShape FaceShape { get; set; } = FaceShape.Oval;
        public HairColor HairColor { get; set; } = HairColor.Brown;
        public HairDensity HairDensity { get; set; } = HairDensity.Medium;

        /// <summary>Délka vlasů v cm (0 = oholené).</summary>
        public double HairLengthCm { get; set; } = 5;

        public HairType HairType { get; set; } = HairType.Straight;
        public bool HasHeterochromia { get; set; } = false;
        public double HipsCm { get; set; }
        public double ChestCm { get; set; }
        public double NeckCm { get; set; }

        /// <summary>Šířka ramen (akromion–akromion), cm.</summary>
        public double ShoulderBreadthCm { get; set; }

        public SkinTone SkinTone { get; set; } = SkinTone.Fitzpatrick2;

        /// <summary>Somatotyp (součet ~1.0).</summary>
        public Somatotype Somatotype { get; set; } = Somatotype.Default();

        public double ThighCircumferenceCm { get; set; }

        /// <summary>
        /// Obvod pod prsy
        /// </summary>
        public double UnderbustCm { get; set; }     // obvod pod prsy

        public double UpperArmCircumferenceCm { get; set; }
        public double WaistCm { get; set; }
    }
}
