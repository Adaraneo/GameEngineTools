﻿// DefaultRelationshipsEngine.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.Engines.Relationships
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using GameEngineTools.Characters.Core;
    using GameEngineTools.World.Utils.Time;
    using Microsoft.Extensions.Options;

    internal sealed class DefaultRelationshipsEngine : IRelationshipsEngine
    {
        public RelationshipState State { get; private set; }

        public RelationshipsConfig Config { get; }

        public DefaultRelationshipsEngine(IOptions<RelationshipsConfig> cfg)
        {
            Config = cfg.Value;
            State = new RelationshipState(new Dictionary<HumanId, RelationshipEdge>());
        }

        public void Handle(IDomainEvent @event, IHumanContext ctx, IEventCollector outbox)
        {
            switch (@event)
            {
                case FirstImpressionFormed fi:
                    Upsert(fi.B, e => e with
                    {
                        Like = Lerp(e.Like, fi.Like, 0.7),
                        Attraction = Lerp(e.Attraction, fi.Attraction, 0.7),
                        Trust = e.Trust <= 0 ? 45 : e.Trust,
                        Closeness = Math.Max(e.Closeness, 10)
                    });
                    break;

                case MicroPositive mp:
                    Upsert(mp.B, e => e with
                    {
                        Like = Bump(e.Like, +2.0),
                        Trust = Bump(e.Trust, +1.0),
                        Closeness = Bump(e.Closeness, +1.5),
                        Comfort = Bump(e.Comfort, +2.0)
                    });
                    break;

                case MicroNegative mn:
                    Upsert(mn.B, e => e with
                    {
                        Like = Bump(e.Like, -2.5),
                        Trust = Bump(e.Trust, -2.0),
                        Comfort = Bump(e.Comfort, -2.0)
                    });
                    break;

                case RepairAttempt ra:
                    Upsert(ra.B, e => e with
                    {
                        Trust = Bump(e.Trust, ra.Accepted ? +4.0 : -4.0),
                        Closeness = Bump(e.Closeness, ra.Accepted ? +3.0 : -3.0)
                    });
                    break;

                case Interactions.InteractionOutcome io:
                    var delta = io.Accepted ? +2.0 : -2.0;
                    Upsert(io.To, e => e with
                    {
                        Closeness = Bump(e.Closeness, delta),
                        Like = Bump(e.Like, io.Accepted ? +1.0 : -1.5),
                        Comfort = Bump(e.Comfort, io.Accepted ? +1.5 : -2.0)
                    });
                    break;
            }
        }

        public void Tick(WDateTime now, WTimeSpan dt, IHumanContext ctx, IEventCollector outbox)
        {
            var days = Math.Max(0, dt.TotalDays);
            if (days == 0) return;

            if (State.Edges.Count == 0) return;

            var dict = new Dictionary<HumanId, RelationshipEdge>(State.Edges);
            foreach (var kv in State.Edges)
            {
                var e = kv.Value;
                var d = Config.DecayPerDay * days;
                var like = Approach(e.Like, 50, d);
                var trust = Approach(e.Trust, 50, d * 0.5);
                var attraction = Approach(e.Attraction, e.Attraction > 50 ? 45 : 35, d * 0.4);
                var close = Approach(e.Closeness, 35, d * 1.2);
                var respect = Approach(e.Respect, 55, d * 0.3);
                var comfort = Approach(e.Comfort, 45, d * 0.6);

                dict[kv.Key] = e with { Like = Clamp(like), Trust = Clamp(trust), Attraction = Clamp(attraction), Closeness = Clamp(close), Respect = Clamp(respect), Comfort = Clamp(comfort) };
            }

            State = new RelationshipState(dict);

            static double Clamp(double v) => Math.Max(0, Math.Min(100, v));
            static double Approach(double cur, double target, double amount) =>
                (cur < target) ? Math.Min(target, cur + amount) : Math.Max(target, cur - amount);
        }

        void Upsert(HumanId other, Func<RelationshipEdge, RelationshipEdge> mut)
        {
            var dict = new Dictionary<HumanId, RelationshipEdge>(State.Edges);
            if (!dict.TryGetValue(other, out var e))
            {
                e = new RelationshipEdge(
                    A: e.A, B: other,
                    Like: 45, Trust: 45, Attraction: 35, Closeness: 10, Respect: 55, Comfort: 40,
                    Breakdown: new DomainBreakdown(50, 50, 50, 50, 50));
            }
            dict[other] = mut(e);
            State = new RelationshipState(dict);
        }

        static double Bump(double v, double by) => Math.Max(0, Math.Min(100, v + by));
        static double Lerp(double a, double b, double t) => a + (b - a) * Math.Clamp(t, 0, 1);
    }
}
