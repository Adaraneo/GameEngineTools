﻿// PersonJsonConverter.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.FileSystem.JsonConverters
{
    using System.Text.Json;
    using System.Text.Json.Serialization;
    using GameEngineTools.Characters.CharacterModel;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;
    using GameEngineTools.Characters.Homo;

    public class PersonJsonConverter : JsonConverter<Person>
    {
        public override Person? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            using (JsonDocument doc = JsonDocument.ParseValue(ref reader))
            {
                JsonElement root = doc.RootElement;

                // Základní data pro konstruktor
                MagicType magicType = MagicType.Unknown;
                var magicTypeProperty = root.GetProperty("MagicType").GetString()!;
                switch (magicTypeProperty)
                {
                    case "Aqua":
                        magicType = MagicType.Water;
                        break;

                    case "Zephyrus":
                        magicType = MagicType.Air;
                        break;

                    case "Ignis":
                        magicType = MagicType.Fire;
                        break;

                    case "Terra":
                        magicType = MagicType.Earth;
                        break;
                }

                var age = root.GetProperty("Age").GetDouble();
                var genus = (GenusType)root.GetProperty("Body").GetProperty("Genus").GetInt32();
                var person = new Person(magicType, age, genus);

                // Name
                if (root.TryGetProperty("Name", out var nameProp))
                {
                    var name = new Name
                    {
                        Original = nameProp.GetProperty("Original").GetString()!,
                        Familiar = nameProp.GetProperty("Familiar").EnumerateArray().Select(x => x.GetString()!).ToArray()
                    };
                    person.Name = name;
                }

                // Surname
                if (root.TryGetProperty("SurnameMF", out var surnameProp))
                {
                    var surname = new Surname();
                    surname.Male = surnameProp.GetProperty("Male").GetString()!;
                    surname.Female = surnameProp.GetProperty("Female").GetString()!;
                    person.SetSurname(surname);
                }

                // Body
                if (root.TryGetProperty("Body", out var bodyProp))
                {
                    //person.Body.HeightCm = bodyProp.GetProperty("HeightCm").GetDouble();
                    //person.Body.WeightKg = bodyProp.GetProperty("WeightKg").GetDouble();
                    //person.Body.Genus = (GenusType)bodyProp.GetProperty("Genus").GetInt32();
                    //person.Body.Blood = (BloodType)bodyProp.GetProperty("Blood").GetInt32();
                    //person.Body.Rh = (RhFactor)bodyProp.GetProperty("Rh").GetInt32();

                    person.Body.ApplyModel(bodyProp.Deserialize<HumanPhysiologyModel>()!);
                }

                // Psychology
                if (root.TryGetProperty("Psychology", out var psyProp))
                {
                    //person.Psychology.Mood = psyProp.GetProperty("Mood").GetDouble();
                    //person.Psychology.StressLevel = psyProp.GetProperty("StressLevel").GetDouble();
                    //person.Psychology.Arousal = psyProp.GetProperty("Arousal").GetDouble();

                    person.Psychology.ApplyModel(psyProp.Deserialize<HumanPsychologyModel>()!);
                }

                // Personality
                if (root.TryGetProperty("Personality", out var persProp))
                {
                    var bigFive = persProp.GetProperty("BigFive");
                    foreach (var kvp in bigFive.EnumerateObject())
                    {
                        var trait = Enum.Parse<BigFiveTrait>(kvp.Name);
                        person.Personality.BigFive[trait] = kvp.Value.GetDouble();
                    }

                    person.Personality.Temperament = (TemperamentType)persProp.GetProperty("Temperament").GetInt32();
                    person.Personality.DecisionStyle = (DecisionStyle)persProp.GetProperty("DecisionStyle").GetInt32();

                    if (persProp.TryGetProperty("Morality", out var moralProp))
                    {
                        foreach (var kvp in moralProp.GetProperty("Scores").EnumerateObject())
                        {
                            var dim = Enum.Parse<MoralDimension>(kvp.Name);
                            person.Personality.Morality[dim] = kvp.Value.GetDouble();
                        }
                    }

                    if (persProp.TryGetProperty("Traits", out var traitsProp))
                    {
                        foreach (var traitVal in traitsProp.EnumerateArray())
                        {
                            var trait = (PersonalityTrait)traitVal.GetInt32();
                            person.Personality.Traits.Add(trait);
                        }
                    }

                    if (persProp.TryGetProperty("PrimaryGoal", out var goalProp))
                    {
                        if (goalProp.ValueKind != JsonValueKind.Null)
                        {
                            person.Personality.PrimaryGoal = new Goal(
                                goalProp.GetProperty("Name").GetString()!,
                                goalProp.TryGetProperty("Description", out var desc) ? desc.GetString() : null,
                                goalProp.TryGetProperty("Priority", out var pri) ? pri.GetDouble() : 0.5
                            );
                        }
                    }

                    if (persProp.TryGetProperty("Values", out var valuesProp))
                    {
                        foreach (var valuesVal in valuesProp.EnumerateArray())
                        {
                            person.Personality.Values.Add(new CoreValue(
                                valuesVal.GetProperty("Name").GetString()!,
                                valuesVal.TryGetProperty("Description", out var desc) ? desc.GetString() : null
                            ));
                        }
                    }

                    if (persProp.TryGetProperty("Fears", out var fearsProp))
                    {
                        foreach (var fearsVal in fearsProp.EnumerateArray())
                        {
                            person.Personality.Fears.Add(new Fear(
                                fearsVal.GetProperty("Name").GetString()!,
                                fearsVal.TryGetProperty("Description", out var desc) ? desc.GetString() : null
                            ));
                        }
                    }

                    if (persProp.TryGetProperty("Hobbies", out var hobbiesProp))
                    {
                        foreach (var hobbiesVal in hobbiesProp.EnumerateArray())
                        {
                            person.Personality.Hobbies.Add(new Hobby(
                                hobbiesVal.GetProperty("Name").GetString()!,
                                hobbiesVal.TryGetProperty("Description", out var desc) ? desc.GetString() : null
                            ));
                        }
                    }

                    if (persProp.TryGetProperty("Experiences", out var experiencesProp))
                    {
                        foreach (var experiencesVal in experiencesProp.EnumerateArray())
                        {
                            person.Personality.Experiences.Add(new Experience(
                                experiencesVal.GetProperty("Name").GetString()!,
                                experiencesVal.TryGetProperty("Description", out var desc) ? desc.GetString() : null
                            ));
                        }
                    }
                }

                // Relations
                if (root.TryGetProperty("Relationships", out var rels))
                {
                    var relsJson = rels.GetRawText();
                    var exportRelationships = JsonSerializer.Deserialize<Dictionary<Guid, RelationshipModel>>(relsJson, options);
                    person.ExportRelationships = exportRelationships!;
                }

                if (root.TryGetProperty("CivilStatus", out var relationshipProp))
                {
                    person.CivilStatus = (CivilStatus)relationshipProp.GetInt32();
                }

                return person;
            }
        }

        public override void Write(Utf8JsonWriter writer, Person value, JsonSerializerOptions options)
        {
            JsonSerializer.Serialize(writer, new
            {
                MagicType = value.GetMagicName(),
                Age = value.Age,
                Name = value.Name,
                SurnameMF = value.GetSurname(),
                Body = value.Body.ToModel(),
                Psychology = value.Psychology.ToModel(),
                Personality = value.Personality,
                Relationships = value.ExportRelationships,
                CivilStatus = value.CivilStatus
            }, options);
        }
    }
}
