﻿// InitiateIntimacySoft.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// Jemný start intimity (Sex) – jen v bezpečných podmínkách.
    public sealed class InitiateIntimacySoft : IBehaviorOption
    {
        // nepřidáváme nový BehaviorType, sdílí cooldown s FlirtBold
        public BehaviorType Type => BehaviorType.FlirtBold;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Sex,
                When = ctx.When,
                IsMicro = false,
                Context = new InteractionContext
                {
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.35f, -1f, 1f),
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.35f, 0f, 1f),
                    Physicality = Math.Clamp(ctx.Ix.Physicality + 0.60f, 0f, 1f),
                    Warmth = Math.Clamp(ctx.Ix.Warmth + 0.30f, 0f, 1f),
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.12f, 0f, 1f),
                    Privacy = Math.Max(ctx.Ix.Privacy, 0.70f),
                    SocialAudience = 0.0f,
                    SharedGoal = Math.Clamp(ctx.Ix.SharedGoal + 0.20f, 0f, 1f),
                    Continuity = Math.Clamp(ctx.Ix.Continuity + 0.20f, 0f, 1f)
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
        {
            if (ctx.Target is null || !ctx.Rel.HasValue) return false;
            var r = ctx.Rel.Value;
            bool stageOk = r.Stage >= BondStage.Intimate;
            bool trustOk = r.Trust >= 60f;
            bool attractOk = r.Attraction >= 60f;
            bool privacyOk = ctx.Ix.Privacy >= 0.60f && ctx.Ix.SocialAudience <= 0.05f;
            bool moodOk = ctx.Actor.Psychology.Mood >= -0.1f && ctx.Actor.Psychology.StressLevel <= 0.55f;
            bool arousalOk = ctx.Actor.Psychology.Arousal >= 0.40f;
            return stageOk && trustOk && attractOk && privacyOk && moodOk && arousalOk;
        }

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality; var psy = ctx.Actor.Psychology; var r = ctx.Rel!.Value;
            double E = per.BigFive[BigFiveTrait.Extraversion];
            double u = 0.05 + 0.25 * E + 0.25 * (r.Attraction / 100.0) + 0.20 * (r.Closeness / 100.0)
                       + 0.15 * ctx.Ix.Privacy + 0.15 * (0.5 + 0.5 * psy.Mood) + 0.15 * psy.Arousal
                       - 0.15 * psy.Fatigue - 0.10 * psy.StressLevel;
            return Bx.Clamp01(u);
        }
    }
}
