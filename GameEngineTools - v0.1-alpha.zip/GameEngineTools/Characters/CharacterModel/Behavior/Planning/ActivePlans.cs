﻿// ActivePlans.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Planning
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public sealed class ActivePlans
    {
        private readonly ConcurrentDictionary<Guid, IBehaviorPlan> _byActor = new();
        public bool TryGet(Guid id, out IBehaviorPlan plan) => _byActor.TryGetValue(id, out plan!);
        public bool Start(Guid id, IBehaviorPlan plan) => _byActor.TryAdd(id, plan);
        public void Complete(Guid id) => _byActor.TryRemove(id, out _);
    }
}
