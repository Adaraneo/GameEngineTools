﻿// Encounters.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.World.Encounters
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Behavior;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;
    using GameEngineTools.World.Utils.Time;

    public enum EncounterSource
    {
        Organic = 0,
        Forced = 1
    }

    public readonly struct Encounter
    {
        public Encounter(IHuman a, IHuman b, WDateTime when) : this()
        {
            A = a;
            B = b;
            When = when;
        }

        public IHuman A { get; init; }
        public IHuman B { get; init; }
        public InteractionContext Ix { get; init; }
        public Guid? PlaceId { get; init; }
        public SituationType Situation { get; init; }
        public EncounterSource Source { get; init; }
        public string? Tag { get; init; }
        public WDateTime When { get; init; }
    }
}
