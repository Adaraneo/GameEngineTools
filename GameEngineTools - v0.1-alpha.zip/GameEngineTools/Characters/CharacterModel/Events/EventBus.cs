﻿// EventBus.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Events
{
    using System.Collections.Concurrent;
    using System.Collections.Immutable;
    using Microsoft.Extensions.Logging;
    using GameEngineTools.Characters.CharacterModel.Behavior;
    using GameEngineTools.Characters.CharacterModel.Relationships;
    using GameEngineTools.World.Utils.Time;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.World.Encounters;

    // === Základní kontrakty ===
    public interface IEvent { }

    public interface IEventBus
    {
        IDisposable Subscribe<TEvent>(Func<TEvent, CancellationToken, Task> handler) where TEvent : IEvent;
        IDisposable Subscribe<TEvent>(Action<TEvent> handler) where TEvent : IEvent;

        IDisposable Subscribe<TEvent>(Func<TEvent, Task> handler) where TEvent : IEvent;
        Task PublishAsync<TEvent>(TEvent evt, CancellationToken ct = default) where TEvent : IEvent;

    }

    public sealed class EventBus : IEventBus
    {
        private readonly ConcurrentDictionary<Type, ImmutableArray<Delegate>> _subscribers = new();
        private readonly ILogger<EventBus>? _log;

        public EventBus(ILogger<EventBus>? log = null) => _log = log;

        public IDisposable Subscribe<TEvent>(Func<TEvent, CancellationToken, Task> handler) where TEvent : IEvent
        {
            _subscribers.AddOrUpdate(
                typeof(TEvent),
                _ => ImmutableArray.Create<Delegate>(handler),
                (_, arr) => arr.Add(handler));

            return new Unsubscriber(() => Unsubscribe(handler));
        }

        public IDisposable Subscribe<TEvent>(Action<TEvent> handler) where TEvent : IEvent
            => Subscribe<TEvent>((e, _) => { handler(e); return Task.CompletedTask; });

        public IDisposable Subscribe<TEvent>(Func<TEvent, Task> handler) where TEvent : IEvent
            => Subscribe<TEvent>((e, _) => handler(e));

        public IDisposable Subscribe<TEvent>(Func<TEvent, ValueTask> handler) where TEvent : IEvent
            => Subscribe<TEvent>((e, _) => handler(e).AsTask());
        public IDisposable Subscribe<TEvent>(Func<TEvent, CancellationToken, ValueTask> handler) where TEvent : IEvent
            => Subscribe<TEvent>((e, ct) => handler(e, ct).AsTask());

        private void Unsubscribe<TEvent>(Func<TEvent, CancellationToken, Task> handler)
        {
            _subscribers.AddOrUpdate(
                typeof(TEvent),
                _ => ImmutableArray<Delegate>.Empty,
                (_, arr) => arr.Remove(handler));
        }

        public async Task PublishAsync<TEvent>(TEvent ev, CancellationToken ct = default) where TEvent : IEvent
        {
            if (!_subscribers.TryGetValue(typeof(TEvent), out var arr) || arr.IsDefaultOrEmpty) return;

            // Snapshot už máme (ImmutableArray). Voláme handlery bez locku.
            foreach (var d in arr)
            {
                try
                {
                    await ((Func<TEvent, CancellationToken, Task>)d)(ev, ct).ConfigureAwait(false);
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    _log?.LogError(ex, "EventBus handler failed for {0}", typeof(TEvent).Name);
                    // záměrně nehážeme dál – jeden špatný handler nesmí shodit ostatní
                }
            }
        }

        private sealed class Unsubscriber : IDisposable
        {
            private int _done;
            private readonly Action _dispose;
            public Unsubscriber(Action dispose) => _dispose = dispose;
            public void Dispose()
            {
                if (Interlocked.Exchange(ref _done, 1) == 0) _dispose();
            }
        }
    }

    // === Eventy z Behavior → Relationships ===

    public sealed record ScheduledInteractionEvent(Guid ActorId, Guid TargetId, InteractionType InteractionType, float Magnitude, InteractionContext? Context, WDateTime When) : IEvent;


    public sealed record BehaviorExecutedEvent(Guid ActorId, Guid? TargetId, BehaviorType BehaviorType, string Outcome) : IEvent;

    internal sealed record GoalSignalEvent(Guid ActorId, string GoalType, float Priority) : IEvent;

    // === Eventy z Relationships → Behavior ===
    internal sealed record RelationshipChangedEvent(Guid ActorId, Guid TargetId, string ChangeType, float OldValue, float NewValue) : IEvent;

    internal sealed record RelationshipThresholdReachedEvent(Guid ActorId, Guid TargetId, string ThresholdType) : IEvent;

    internal sealed record FamilyChangedEvent(Guid ParentId, Guid ChildId, string ChangeType) : IEvent;

    // === Společný event ===
    //public sealed record SimulationTickEvent(WDateTime Timestamp, WTimeSpan DeltaTime) : IEvent;

    internal sealed record RelationshipStageChangedEvent(WDateTime When, Relationship Rel, BondStage From, BondStage To) : IEvent;
    internal sealed record RelationshipKindChangedEvent(WDateTime When, Relationship Rel, BondKind From, BondKind To) : IEvent;

    internal sealed record InteractionAppliedEvent(Guid ActorId,Guid TargetId,InteractionType InteractionType,WDateTime When,InteractionContext? Context) : IEvent;

    public sealed record EncounterCreatedEvent(IHuman A, IHuman B, Place Place, WDateTime When, int OccupantCountHint = 0, double PriorityHint = 0) : IEvent
    {
        // Kanonizace pořadí A/B podle DNA, ať nevznikají duplicity "A,B" vs "B,A"
        public static EncounterCreatedEvent Create(Human a, Human b, Place place, WDateTime when, int occupantCountHint = 0, double priorityHint = 0d)
        {
            var swap = string.CompareOrdinal(a.Body.DNA.ToString(), b.Body.DNA.ToString()) > 0;
            var A = swap ? b : a;
            var B = swap ? a : b;
            return new EncounterCreatedEvent(A, B, place, when, occupantCountHint, priorityHint);
        }
    }

    public sealed record PresenceChangedEvent(
    IHuman Self,
    IHuman Other,
    Place Place,
    bool NowSamePlace,
    WDateTime When) : IEvent
    {
        public static PresenceChangedEvent Together(IHuman a, IHuman b, Place place, WDateTime when)
            => new(a, b, place, true, when);

        public static PresenceChangedEvent Separated(IHuman a, IHuman b, Place place, WDateTime when)
            => new(a, b, place, false, when);
    }

}
