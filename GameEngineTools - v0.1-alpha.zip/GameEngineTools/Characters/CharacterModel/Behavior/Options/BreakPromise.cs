﻿// BreakPromise.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// Zrušení domluvené věci na poslední chvíli – silně negativní na kontinuitu/společný cíl.
    public sealed class BreakPromise : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.Refuse;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Betrayal,
                When = ctx.When,
                IsMicro = false,
                Context = new InteractionContext
                {
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone - 0.25f, -1f, 1f),
                    Depth = Math.Max(0f, ctx.Ix.Depth - 0.15f),
                    SharedGoal = Math.Max(0f, ctx.Ix.SharedGoal - 0.25f),
                    Continuity = Math.Max(0f, ctx.Ix.Continuity - 0.20f),
                    Warmth = Math.Max(0f, ctx.Ix.Warmth - 0.15f),
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.15f, 0f, 1f),
                    Privacy = ctx.Ix.Privacy,
                    SocialAudience = ctx.Ix.SocialAudience
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && ctx.Ix.Continuity > 0.3f;

        public float Utility(in BehaviorContext ctx)
        {
            double u = 0.05 + 0.30 * (1 - ctx.Ix.Privacy) + 0.25 * ctx.CrowdNoise01
                       + 0.25 * (1 - ctx.Ix.Continuity);
            return Bx.Clamp01(u);
        }
    }
}
