﻿// ObservationsFromInteractionsSubscriber.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.World.Knowledge.Subscribers
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Events;
    using GameEngineTools.Characters.CharacterModel.Relationships;
    using GameEngineTools.World.Knowledge;

    public sealed class ObservationsFromInteractionsSubscriber
    {
        private readonly IEventBus _bus;
        private readonly IKnowledgeLedger _knowledge;

        private static float ConfidenceFromContext(InteractionContext? ctx)
        {
            if (ctx is null) return 0.5f;
            // vyšší audience + nižší hluk = vyšší confidence (0.3..0.9)
            var aud = Math.Clamp(ctx.Value.SocialAudience, 0f, 1f);
            var noise = 1f - Math.Clamp(ctx.Value.Noise, 0f, 1f);
            return 0.3f + 0.6f * (0.6f * aud + 0.4f * noise);
        }

        private void OnInteractionApplied(InteractionAppliedEvent e)
        {
            // A: pokud máš AudienceWitnessIds (viz patch níž), použij je. Jinak odhadni z SocialAudience.
            var witnesses = e.Context?.AudienceWitnessIds ?? Array.Empty<Guid>();
            if (witnesses.Length == 0)
            {
                // fallback: žádní explicitní svědci → nic nezapisuj (nebo by šlo náhodně vygenerovat)
                return;
            }

            string? claim = e.InteractionType switch
            {
                InteractionType.Apology or InteractionType.MakeAmends or InteractionType.Aftercare => "prosocial",
                InteractionType.Argument or InteractionType.Breach or InteractionType.NoShow => "conflict_prone",
                InteractionType.Kiss or InteractionType.Touch => (e.Context?.Privacy ?? 0f) <= 0.25f ? "bold_in_public" : null,
                _ => null
            };
            if (claim is null) return;

            float conf = ConfidenceFromContext(e.Context);
            foreach (var w in witnesses)
                _knowledge.Record(new Observation(w, e.ActorId, claim, conf, e.When));
        }

        public ObservationsFromInteractionsSubscriber(IEventBus bus, IKnowledgeLedger knowledge)
        { _bus = bus; _knowledge = knowledge; _bus.Subscribe<InteractionAppliedEvent>(OnInteractionApplied); }
    }
}
