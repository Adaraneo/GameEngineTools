﻿// PlaceAwareNormEvaluator.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Norms
{
    public sealed class PlaceAwareNormEvaluator : INormEvaluator
    {
        private readonly SimpleNormEvaluator _simple = new();

        public double Evaluate(BehaviorType type, in BehaviorContext ctx)
        {
            double p = _simple.Evaluate(type, ctx); // veřejnost / dav

            switch (ctx.Situation)
            {
                case SituationType.WorkTask:
                    if (type is BehaviorType.FlirtLight or BehaviorType.FlirtBold
                        or BehaviorType.Kiss or BehaviorType.KissLight
                        or BehaviorType.InitiateIntimacySoft or BehaviorType.InitiateIntimacyBold)
                        p -= 0.35; // „romantika v práci“ = citelný zápor

                    if (type is BehaviorType.SelfDisclosureDeep)
                        p -= 0.15 * ctx.CrowdNoise01; // hluboké sdílení při okolním ruchu působí nepatřičně
                    break;

                case SituationType.GroupSetting:
                    if (type is BehaviorType.SelfDisclosureDeep) p -= 0.45; // hluboké sdílení ve skupině
                    if (type is BehaviorType.Confront or BehaviorType.UndermineInPublic or BehaviorType.Retort)
                        p -= 0.20; // veřejný konflikt je navíc „společensky dražší“
                    break;

                case SituationType.OneOnOnePrivate:
                case SituationType.DateLike:
                    if (type is BehaviorType.SelfDisclosureDeep) p += 0.15; // soukromí snižuje postih
                    if (type is BehaviorType.Kiss or BehaviorType.InitiateIntimacySoft or BehaviorType.InitiateIntimacyBold)
                        p += 0.10 * ctx.Ix.Privacy; // čím víc privacy, tím menší postih
                    break;
            }

            p *= 1 + 0.5 * ctx.Actor.Personality.GetBigFiveTrait(Homo.BigFiveTrait.Neuroticism) * ctx.NormPressure01;
            return p; // záporná čísla = penalizace, kladná = odmazání postihu
        }
    }
}
