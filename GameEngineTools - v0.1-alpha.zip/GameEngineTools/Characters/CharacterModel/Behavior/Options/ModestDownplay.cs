﻿// ModestDownplay.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// <summary>
    /// Přijetí s lehkým zlehčením ("díky, ale byla to maličkost") – vztahově bezpečné, méně afiliační.
    /// </summary>
    public sealed class ModestDownplay : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.KeepDistance;

        public void Apply(in BehaviorContext ctx)
        {
            // Mapujeme na "Honesty" mírně pozitivní, ale s téměř nulovým prohloubením
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Honesty,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.05f, -1f, 1f),
                    Depth = Math.Clamp(ctx.Ix.Depth - 0.05f, 0f, 1f),
                    Privacy = ctx.Ix.Privacy,
                    Risk = Math.Max(0f, ctx.Ix.Risk - 0.05f),
                    SocialAudience = ctx.Ix.SocialAudience,
                    SharedGoal = ctx.Ix.SharedGoal,
                    Continuity = ctx.Ix.Continuity
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && ctx.Situation == SituationType.PraiseReceived;

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality;
            var psy = ctx.Actor.Psychology;

            double N = per.BigFive[BigFiveTrait.Neuroticism];     // plachost, rozpaky
            double A = per.BigFive[BigFiveTrait.Agreeableness];   // slušnost – přijetí
            double E = per.BigFive[BigFiveTrait.Extraversion];

            // Více se volí při vyšší plachosti/rozpacích a nižší extraverzi, slabší afiliační potřebě
            double u = 0.10
                     + 0.30 * N
                     + 0.15 * A
                     - 0.20 * E
                     - 0.10 * ctx.Goals.AffiliationNeed01
                     + 0.10 * (0.5 + 0.5 * psy.Mood);

            return Bx.Clamp01(u);
        }
    }
}
