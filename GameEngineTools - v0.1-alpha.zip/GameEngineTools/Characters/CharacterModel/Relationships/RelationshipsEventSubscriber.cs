﻿// RelationshipsEventSubscriber.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships
{
    using System;
    using System.Threading;
    using System.Threading.Tasks;
    using Microsoft.Extensions.DependencyInjection;
    using GameEngineTools.Characters.CharacterModel.Behavior;
    using GameEngineTools.Characters.CharacterModel.Events;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.World.Core.Time;
    /// <summary>
    /// Překlenuje události z Behavior do RelationshipManageru.
    /// NENARUŠUJE zpětnou kompatibilitu – ApplyInteraction můžeš dál volat přímo.
    /// </summary>
    public sealed class RelationshipsEventSubscriber : IDisposable
    {
        private readonly IEventBus _bus;
        private readonly IClock _clock;
        private readonly IHumanResolver _humans; // jednoduché rozhraní pro získání IHuman z ID
        private bool _subscribed;
        private readonly RelationshipManager _relationshipManager;

        public RelationshipsEventSubscriber(IEventBus bus, IClock clock, IHumanResolver humans, IServiceProvider provider)
        {
            _bus = bus;
            _clock = clock;
            _humans = humans;
            Subscribe();
            _relationshipManager = provider.GetRequiredService<RelationshipManager>();
        }

        private void Subscribe()
        {
            if (_subscribed) return;

            _bus.Subscribe<BehaviorExecutedEvent>(OnBehaviorExecuted);
            _bus.Subscribe<FamilyChangedEvent>(OnFamilyChanged);
            _subscribed = true;
        }

        private void OnBehaviorExecuted(BehaviorExecutedEvent e)
        {
            if (!_humans.TryGet(e.ActorId, out var from)) return;

            // Pokud BehaviorExecuted má TargetId, je to typicky „interakce“ (dar, útok, podpora…)
            if (e.TargetId.HasValue && _humans.TryGet(e.TargetId.Value, out var to))
            {
                var interaction = MapBehaviorToInteraction(e.BehaviorType, e.Outcome);
                _relationshipManager.ApplyInteraction(from, to, interaction, baseEffect: 1f, context: null);
            }
        }

        private void OnFamilyChanged(FamilyChangedEvent e)
        {
            if (!_humans.TryGet(e.ParentId, out var a)) return;
            if (!_humans.TryGet(e.ChildId, out var b)) return;

            var role = e.ChangeType.Equals("Add", StringComparison.OrdinalIgnoreCase)
                ? KinshipRole.Father // nebo Mother; pokud chceš přesnost, rozšiř payload eventu o konkrétní roli
                : KinshipRole.Unknown;

            _relationshipManager.SetKinship(a, b, role);
        }

        private static InteractionType MapBehaviorToInteraction(BehaviorType behaviorType, string outcome)
        {
            return behaviorType switch
            {
                // prosociál
                BehaviorType.OfferHelp => InteractionType.Help,
                BehaviorType.Apologize => InteractionType.Apology,
                BehaviorType.HonestDisclosureLight => InteractionType.Honesty,
                BehaviorType.ReturnCompliment => InteractionType.Compliment,
                BehaviorType.AcknowledgePraise => InteractionType.Compliment,
                BehaviorType.ComplimentLight => InteractionType.Compliment,
                BehaviorType.DeescalateConflict => InteractionType.MakeAmends,
                BehaviorType.AftercareCuddle => InteractionType.Aftercare,

                // konverzační/nenápadné
                BehaviorType.PoliteNod => InteractionType.SmallTalk,
                BehaviorType.DeferReply => InteractionType.SmallTalk,
                BehaviorType.GracefulExit => InteractionType.Generic,
                BehaviorType.AskOpenQuestion => InteractionType.Talk,
                BehaviorType.FriendChat => InteractionType.Talk,
                BehaviorType.CheckIn => InteractionType.Talk,
                BehaviorType.ChangeTopic => InteractionType.Talk,
                BehaviorType.DeflectQuestion => InteractionType.Talk,
                BehaviorType.SetBoundary => InteractionType.Generic,   // „hranice“ vede hlavně přes kontext (Depth/Sincerity)

                // společný čas
                BehaviorType.InviteSharedActivity => InteractionType.SharedActivity,
                BehaviorType.SuggestSharedActivity => InteractionType.SharedActivity,

                // přitažlivost/intimita
                BehaviorType.FlirtLight => InteractionType.Flirt,
                BehaviorType.FlirtBold => InteractionType.Kiss,
                BehaviorType.KissLight => InteractionType.Kiss,
                BehaviorType.Kiss => InteractionType.Kiss,
                BehaviorType.InitiateIntimacySoft => InteractionType.Touch,

                // konflikt/negativní
                BehaviorType.Retort => InteractionType.Argument,
                BehaviorType.Confront => InteractionType.Argument,
                BehaviorType.UndermineInPublic => InteractionType.Insult,
                BehaviorType.InsultDirect => InteractionType.Insult,
                BehaviorType.LieWhite => InteractionType.Lie,
                BehaviorType.RefuseHelp => InteractionType.Breach,
                BehaviorType.BreakPromise => InteractionType.Breach,
                BehaviorType.Withdraw => InteractionType.NoShow,

                _ => InteractionType.None
            };
        }


        public void Dispose()
        {
            // Zatím nic neděláme – předpokládáme, že EventBus žije stejně dlouho jako tento subscriber
        }
    }
}

