﻿// BehaviorCandidateGenerator.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior
{
    using System;
    using System.Collections.Generic;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Logging;
    using GameEngineTools.World.Encounters;
    using Microsoft.Extensions.Logging;

    public interface IRelationshipSnapshotProvider
    {
        RelationshipSnapshotForBehavior? TryGet(IHuman a, IHuman b);
    }

    public sealed class BehaviorCandidateGenerator
    {
        private readonly ILogger<BehaviorCandidateGenerator> _log;
        private readonly IRelationshipSnapshotProvider _relView;
        private readonly IInteractionSink _sink;
        private readonly IGoalSignalProvider _goals;

        public BehaviorCandidateGenerator(IRelationshipSnapshotProvider relView, IInteractionSink sink, ILogger<BehaviorCandidateGenerator> log, IGoalSignalProvider goals)
        {
            _relView = relView;
            _sink = sink;
            _log = log;
            _goals = goals;
        }

        public IEnumerable<BehaviorContext> BuildContexts(IEnumerable<Encounter> encounters)
        {
            // TODO: logging
            foreach (var e in encounters)
            {
                var relAB = _relView.TryGet(e.A, e.B);
                var relBA = _relView.TryGet(e.B, e.A);

                yield return new BehaviorContext
                {
                    Actor = e.A,
                    Target = e.B,
                    Situation = e.Situation,
                    Ix = e.Ix,
                    When = e.When,
                    Rel = relAB,
                    Sink = _sink,
                    CrowdNoise01 = e.Ix.SocialAudience,
                    NormPressure01 = 1f - e.Ix.Privacy,
                    Goals = _goals.GetGoals(e.A, relAB)
                };

                yield return new BehaviorContext
                {
                    Actor = e.B,
                    Target = e.A,
                    Situation = e.Situation,
                    Ix = e.Ix,
                    When = e.When,
                    Rel = relBA,
                    Sink = _sink,
                    CrowdNoise01 = e.Ix.SocialAudience,
                    NormPressure01 = 1f - e.Ix.Privacy,
                    Goals = _goals.GetGoals(e.B, relBA)
                };
            }
        }

        internal IEnumerable<BehaviorContext> BuildContextsFor(Encounter e)
        {
            var relAB = _relView.TryGet(e.A, e.B);
            var relBA = _relView.TryGet(e.B, e.A);

            yield return new BehaviorContext
            {
                Actor = e.A,
                Target = e.B,
                Situation = e.Situation,
                Ix = e.Ix,
                When = e.When,
                Rel = relAB,
                Sink = _sink,
                CrowdNoise01 = e.Ix.SocialAudience,
                NormPressure01 = 1f - e.Ix.Privacy,
                Goals = _goals.GetGoals(e.A, relAB)
            };

            yield return new BehaviorContext
            {
                Actor = e.B,
                Target = e.A,
                Situation = e.Situation,
                Ix = e.Ix,
                When = e.When,
                Rel = relBA,
                Sink = _sink,
                CrowdNoise01 = e.Ix.SocialAudience,
                NormPressure01 = 1f - e.Ix.Privacy,
                Goals = _goals.GetGoals(e.B, relBA)
            };
        }
    }
}
