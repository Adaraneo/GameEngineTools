﻿// InsultDirect.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// Přímá urážka (tvrdý negativní zásah).
    public sealed class InsultDirect : IBehaviorOption
    {
        // reuse stávající cooldown koš
        public BehaviorType Type => BehaviorType.Retort;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Insult,
                When = ctx.When,
                IsMicro = false,
                Context = new InteractionContext
                {
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone - 0.40f, -1f, 1f),
                    Warmth = Math.Max(0f, ctx.Ix.Warmth - 0.30f),
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.20f, 0f, 1f),
                    Depth = Math.Max(0f, ctx.Ix.Depth - 0.10f),
                    Privacy = ctx.Ix.Privacy,
                    SocialAudience = ctx.Ix.SocialAudience,
                    SharedGoal = Math.Max(0f, ctx.Ix.SharedGoal - 0.10f),
                    Continuity = ctx.Ix.Continuity
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && (ctx.Situation == SituationType.Conflict || ctx.Ix.EmotionalTone < 0f);

        public float Utility(in BehaviorContext ctx)
        {
            var p = ctx.Actor.Psychology; var per = ctx.Actor.Personality;
            double A = per.BigFive[BigFiveTrait.Agreeableness];
            double u = 0.05 + 0.45 * p.Aggression + 0.30 * p.StressLevel - 0.30 * A
                       + 0.10 * (1.0 - ctx.Ix.Privacy);
            return Bx.Clamp01(u);
        }
    }
}
