﻿// SimpleNormEvaluator.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Norms
{
    public sealed class SimpleNormEvaluator : INormEvaluator
    {
        public double Evaluate(BehaviorType type, in BehaviorContext ctx)
        {
            var publicness = System.Math.Clamp(ctx.NormPressure01, 0f, 1f);  // 0..1 (0=privát, 1=veřejno)
            var crowd = System.Math.Clamp(ctx.CrowdNoise01, 0f, 1f);  // 0..1

            // Intimita na veřejnosti
            if (type is BehaviorType.InitiateIntimacySoft or BehaviorType.InitiateIntimacyBold
                       or BehaviorType.Kiss or BehaviorType.KissLight or BehaviorType.FlirtBold)
                return -0.6 * publicness - 0.2 * crowd;

            // Hlubší osobní odhalení v otevřenu
            if (type is BehaviorType.HonestDisclosureLight)
                return -0.35 * publicness;

            // Ponížení/konfrontace „před lidmi“
            if (type is BehaviorType.UndermineInPublic or BehaviorType.Retort or BehaviorType.Confront)
                return -0.5 * publicness - 0.25 * crowd;

            return 0.0;
        }
    }
}
