﻿// ThemeTag.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public enum ThemeTag
    {
        None = 0,
        Music,
        Faith,
        Nature,
        Humor,
        Vulnerability,
        Conflict,
        Care,
        Touch
    }
}
