﻿// SetBoundary.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    public sealed class SetBoundary : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.SetBoundary;

        public void Apply(in BehaviorContext ctx)
        {
            // Mapuj na Honesty (s vyšším Depth) a malé riziko; veřejně to trochu bolí trust (řeší Relationship logika)
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Honesty,
                When = ctx.When,
                IsMicro = false,
                Context = new InteractionContext
                {
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone - 0.10f, -1f, 1f), // neutrálně/lehce chladněji
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.30f, 0f, 1f),
                    Privacy = ctx.Ix.Privacy,
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.15f, 0f, 1f),
                    SocialAudience = ctx.Ix.SocialAudience,
                    SharedGoal = ctx.Ix.SharedGoal,
                    Continuity = ctx.Ix.Continuity
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx) => ctx.Target is not null;

        public float Utility(in BehaviorContext ctx)
        {
            var psy = ctx.Actor.Psychology;
            var per = ctx.Actor.Personality;
            double A = per.BigFive[Homo.BigFiveTrait.Agreeableness];

            // Gate: když je situace „Conflict“ nebo „InsultReceived“, posuň utilitu nahoru
            double situ = (ctx.Situation == SituationType.Conflict || ctx.Situation == SituationType.InsultReceived) ? 0.25 : 0.0;

            double u = 0.05 + 0.35 * psy.Aggression + 0.25 * psy.StressLevel + 0.20 * psy.SelfControl + situ - 0.25 * A
                       - 0.20 * ctx.Ix.SocialAudience; // veřejně spíš méně
            return Bx.Clamp01(u);
        }
    }
}
