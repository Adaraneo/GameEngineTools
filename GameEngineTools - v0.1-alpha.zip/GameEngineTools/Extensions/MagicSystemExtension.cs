﻿// MagicSystemExtension.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Extensions
{
    using GameEngineTools.Characters.GameObjects;

    public static class MagicSystemExtension
    {
        public static void DoMagic(this NPPC caster, object target)
        {
            caster.Person.Magic.Do(target);
        }

        public static void SetAffectPoints(this NPPC nppc, double amount)
        {
            nppc.Person.Magic.AffectPoints = amount;
        }
    }
}
