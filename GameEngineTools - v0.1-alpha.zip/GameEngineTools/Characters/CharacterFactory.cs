﻿// CharacterFactory.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using GameEngineTools;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.Homo;

    public static class CharacterFactory
    {
        private static readonly Random rand = Random.Shared;

        private static void AddTemperamentTraits(Person p, TemperamentType t)
        {
            void Add(PersonalityTrait tr) => p.Personality.AdjustTrait(tr, add: true);

            switch (t)
            {
                case TemperamentType.Sanguine: Add(PersonalityTrait.Curious); Add(PersonalityTrait.Empathetic); break;
                case TemperamentType.Choleric: Add(PersonalityTrait.Bold); Add(PersonalityTrait.Impulsive); break;
                case TemperamentType.Phlegmatic: Add(PersonalityTrait.Steady); Add(PersonalityTrait.Practical); break;
                case TemperamentType.Melancholic: Add(PersonalityTrait.Introspective); Add(PersonalityTrait.Idealistic); break;
            }
        }

        private static void ApplyTemperamentToBigFive(Person p, TemperamentType t)
        {
            var b5 = p.Personality.BigFive;

            // středové hodnoty (0–1)
            (double O, double C, double E, double A, double N) mu = t switch
            {
                TemperamentType.Sanguine => (0.60, 0.50, 0.75, 0.60, 0.35),
                TemperamentType.Choleric => (0.55, 0.70, 0.70, 0.40, 0.55),
                TemperamentType.Phlegmatic => (0.50, 0.55, 0.35, 0.70, 0.35),
                TemperamentType.Melancholic => (0.65, 0.72, 0.30, 0.55, 0.70),
                _ => (0.55, 0.56, 0.53, 0.56, 0.49)
            };

            double sigma = 0.12; // šum

            b5[BigFiveTrait.Openness] = NextGaussianClamped(mu.O, sigma);
            b5[BigFiveTrait.Conscientiousness] = NextGaussianClamped(mu.C, sigma);
            b5[BigFiveTrait.Extraversion] = NextGaussianClamped(mu.E, sigma);
            b5[BigFiveTrait.Agreeableness] = NextGaussianClamped(mu.A, sigma);
            b5[BigFiveTrait.Neuroticism] = NextGaussianClamped(mu.N, sigma);

            // DecisionStyle výchozí z temperamentu (elementy/arch. to mohou jemně posunout)
            p.Personality.DecisionStyle = t switch
            {
                TemperamentType.Sanguine => DecisionStyle.Intuitive,
                TemperamentType.Choleric => DecisionStyle.Impulsive,
                TemperamentType.Phlegmatic => DecisionStyle.Deliberate,
                TemperamentType.Melancholic => DecisionStyle.Reflective,
                _ => DecisionStyle.Balanced
            };
        }

        private static double Clamp(double v, double lo, double hi) => Math.Clamp(v, lo, hi);

        private static double ClampSingle(double x) => Math.Max(0.0, Math.Min(1.0, x));

        private static Person CreatePersonWithArchetypeAndElementalType(string archetype, List<Name> maleNames, List<Name> femaleNames, List<Surname> surnames, double minAge = 0, double maxAge = 100, GenusType? genus = null)
        {
            var person = CreateRealisticPerson(maleNames, femaleNames, surnames, minAge, maxAge, genus);

            // Aplikuj archetyp
            ApplyArchetype(person, archetype);

            // Aplikuj živel, bezpečně
            MergeElementalPersonality(person, (ElementalPersonalityType)person.Magic.MagicType);

            return person;
        }

        private static Person CreateRealisticPerson(List<Name> maleNames, List<Name> femaleNames, List<Surname> surnames, in double minAge, in double maxAge, GenusType? genus = null, in double? heightCm = null, in double? weightKg = null)
        {
            if (genus == null)
                genus = rand.NextDouble() < 0.5 ? GenusType.Male : GenusType.Female;

            var age = rand.Next((int)minAge, (int)maxAge);
            var magic = (MagicType)rand.Next(0, 4);
            var name = genus == GenusType.Male
                ? maleNames[rand.Next(maleNames.Count)]
                : femaleNames[rand.Next(femaleNames.Count)];
            var surname = surnames[rand.Next(surnames.Count)];

            var (height, weight) = EstimateHeightWeight(age, genus.Value);
            if (heightCm.HasValue)
            {
                height = heightCm.Value;
            }

            if (weightKg.HasValue)
            {
                weight = weightKg.Value;
            }

            var person = genus == GenusType.Male
                ? Person.Male(name, surname, magic, age, height, weight)
                : Person.Female(name, surname, magic, age, height, weight);

            GenerateRealisticAppearance(person);
            GenerateRealisticPersonality(person);

            return person;
        }

        private static (double height, double weight) EstimateHeightWeight(double age, GenusType genus)
        {
            if (age < 1)
            {
                double height = 50 + age * 25;
                double weight = 3.5 + age * 6;
                return (height, weight);
            }
            else if (age < 12)
            {
                double height = 75 + (age - 1) * 7.5;
                double weight = 9.5 + (age - 1) * 3.2;
                return (height, weight);
            }
            else if (age < 18)
            {
                double baseHeight = genus == GenusType.Male ? 140 : 135;
                double heightGain = (genus == GenusType.Male ? 7 : 5.5) * (age - 12);
                double height = baseHeight + heightGain;

                double baseWeight = genus == GenusType.Male ? 40 : 38;
                double weightGain = (genus == GenusType.Male ? 4.5 : 3.5) * (age - 12);
                double weight = baseWeight + weightGain;

                return (height, weight);
            }
            else if (age < 42)
            {
                double height = genus == GenusType.Male ? 178 : 165;
                double weight = genus == GenusType.Male
                    ? 70 + (age - 18) * 0.3
                    : 55 + (age - 18) * 0.25;
                return (height, weight);
            }
            else
            {
                double height = genus == GenusType.Male ? 176 : 162;
                double weight = genus == GenusType.Male ? 75 : 60;
                return (height, weight);
            }
        }

        private static void GenerateFears(Person p)
        {
            if (p.Age < 10)
            {
                p.Personality.Fears.Add(new Fear("Darkness"));
            }

            if (p.Age >= 10 && p.Age <= 25 && rand.NextDouble() < 0.4)
            {
                p.Personality.Fears.Add(new Fear("Rejection"));
            }

            if (p.Age > 40 && rand.NextDouble() < 0.5)
            {
                p.Personality.Fears.Add(new Fear("Failure"));
            }

            if (p.Personality.Traits.Contains(PersonalityTrait.Paranoid))
            {
                p.Personality.Fears.Add(new Fear("Being Watched"));
            }
        }

        private static void GenerateRealisticAppearance(Person person)
        {
            var b = person.Body;
            double h = b.HeightCm;                     // výška v cm
            double w = b.WeightKg;                     // hmotnost v kg
            double bmi = w / Math.Pow(h / 100.0, 2);   // BMI
            bool isFemale = b.Genus == GenusType.Female;

            // --- Somatotyp (Dirichlet-like, pak normalizace) ---
            double ecto = Math.Max(0.01, NextNormal(0.34, 0.12));
            double meso = Math.Max(0.01, NextNormal(0.33, 0.12));
            double endo = Math.Max(0.01, NextNormal(0.33, 0.12));
            double s = ecto + meso + endo;
            b.Somatotype = new Somatotype { Ectomorph = ecto / s, Mesomorph = meso / s, Endomorph = endo / s };

            // --- Skin tone (Fitzpatrick) – lehce preferuj střed (2–4) ---
            b.SkinTone = PickWeighted(
                (SkinTone.Fitzpatrick1, 0.12), (SkinTone.Fitzpatrick2, 0.22), (SkinTone.Fitzpatrick3, 0.26),
                (SkinTone.Fitzpatrick4, 0.22), (SkinTone.Fitzpatrick5, 0.12), (SkinTone.Fitzpatrick6, 0.06));

            // --- Eyes: Brown  ~70 %, Blue ~15 %, Green ~8 %, Hazel ~5 %, Gray ~1.5 %, Amber ~0.5 % ---
            b.HasHeterochromia = rand.NextDouble() < 0.004; // vzácné
            b.EyeColor = PickWeighted(
                (EyeColor.Brown, 0.70), (EyeColor.Blue, 0.15), (EyeColor.Green, 0.08),
                (EyeColor.Hazel, 0.05), (EyeColor.Gray, 0.015), (EyeColor.Amber, 0.005));

            // --- Hair type / density ---
            b.HairType = PickWeighted((HairType.Straight, 0.45), (HairType.Wavy, 0.35),
                                      (HairType.Curly, 0.15), (HairType.Coily, 0.05));
            // Hustota klesá s věkem; muži rychleji
            double age = person.Age;
            double densityBase = isFemale ? 0.65 : 0.55;
            double densityAgePenalty = (isFemale ? 0.005 : 0.009) * Math.Max(0, age - 25);
            double dens = Clamp(densityBase - densityAgePenalty + NextNormal(0, 0.06), 0.2, 0.9);
            b.HairDensity = dens < 0.35 ? HairDensity.Sparse : (dens < 0.65 ? HairDensity.Medium : HairDensity.Dense);

            // Barva vlasů (přirozené vs. šedivení; malé % „Dyed“)
            //bool dyed = rand.NextDouble() < 0.08;
            if (age >= 45 && rand.NextDouble() < (0.02 * (age - 40))) // postupné šedivění
                b.HairColor = PickWeighted((HairColor.Gray, 0.7), (HairColor.White, 0.3));
            //else if (dyed)
            //    b.HairColor = HairColor.Dyed;
            else
                b.HairColor = PickWeighted((HairColor.Black, 0.20), (HairColor.Brown, 0.50),
                                           (HairColor.Blonde, 0.20), (HairColor.Auburn, 0.06), (HairColor.Red, 0.04));

            // Délka vlasů (gender/age zvyky, ale široké rozložení)
            if (isFemale)
                b.HairLengthCm = Clamp(NextNormal(28, 12), 0, 90);  // medián cca po ramena
            else
                b.HairLengthCm = Clamp(NextNormal(6, 6), 0, 40);    // medián krátké až střední

            // Dominantní ruka
            double handR = rand.NextDouble();
            b.DominantHand = handR < 0.10 ? DominantHand.Left : (handR < 0.12 ? DominantHand.Ambidextrous : DominantHand.Right);

            // --- Proporce trupu a končetin (navázané na WtHR/WHR + somatotyp + BMI) ---

            // WtHR (waist-to-height); ženy typicky 0.40–0.55, muži 0.45–0.60; roste s věkem/BMI
            double targetWtHRBase = isFemale ? 0.47 : 0.52;
            targetWtHRBase += 0.002 * Math.Max(0, age - 30);                  // věk
            targetWtHRBase += 0.004 * Math.Max(0, bmi - 23);                  // BMI příspěvek
            targetWtHRBase += 0.010 * b.Somatotype.Endomorph - 0.006 * b.Somatotype.Ectomorph;
            double targetWtHR = Clamp(NextNormal(targetWtHRBase, 0.02), isFemale ? 0.40 : 0.45, isFemale ? 0.58 : 0.63);

            b.WaistCm = Math.Round(targetWtHR * h, 1);

            // WHR (waist-to-hip); ženy 0.70–0.85, muži 0.85–0.95
            double whrBase = isFemale ? 0.78 : 0.90;
            whrBase -= 0.02 * b.Somatotype.Mesomorph;        // více „tvaru“ u meso
            whrBase += 0.02 * b.Somatotype.Endomorph;
            double whr = Clamp(NextNormal(whrBase, 0.03), isFemale ? 0.68 : 0.82, isFemale ? 0.88 : 0.98);
            b.HipsCm = Math.Round(b.WaistCm / whr, 1);

            // Šířka ramen (biacromial). Základ podle výšky, meso zvýší, ecto sníží.
            double shoulderBase = (isFemale ? 0.255 : 0.275) * h;
            shoulderBase += 2.0 * (b.Somatotype.Mesomorph - b.Somatotype.Ectomorph);
            b.ShoulderBreadthCm = Math.Round(Clamp(NextNormal(shoulderBase, 1.8), 34, 56), 1);

            // Chest obvod (hrudník)
            double chestAdj = (isFemale ? 6.0 : 10.0) + 6.0 * b.Somatotype.Mesomorph - 2.0 * b.Somatotype.Ectomorph;
            b.ChestCm = Math.Round(Clamp(b.WaistCm + NextNormal(chestAdj, 2.0), isFemale ? 75 : 85, isFemale ? 115 : 125), 1);

            // Bust/Underbust (jen u žen dává smysl; u mužů srovnáme s Chest)
            if (isFemale)
            {
                // Underbust ~ hrudní koš nad pasem; drž při těle
                b.UnderbustCm = Math.Round(Clamp(NextNormal(b.ChestCm - 10.0, 2.0), b.WaistCm - 2.0, b.ChestCm - 2.0), 1);
                // Cup delta 8–28 cm; závisí lehce na endo/BMI
                double cupDelta = Clamp(NextNormal(16.0 + 4.0 * (b.Somatotype.Endomorph - 0.33) + 0.4 * (bmi - 22), 3.0), 8.0, 28.0);
                b.BustCm = Math.Round(b.UnderbustCm + cupDelta, 1);
            }
            else
            {
                b.UnderbustCm = Math.Round(Clamp(b.ChestCm - 10.0 + NextNormal(0, 1.5), 80, 120), 1);
                b.BustCm = b.ChestCm; // unisex pole, u mužů = hrudník
            }

            // Krk (koreluje s BMI a pohlavím)
            b.NeckCm = Math.Round(Clamp((isFemale ? 33.0 : 39.0) + 0.35 * (bmi - (isFemale ? 21.0 : 23.0)) + NextNormal(0, 1.0),
                                        isFemale ? 28 : 32, isFemale ? 39 : 46), 1);

            // Paže / stehno / lýtko – jednoduché linky na BMI + mesomorph
            b.UpperArmCircumferenceCm = Math.Round(Clamp((isFemale ? 25.0 : 28.0) + 3.5 * b.Somatotype.Mesomorph + 0.30 * (bmi - 22.0) + NextNormal(0, 1.2),
                                                         isFemale ? 20 : 24, isFemale ? 36 : 42), 1);

            b.ThighCircumferenceCm = Math.Round(Clamp((isFemale ? 54.0 : 50.0) + 4.0 * b.Somatotype.Mesomorph + 0.60 * (bmi - 22.0) + NextNormal(0, 1.8),
                                                      isFemale ? 45 : 42, isFemale ? 70 : 66), 1);

            b.CalfCircumferenceCm = Math.Round(Clamp((isFemale ? 35.0 : 37.0) + 2.0 * b.Somatotype.Mesomorph + 0.25 * (bmi - 22.0) + NextNormal(0, 1.0),
                                                     isFemale ? 30 : 32, isFemale ? 46 : 48), 1);

            // Tvar obličeje – náhodně, s drobným biasem podle somatotypu
            b.FaceShape = PickWeighted(
                (FaceShape.Oval, 0.22 + 0.05 * b.Somatotype.Ectomorph),
                (FaceShape.Round, 0.18 + 0.04 * b.Somatotype.Endomorph),
                (FaceShape.Square, 0.18 + 0.03 * b.Somatotype.Mesomorph),
                (FaceShape.Diamond, 0.12),
                (FaceShape.Heart, 0.15),
                (FaceShape.Oblong, 0.15)
            );
        }

        private static void GenerateRealisticPersonality(Person p)
        {
            var temperament = GenerateTemperament(p);
            p.Personality.Temperament = temperament;

            ApplyTemperamentToBigFive(p, temperament);

            foreach (MoralDimension dim in Enum.GetValues(typeof(MoralDimension)))
            {
                p.Personality.Morality[dim] = NextGaussianClamped();
            }

            AddTemperamentTraits(p, temperament);

            var allTraits = Enum.GetValues(typeof(PersonalityTrait))
                .Cast<PersonalityTrait>()
                .Where(t => t != PersonalityTrait.None)
                .ToList();

            if (rand.NextDouble() < 0.5)
            {
                var extra = allTraits[rand.Next(allTraits.Count)];
                p.Personality.AdjustTrait(extra, true);
            }

            GenerateFears(p);
        }

        private static TemperamentType GenerateTemperament(Person p)
        {
            // rovnoměrný základ
            var w = new Dictionary<TemperamentType, double> {
                { TemperamentType.Sanguine,    0.20 },
                { TemperamentType.Choleric,    0.20 },
                { TemperamentType.Phlegmatic,  0.20 },
                { TemperamentType.Melancholic, 0.20 },
                { TemperamentType.Mixed, 0.20 }
            };

            // lehké biasy podle elementu – pokud ho máš k dispozici už zde:
            switch ((ElementalPersonalityType)p.Magic.MagicType)
            {
                case ElementalPersonalityType.Fire: w[TemperamentType.Choleric] += 0.08; break;
                case ElementalPersonalityType.Water: w[TemperamentType.Melancholic] += 0.06; w[TemperamentType.Phlegmatic] += 0.02; break;
                case ElementalPersonalityType.Earth: w[TemperamentType.Phlegmatic] += 0.06; w[TemperamentType.Melancholic] += 0.02; break;
                case ElementalPersonalityType.Air: w[TemperamentType.Sanguine] += 0.06; break;
            }

            // věk – starší o chlup méně choleric, víc phlegmatic/melancholic
            if (p.Age >= 35) { w[TemperamentType.Phlegmatic] += 0.03; w[TemperamentType.Melancholic] += 0.02; w[TemperamentType.Choleric] -= 0.02; }

            // výběr podle vah
            double total = w.Values.Sum();
            double r = rand.NextDouble() * total;
            double acc = 0;
            foreach (var kv in w)
            {
                acc += Math.Max(0, kv.Value);
                if (r <= acc) return kv.Key;
            }

            return TemperamentType.Mixed; // fallback
        }

        private static void MergeElementalPersonality(Person p, ElementalPersonalityType element)
        {
            var b5 = p.Personality.BigFive;
            var t = p.Personality.Traits;

            // Konfliktní mapování
            var conflictMap = new Dictionary<PersonalityTrait, PersonalityTrait[]>
            {
                { PersonalityTrait.Impulsive, new[] { PersonalityTrait.Steady } },
                { PersonalityTrait.Idealistic, new[] { PersonalityTrait.Practical } }
            };

            // Pomocná funkce pro přidání traitu
            void SafeAddTrait(PersonalityTrait trait)
            {
                if (!t.Contains(trait) && !t.Any(existing => conflictMap.ContainsKey(existing) && conflictMap[existing].Contains(trait)))
                {
                    //t.Add(trait);
                    p.Personality.AdjustTrait(trait);
                }
            }

            switch (element)
            {
                case ElementalPersonalityType.Fire:
                    SafeAddTrait(PersonalityTrait.Bold);
                    SafeAddTrait(PersonalityTrait.Impulsive);
                    p.Personality.BigFive[BigFiveTrait.Extraversion] = ClampSingle(p.Personality.BigFive[BigFiveTrait.Extraversion] + 0.08);
                    p.Personality.BigFive[BigFiveTrait.Openness] = ClampSingle(p.Personality.BigFive[BigFiveTrait.Openness] + 0.07);
                    p.Personality.BigFive[BigFiveTrait.Neuroticism] = ClampSingle(p.Personality.BigFive[BigFiveTrait.Neuroticism] + 0.05);
                    break;

                case ElementalPersonalityType.Water:
                    SafeAddTrait(PersonalityTrait.Empathetic);
                    SafeAddTrait(PersonalityTrait.Introspective);
                    p.Personality.BigFive[BigFiveTrait.Agreeableness] = ClampSingle(p.Personality.BigFive[BigFiveTrait.Agreeableness] + 0.07);
                    p.Personality.BigFive[BigFiveTrait.Extraversion] = ClampSingle(p.Personality.BigFive[BigFiveTrait.Extraversion] - 0.05);
                    p.Personality.BigFive[BigFiveTrait.Neuroticism] = ClampSingle(p.Personality.BigFive[BigFiveTrait.Neuroticism] + 0.05);
                    break;

                case ElementalPersonalityType.Earth:
                    SafeAddTrait(PersonalityTrait.Steady);
                    SafeAddTrait(PersonalityTrait.Practical);
                    p.Personality.BigFive[BigFiveTrait.Conscientiousness] = ClampSingle(p.Personality.BigFive[BigFiveTrait.Conscientiousness] + 0.08);
                    p.Personality.BigFive[BigFiveTrait.Extraversion] = ClampSingle(p.Personality.BigFive[BigFiveTrait.Extraversion] - 0.05);
                    p.Personality.BigFive[BigFiveTrait.Neuroticism] = ClampSingle(p.Personality.BigFive[BigFiveTrait.Neuroticism] - 0.05);
                    break;

                case ElementalPersonalityType.Air:
                    SafeAddTrait(PersonalityTrait.Curious);
                    SafeAddTrait(PersonalityTrait.Idealistic);
                    p.Personality.BigFive[BigFiveTrait.Openness] = ClampSingle(p.Personality.BigFive[BigFiveTrait.Openness] + 0.08);
                    p.Personality.BigFive[BigFiveTrait.Extraversion] = ClampSingle(p.Personality.BigFive[BigFiveTrait.Extraversion] + 0.03);
                    p.Personality.BigFive[BigFiveTrait.Conscientiousness] = ClampSingle(p.Personality.BigFive[BigFiveTrait.Conscientiousness] - 0.03);
                    break;
            }

            //p.Personality.DecisionStyle = element switch
            //{
            //    ElementalPersonalityType.Fire => DecisionStyle.Impulsive,
            //    ElementalPersonalityType.Water => DecisionStyle.Reflective,
            //    ElementalPersonalityType.Earth => DecisionStyle.Deliberate,
            //    ElementalPersonalityType.Air => DecisionStyle.Intuitive,
            //    _ => p.Personality.DecisionStyle
            //};
        }

        private static double NextGaussianClamped(double mean = 0.5, double stdDev = 0.15)
        {
            double u1 = 1.0 - rand.NextDouble();
            double u2 = 1.0 - rand.NextDouble();
            double randStdNormal = Math.Sqrt(-2.0 * Math.Log(u1)) * Math.Sin(2.0 * Math.PI * u2);
            double value = mean + stdDev * randStdNormal;
            return Math.Clamp(value, 0.0, 1.0);
        }

        private static double NextNormal(double mean, double std)
        {
            // Box–Muller (nezávislý na NextGaussianClamped, protože tu chceme i <0, >1 rozsah)
            double u1 = 1.0 - rand.NextDouble();
            double u2 = 1.0 - rand.NextDouble();
            double z = Math.Sqrt(-2.0 * Math.Log(u1)) * Math.Cos(2.0 * Math.PI * u2);
            return mean + std * z;
        }

        private static T PickWeighted<T>(params (T item, double w)[] items)
        {
            double total = 0; foreach (var it in items) total += Math.Max(0, it.w);
            if (total <= 0) return items[0].item;
            double r = rand.NextDouble() * total, acc = 0;
            foreach (var (item, w) in items) { acc += Math.Max(0, w); if (r <= acc) return item; }
            return items[^1].item;
        }

        public static void ApplyArchetype(Person p, string archetype)
        {
            var b5 = p.Personality.BigFive;
            var t = p.Personality.Traits;

            switch (archetype.ToLower())
            {
                case "knight":
                    t.Add(PersonalityTrait.Brave);
                    t.Add(PersonalityTrait.Loyal);
                    b5[BigFiveTrait.Conscientiousness] = Math.Clamp(b5[BigFiveTrait.Conscientiousness] + 0.2, 0, 1);
                    b5[BigFiveTrait.Neuroticism] = Math.Clamp(b5[BigFiveTrait.Neuroticism] - 0.2, 0, 1);
                    p.Personality.Morality[MoralDimension.Care] = Math.Max(p.Personality.Morality[MoralDimension.Care], 0.6);
                    p.Personality.Morality[MoralDimension.Loyalty] = 0.9;
                    break;

                case "survivor":
                    t.Add(PersonalityTrait.Paranoid);
                    b5[BigFiveTrait.Neuroticism] = Math.Min(b5[BigFiveTrait.Neuroticism] + 0.3, 1);
                    b5[BigFiveTrait.Agreeableness] = Math.Max(b5[BigFiveTrait.Agreeableness] - 0.3, 0);
                    p.Personality.Morality[MoralDimension.Liberty] = 0.9;
                    break;

                case "noble":
                    t.Add(PersonalityTrait.Kind);
                    b5[BigFiveTrait.Agreeableness] += 0.2;
                    b5[BigFiveTrait.Conscientiousness] += 0.1;
                    p.Personality.Morality[MoralDimension.Fairness] = 0.85;
                    p.Personality.Morality[MoralDimension.Care] = 0.8;
                    break;

                case "child hero":
                    t.Add(PersonalityTrait.Curious);
                    b5[BigFiveTrait.Openness] = 0.9;
                    b5[BigFiveTrait.Conscientiousness] = 0.4;
                    break;
            }
        }

        public static Person RandomizePerson(List<Name> maleNames, List<Name> femaleNames, List<Surname> surnames, in double minAge, in double maxAge, GenusType? genus, bool useArchetypeAndMagicMerging = false, in double? heightCm = null, in double? weightKg = null)
        {
            if (useArchetypeAndMagicMerging)
            {
                var archetypes = new string[] { "knight", "survivor", "noble", "child hero" };
                var chosen = archetypes[rand.Next(archetypes.Length)];
                return CreatePersonWithArchetypeAndElementalType(chosen, maleNames, femaleNames, surnames, minAge, maxAge, genus);
            }

            return CreateRealisticPerson(maleNames, femaleNames, surnames, minAge, maxAge, genus, heightCm, weightKg);
        }
    }
}
