﻿// Episode.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships.Memory
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using GameEngineTools.World.Utils.Time;

    public sealed class Episode
    {
        public Guid ActorId { get; init; }
        public Guid TargetId { get; init; }
        public string InteractionType { get; init; } = string.Empty;
        /// <summary>
        /// -1..+1 (negativní..pozitivní)
        /// </summary>
        public float Valence { get; init; }
        /// <summary>
        /// 0..1 (míra intimity)
        /// </summary>
        public float Intimacy { get; init; }
        /// <summary>
        /// 0..1 (překvapení/neočekávanost)
        /// </summary>
        public float Surprise { get; init; }
        public HashSet<ThemeTag> Tags { get; init; } = new();
        public WDateTime When { get; init; }
        public float Salience => MathF.Abs(Valence) * 0.6f + Intimacy * 0.3f + Surprise * 0.1f;
    }
}
