﻿// IKnowledgeLedger.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.World.Knowledge
{
    using System;

    public interface IKnowledgeLedger
    {
        /// 0..1 – jak silně pozorovatel věří tvrzení o subjektu.
        float Believe(Guid observerId, Guid subjectId, string claim);

        void Record(Observation o);
    }
}
