﻿// BehaviorRunner.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior
{
    using System.Linq;
    using GameEngineTools.World.Utils.Time;
    using GameEngineTools.Characters.CharacterModel.Behavior.Engine;

    public static class BehaviorRunner
    {
        public static IBehaviorOption? RunOnce(BehaviorEngine engine, BehaviorContext ctx,
                                   IEnumerable<IBehaviorOption> options,
                                   BehaviorCooldowns cooldowns)
        {
            
            var pool = options.Where(o => o.IsApplicable(ctx)).ToList();
            if (pool.Count == 0) return null;

            var chosen = engine.SelectWithTrace(ctx, pool, out var candidates);
            if (chosen is null) return null;

            if (cooldowns.IsOnCooldown(ctx.Actor, ctx.Target, chosen.Type, ctx.When)) return null;

            // TODO: Jak udělat logging v static?

            // Aplikace přes sink → EventBus
            chosen.Apply(ctx);

            // effort-based cooldown: cca 3-9 min
            var effort = BehaviorScoring.EffortOf(chosen.Type);
            var minutes = 3 + (int)Math.Round(12 * effort);

            // Minimální core cooldown (pokud ho engine sám nebumpuje)
            cooldowns.Bump(ctx.Actor, ctx.Target, chosen.Type, WTimeSpan.FromMinutes(minutes), ctx.When);
            return chosen;
        }
    }
}
