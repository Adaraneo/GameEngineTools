﻿// HumanPsychology.Math.cs
// Copyright (c) 50PSoftware

// HumanPsychology.Math.cs
// S-křivky, hysterese, lerp a šum.

namespace GameEngineTools.Characters.Homo
{
    using System;

    public partial class HumanPsychology
    {
        // Jednoduchý nízkofrekvenční šum – malý, adaptivně tlumený SelfControl
        private readonly Random _rng = Random.Shared;

        private static double Clamp01(double x) => Math.Clamp(x, 0, 1);

        private static double Clamp11(double x) => Math.Clamp(x, -1, 1);

        private static double Lerp(double a, double b, double t) => a + (b - a) * Math.Clamp(t, 0, 1);

        // Logistic S-křivka: 1 / (1 + e^(−k(x−x0)))
        private static double Sigmoid(double x, double k, double x0) =>
            1.0 / (1.0 + Math.Exp(-k * (x - x0)));

        // Tanh-s tvar (−1..+1) → transformujeme na 0..1 dle potřeby
        private static double Tanh01(double x, double k, double x0) =>
            0.5 * (Math.Tanh(k * (x - x0)) + 1.0);

        private double SmallNoise(double sigma) => (_rng.NextDouble() * 2 - 1) * sigma * (1.0 - 0.5 * SelfControl);

        // Hysterese pro stavové příznaky (např. „HighStress“)
        internal struct HysteresisGate
        {
            public double Off;
            public double On;
            public bool State;  // aktuální stav (zapnuto/vypnuto)
                                // práh pro zapnutí
                                // práh pro vypnutí

            public HysteresisGate(double on, double off, bool initial = false)
            { State = initial; On = on; Off = off; }

            public bool Update(double value)
            {
                if (!State && value >= On) State = true;
                else if (State && value <= Off) State = false;
                return State;
            }
        }
    }
}
