﻿// WDateTime.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.World.Utils.Time
{
    using System;
    using System.Text.Json.Serialization;
    using GameEngineTools.World.Core.Calendars;
    using GameEngineTools.World.Core.Time;

    /// <summary>
    /// Čistý UTC instant bez závislosti na DateTime. Ukládá tick-y od 1970-01-01T00:00:00Z (1 tick = 100 ns).
    /// Implementuje vlastní civilní kalendář (proleptický gregorián).
    /// </summary>
    [JsonConverter(typeof(WDateTimeJsonConverter))]
    public readonly struct WDateTime :
    IEquatable<WDateTime>, IComparable<WDateTime>, IFormattable
    {
        private static WorldTimeSpec DefaultSpec()
        {
            // Příklad “herního” světa: 1 světová sekunda = 1 reálná sekunda, den = 26 h, rok = 10×36 + přestup 5 dní / 4. rok.
            var cal = new FixedMonthsCalendar(
                new[] { 36, 36, 36, 36, 36, 36, 36, 36, 36, 36 },
                y => (y % 4 == 0) ? 5 : 0
            );
            return new WorldTimeSpec(
                ticksPerSecond: 10_000_000, // světový tick = 100 ns (jen interní jednotka)
                secondsPerMinute: 60,
                minutesPerHour: 60,
                hoursPerDay: 26,
                calendar: cal
            );
        }

        private static void ValidateYMDHMS(int y, int m, int d, int hh, int mi, int ss)
        {
            if (y < 1 || m < 1 || d < 1) throw new ArgumentOutOfRangeException();
            if (hh < 0 || hh >= Spec.HoursPerDay) throw new ArgumentOutOfRangeException(nameof(hh));
            if (mi < 0 || mi >= Spec.MinutesPerHour) throw new ArgumentOutOfRangeException(nameof(mi));
            if (ss < 0 || ss >= Spec.SecondsPerMinute) throw new ArgumentOutOfRangeException(nameof(ss));
            if (d > Spec.Calendar.DaysInMonth(y, m)) throw new ArgumentOutOfRangeException(nameof(d));
        }

        public WDateTime(long worldTicks) => WorldTicks = worldTicks;

        /// <summary>
        /// Vytvoří okamžik ze světových částí (UTC styl): year, month, day, hour, minute, second.
        /// Ověření vstupů a přepočet provádí FromParts(...) dle aktuálního WorldTimeSpec/Calendar.
        /// </summary>
        public WDateTime(int year, int month, int day, int hour, int minute, int second)
            : this(FromParts(year, month, day, hour, minute, second).WorldTicks)
        { }

        public static WorldClock? Clock { get; private set; }

        public static WDateTime MaxValue
        {
            get
            {
                // největší celé množství dní, které se vejde do long.MaxValue ticků
                long fullDays = long.MaxValue / Spec.TicksPerDay;
                long ticksAt00 = fullDays * Spec.TicksPerDay; // zarovnáno na 00:00:00
                return new WDateTime(ticksAt00);
            }
        }

        // --- Bounds aligned to day start ---
        public static WDateTime MinValue => new WDateTime(0);

        public static WDateTime Now
            => Clock is null ? throw new InvalidOperationException("WorldClock is not set.")
                             : new WDateTime(Clock.NowWorldTicks());

        public static WorldTimeSpec Spec { get; private set; } = DefaultSpec();
        // volitelné napojení na real-time

        public WDateTime Date
        {
            get
            {
                // počet celých dní od světové epochy
                long days = Math.DivRem(WorldTicks, Spec.TicksPerDay, out long rem);

                // Pokud někdy povolíš záporné WorldTicks a budeš chtít "floor" chování
                // (tj. -00:01 → předchozí den), odkomentuj:
                // if (rem < 0) days--;

                return new WDateTime(days * Spec.TicksPerDay);
            }
        }

        // DateOnly/TimeOnly “vlastnosti”
        public WDateOnly DateOnly
        {
            get
            {
                long dayIndex = Math.DivRem(WorldTicks, Spec.TicksPerDay, out long _);
                // pokud podporuješ záporné časy a chceš floor, odkomentuj:
                // if (WorldTicks < 0 && _ != 0) dayIndex--;
                return new WDateOnly(dayIndex);
            }
        }

        public int Day
        {
            get { Deconstruct(out _, out _, out var d, out _, out _, out _, out _); return d; }
        }

        public WDateTime DayOfYear
        {
            get
            {
                Deconstruct(out int y, out _, out int d, out _, out _, out _, out _);
                return FromParts(y, 1, 1) + (d - 1) * Spec.TicksPerDay;
            }
        }

        public int Hour
        {
            get { Deconstruct(out _, out _, out _, out var h, out _, out _, out _); return h; }
        }

        /// <summary>
        /// Millisecond v rámci “světové” sekundy. Počítá se ze zbytku worldTicků pod sekundu.
        /// (bezpečné i když Spec.TicksPerSecond není dělitelné 1000)
        /// </summary>
        public int Millisecond
        {
            get
            {
                Deconstruct(out _, out _, out _, out _, out _, out _, out var subTick);
                // floor: 0..999
                return (int)((subTick * 1000L) / Spec.TicksPerSecond);
            }
        }

        public int Minute
        {
            get { Deconstruct(out _, out _, out _, out _, out var m, out _, out _); return m; }
        }

        public int Month
        {
            get { Deconstruct(out _, out var m, out _, out _, out _, out _, out _); return m; }
        }

        public int Second
        {
            get { Deconstruct(out _, out _, out _, out _, out _, out var s, out _); return s; }
        }

        public long Ticks
        {
            get
            {
                if (Clock is null) throw new InvalidOperationException("WorldClock is not set");
                return Clock.EarthEpochUnixTicks;
            }
        }

        public WTimeSpan TimeOfDay
        {
            get
            {
                long rem = WorldTicks % Spec.TicksPerDay;
                if (rem < 0) rem += Spec.TicksPerDay; // jen kdybys šel i do záporných časů
                return new WTimeSpan(rem);
            }
        }

        public WTimeOnly TimeOnly
        {
            get
            {
                long rem = Math.DivRem(WorldTicks, Spec.TicksPerDay, out _);
                if (rem < 0) rem += Spec.TicksPerDay; // pro případ záporných časů
                return new WTimeOnly(rem);
            }
        }

        public long WorldTicks { get; }

        // od 1/1/1 00:00:00 (světová epocha)
        // --- Scalar components (ala DateTime) ---
        public int Year
        {
            get { Deconstruct(out var y, out _, out _, out _, out _, out _, out _); return y; }
        }

        public static WTimeSpan Difference(WDateTime a, WDateTime b) => new(a.WorldTicks - b.WorldTicks);

        // Továrny/withery
        public static WDateTime From(WDateOnly date) => new WDateTime(checked(date.DayIndex * Spec.TicksPerDay));

        public static WDateTime From(WDateOnly date, WTimeOnly time) =>
            new WDateTime(checked(date.DayIndex * Spec.TicksPerDay + time.TicksOfDay));

        // --- Factory z částí ---
        public static WDateTime FromParts(int year, int month, int day, int hour = 0, int minute = 0, int second = 0, long subTick = 0)
        {
            ValidateYMDHMS(year, month, day, hour, minute, second);
            long days = Spec.Calendar.DaysFromDate(year, month, day);
            long ticks = days * Spec.TicksPerDay
                       + hour * Spec.TicksPerHour
                       + minute * Spec.TicksPerMinute
                       + second * Spec.TicksPerSecond
                       + subTick; // volitelný “zlomek” (např. 0..(TicksPerSecond-1))
            return new WDateTime(ticks);
        }

        public static WDateTime Max(WDateTime a, WDateTime b) => a.WorldTicks >= b.WorldTicks ? a : b;

        // Min/Max/Clamp
        public static WDateTime Min(WDateTime a, WDateTime b) => a.WorldTicks <= b.WorldTicks ? a : b;

        // rozdíl dvou okamžiků → počet worldTicků
        public static WTimeSpan operator -(WDateTime a, WDateTime b) => new(a.WorldTicks - b.WorldTicks);

        public static WDateTime operator -(WDateTime a, long ticks) => new(a.WorldTicks - ticks);

        public static WDateTime operator -(WDateTime t, WTimeSpan d) => new(t.WorldTicks - d.Ticks);

        public static WDateTime operator --(WDateTime a) => new(a.WorldTicks - 1);

        public static bool operator !=(WDateTime left, WDateTime right) => left.WorldTicks != right.WorldTicks;

        // --- Aritmetika / porovnání & utility ---
        // posuny v tickách (pravá i levá forma)
        public static WDateTime operator +(WDateTime a, long ticks) => new(a.WorldTicks + ticks);

        public static WDateTime operator +(long ticks, WDateTime a) => new(a.WorldTicks + ticks);

        // date ± span
        public static WDateTime operator +(WDateTime t, WTimeSpan d) => new(t.WorldTicks + d.Ticks);

        public static WDateTime operator +(WTimeSpan d, WDateTime t) => new(t.WorldTicks + d.Ticks);

        // inkrement/dekrement po 1 worldTicku
        public static WDateTime operator ++(WDateTime a) => new(a.WorldTicks + 1);

        public static bool operator <(WDateTime left, WDateTime right) => left.WorldTicks < right.WorldTicks;

        public static bool operator <=(WDateTime left, WDateTime right) => left.WorldTicks <= right.WorldTicks;

        // relační a rovnostní operátory
        public static bool operator ==(WDateTime left, WDateTime right) => left.WorldTicks == right.WorldTicks;

        public static bool operator >(WDateTime left, WDateTime right) => left.WorldTicks > right.WorldTicks;

        public static bool operator >=(WDateTime left, WDateTime right) => left.WorldTicks >= right.WorldTicks;

        // --- Parsing: ReadOnlySpan<char> overload ---
        public static bool TryParse(ReadOnlySpan<char> input, out WDateTime value)
        {
            value = default;

            // trim bez alokací
            int start = 0, end = input.Length;
            while (start < end && char.IsWhiteSpace(input[start])) start++;
            while (end > start && char.IsWhiteSpace(input[end - 1])) end--;
            var s = input.Slice(start, end - start);
            if (s.Length == 0) return false;

            // volitelné koncové 'Z'/'z' ignorujeme
            if (s.Length > 0)
            {
                char last = s[^1];
                if (last == 'Z' || last == 'z') s = s[..^1];
            }

            // split na datum a čas podle 'T' nebo mezery
            int iT = s.IndexOf('T');
            int iSP = s.IndexOf(' ');
            int sep = (iT >= 0 && iSP >= 0) ? Math.Min(iT, iSP) : Math.Max(iT, iSP);

            ReadOnlySpan<char> datePart = s;
            ReadOnlySpan<char> timePart = ReadOnlySpan<char>.Empty;
            if (sep >= 0)
            {
                datePart = s[..sep];
                timePart = s[(sep + 1)..];
                // ořízni případné whitespace u timePart
                int ts = 0, te = timePart.Length;
                while (ts < te && char.IsWhiteSpace(timePart[ts])) ts++;
                while (te > ts && char.IsWhiteSpace(timePart[te - 1])) te--;
                timePart = timePart.Slice(ts, te - ts);
            }

            // --- DATE: "YYYY-MM-DD"
            if (datePart.Length < 10 || datePart[4] != '-' || datePart[7] != '-') return false;

            if (!TryParseInt(datePart[..4], 1, int.MaxValue, out int year)) return false;
            if (!TryParseInt(datePart.Slice(5, 2), 1, 99, out int month)) return false;
            if (!TryParseInt(datePart.Slice(8, 2), 1, 99, out int day)) return false;

            // --- TIME: "HH:MM:SS[.frac]" nebo "HH:MM:SS[.subticks]#"
            int hour = 0, minute = 0, second = 0;
            long subTick = 0;

            if (timePart.Length > 0)
            {
                ReadOnlySpan<char> main = timePart;
                ReadOnlySpan<char> frac = ReadOnlySpan<char>.Empty;
                int dot = timePart.IndexOf('.');
                if (dot >= 0)
                {
                    main = timePart[..dot];
                    frac = timePart[(dot + 1)..];
                }

                if (main.Length < 8 || main[2] != ':' || main[5] != ':') return false;

                var spec = Spec;
                if (!TryParseInt(main[..2], 0, spec.HoursPerDay - 1, out hour)) return false;
                if (!TryParseInt(main.Slice(3, 2), 0, spec.MinutesPerHour - 1, out minute)) return false;
                if (!TryParseInt(main.Slice(6, 2), 0, spec.SecondsPerMinute - 1, out second)) return false;

                if (!frac.IsEmpty)
                {
                    bool rawTicks = false;
                    if (frac[^1] == 'W') { rawTicks = true; frac = frac[..^1]; }
                    if (frac.Length == 0) return false;

                    // jen číslice
                    for (int i = 0; i < frac.Length; i++)
                    {
                        char c = frac[i];
                        if ((uint)(c - '0') > 9U) return false;
                    }

                    if (rawTicks)
                    {
                        if (!TryParseInt64(frac, 0, spec.TicksPerSecond - 1, out subTick)) return false;
                    }
                    else
                    {
                        // desetinný podíl sekundy → worldTicky (trunc, ochrana proti overflow)
                        int n = Math.Min(frac.Length, 18);
                        if (!TryParseInt64(frac[..n], 0, long.MaxValue, out long fracVal)) return false;
                        long pow10 = Pow10(n);
                        subTick = (fracVal * spec.TicksPerSecond) / pow10;
                        if (subTick >= spec.TicksPerSecond) subTick = spec.TicksPerSecond - 1;
                    }
                }
            }

            // validace datumu a výpočet ticků
            long days;
            try { days = Spec.Calendar.DaysFromDate(year, month, day); }
            catch { return false; }

            long ticks = days * Spec.TicksPerDay
                       + hour * Spec.TicksPerHour
                       + minute * Spec.TicksPerMinute
                       + second * Spec.TicksPerSecond
                       + subTick;

            value = new WDateTime(ticks);
            return true;

            // --- lokální helpery bez alokací ---
            static bool TryParseInt(ReadOnlySpan<char> span, int min, int max, out int val)
            {
                long acc = 0;
                for (int i = 0; i < span.Length; i++)
                {
                    int d = span[i] - '0';
                    if ((uint)d > 9U) { val = 0; return false; }
                    acc = acc * 10 + d;
                    if (acc > int.MaxValue) { val = 0; return false; }
                }
                val = (int)acc;
                return val >= min && val <= max;
            }

            static bool TryParseInt64(ReadOnlySpan<char> span, long min, long max, out long val)
            {
                long acc = 0;
                for (int i = 0; i < span.Length; i++)
                {
                    int d = span[i] - '0';
                    if ((uint)d > 9U) { val = 0; return false; }
                    if (acc > (long.MaxValue - d) / 10) { val = 0; return false; }
                    acc = acc * 10 + d;
                }
                val = acc;
                return val >= min && val <= max;
            }

            static long Pow10(int n)
            {
                long p = 1;
                for (int i = 0; i < n; i++) p *= 10;
                return p;
            }
        }

        public static bool TryParse(string? text, out WDateTime value)
        {
            value = default;
            if (string.IsNullOrWhiteSpace(text)) return false;

            ReadOnlySpan<char> s = text.AsSpan().Trim();

            // volitelné koncové 'Z'/'z' ignorujeme (aby se to nepletlo s UTC na Zemi)
            if (s.Length > 0)
            {
                char last = s[^1];
                if (last == 'Z' || last == 'z') s = s[..^1];
            }

            // rozdělíme na datum a čas podle 'T' nebo mezery
            int iT = s.IndexOf('T');
            int iSP = s.IndexOf(' ');
            int sep = (iT >= 0 && iSP >= 0) ? Math.Min(iT, iSP) : Math.Max(iT, iSP);

            ReadOnlySpan<char> datePart = s;
            ReadOnlySpan<char> timePart = ReadOnlySpan<char>.Empty;
            bool hasTime = sep >= 0;
            if (hasTime)
            {
                datePart = s[..sep];
                timePart = s[(sep + 1)..].Trim();
                if (timePart.Length == 0) hasTime = false;
            }

            // --- DATE: "YYYY-MM-DD"
            if (datePart.Length < 10 || datePart[4] != '-' || datePart[7] != '-')
                return false;

            if (!TryParseInt(datePart[..4], 1, int.MaxValue, out int year)) return false;
            if (!TryParseInt(datePart.Slice(5, 2), 1, 99, out int month)) return false;
            if (!TryParseInt(datePart.Slice(8, 2), 1, 99, out int day)) return false;

            // --- TIME: "HH:MM:SS[.frac]" nebo "HH:MM:SS[.subticks]#"
            int hour = 0, minute = 0, second = 0;
            long subTick = 0;

            if (hasTime)
            {
                // odděl frakci
                ReadOnlySpan<char> main = timePart;
                ReadOnlySpan<char> frac = ReadOnlySpan<char>.Empty;
                int dot = timePart.IndexOf('.');
                if (dot >= 0)
                {
                    main = timePart[..dot];
                    frac = timePart[(dot + 1)..];
                }

                if (main.Length < 8 || main[2] != ':' || main[5] != ':')
                    return false;

                if (!TryParseInt(main[..2], 0, WDateTime.Spec.HoursPerDay - 1, out hour)) return false;
                if (!TryParseInt(main.Slice(3, 2), 0, WDateTime.Spec.MinutesPerHour - 1, out minute)) return false;
                if (!TryParseInt(main.Slice(6, 2), 0, WDateTime.Spec.SecondsPerMinute - 1, out second)) return false;

                if (!frac.IsEmpty)
                {
                    bool rawTicks = false;
                    if (frac[^1] == 'W')
                    {
                        rawTicks = true;
                        frac = frac[..^1];
                    }

                    // všechno musí být číslice
                    for (int i = 0; i < frac.Length; i++)
                    {
                        char c = frac[i];
                        if (c < '0' || c > '9') return false;
                    }
                    if (frac.Length == 0) return false;

                    if (rawTicks)
                    {
                        // přímé worldTicky pod sekundu (round-trip s ToString -> ".{sub}W")
                        if (!TryParseInt64(frac, 0, WDateTime.Spec.TicksPerSecond - 1, out subTick)) return false;
                    }
                    else
                    {
                        // desetinný podíl sekundy → worldTicky (trunc)
                        long pow10 = Pow10(Math.Min(frac.Length, 18)); // ochrana proti overflow
                        if (!TryParseInt64(frac[..Math.Min(frac.Length, 18)], 0, long.MaxValue, out long fracVal)) return false;

                        // škáluj: subTick = floor(frac * TicksPerSecond)
                        // tedy: (fracVal / 10^n) * TicksPerSecond
                        subTick = (fracVal * WDateTime.Spec.TicksPerSecond) / pow10;

                        // pokud bylo cifer víc než 18, zbytek ignorujeme (trunc)
                        if (subTick >= WDateTime.Spec.TicksPerSecond) subTick = WDateTime.Spec.TicksPerSecond - 1;
                    }
                }
            }

            // převeď na worldTicks
            long days;
            try
            {
                days = WDateTime.Spec.Calendar.DaysFromDate(year, month, day);
            }
            catch
            {
                return false; // neplatné datum podle kalendáře
            }

            long ticks = days * WDateTime.Spec.TicksPerDay
                       + hour * WDateTime.Spec.TicksPerHour
                       + minute * WDateTime.Spec.TicksPerMinute
                       + second * WDateTime.Spec.TicksPerSecond
                       + subTick;

            value = new WDateTime(ticks);
            return true;

            // --- lokální pomocníci ---
            static bool TryParseInt(ReadOnlySpan<char> span, int min, int max, out int val)
            {
                long acc = 0;
                for (int i = 0; i < span.Length; i++)
                {
                    char c = span[i];
                    if (c < '0' || c > '9') { val = 0; return false; }
                    acc = acc * 10 + (c - '0');
                    if (acc > int.MaxValue) { val = 0; return false; }
                }
                val = (int)acc;
                return val >= min && val <= max;
            }

            static bool TryParseInt64(ReadOnlySpan<char> span, long min, long max, out long val)
            {
                long acc = 0;
                for (int i = 0; i < span.Length; i++)
                {
                    char c = span[i];
                    if (c < '0' || c > '9') { val = 0; return false; }
                    long d = c - '0';
                    // overflow-safe: předem ověř
                    if (acc > (long.MaxValue - d) / 10) { val = 0; return false; }
                    acc = acc * 10 + d;
                }
                val = acc;
                return val >= min && val <= max;
            }

            static long Pow10(int n)
            {
                long p = 1;
                for (int i = 0; i < n; i++) p *= 10;
                return p;
            }
        }

        public static void Use(WorldTimeSpec spec) => Spec = spec;

        public static void UseClock(WorldClock clock) => Clock = clock;

        // pohodlné Add* s WTimeSpan
        public WDateTime Add(WTimeSpan span) => new(WorldTicks + span.Ticks);

        public WDateTime AddDays(long d) => new(WorldTicks + d * Spec.TicksPerDay);

        public WDateTime AddDays(double d) => this + WTimeSpan.FromDays(d);

        public WDateTime AddHours(long h) => new(WorldTicks + h * Spec.TicksPerHour);

        public WDateTime AddHours(double h) => this + WTimeSpan.FromHours(h);

        public WDateTime AddMinutes(long m) => new(WorldTicks + m * Spec.TicksPerMinute);

        public WDateTime AddMinutes(double m) => this + WTimeSpan.FromMinutes(m);

        public WDateTime AddSeconds(long s) => new(WorldTicks + s * Spec.TicksPerSecond);

        public WDateTime AddSeconds(double s) => this + WTimeSpan.FromSeconds(s);

        // pohodlné Add* bez BCL
        public WDateTime AddTicks(long ticks) => new(WorldTicks + ticks);

        public WDateTime Clamp(in WDateTime min, in WDateTime max)
        {
            if (min.WorldTicks > max.WorldTicks) throw new ArgumentException("min > max");
            if (WorldTicks < min.WorldTicks) return min;
            if (WorldTicks > max.WorldTicks) return max;
            return this;
        }

        // IComparable / IEquatable zůstává, jen ať jsou pohromadě:
        public int CompareTo(WDateTime other) => WorldTicks.CompareTo(other.WorldTicks);

        // --- Rozklad ---
        public void Deconstruct(out int year, out int month, out int day, out int hour, out int minute, out int second, out long subTick)
        {
            long dayIndex = Math.DivRem(WorldTicks, Spec.TicksPerDay, out long rest);
            (year, month, day) = Spec.Calendar.DateFromDays(dayIndex);

            hour = (int)(rest / Spec.TicksPerHour); rest -= hour * Spec.TicksPerHour;
            minute = (int)(rest / Spec.TicksPerMinute); rest -= minute * Spec.TicksPerMinute;
            second = (int)(rest / Spec.TicksPerSecond); rest -= second * Spec.TicksPerSecond;
            subTick = rest;
        }

        // rozdíl jako WTimeSpan (ponech klidně i svoji původní verzi vracející long)
        public WTimeSpan Diff(WDateTime other) => new(this.WorldTicks - other.WorldTicks);

        public bool Equals(WDateTime other) => WorldTicks == other.WorldTicks;

        public override bool Equals(object? obj) => obj is WDateTime d && Equals(d);

        public override int GetHashCode() => WorldTicks.GetHashCode();

        // --- Formatování (světové ISO) ---
        public override string ToString() => ToString("O");

        public string ToString(string? format, IFormatProvider? _ = null)
        {
            Deconstruct(out var y, out var m, out var d, out var hh, out var mm, out var ss, out var sub);
            // “O”: YYYY-MM-DDTHH:MM:SS[.ttt] (ttt = podtick v rámci Spec.TicksPerSecond)
            var sb = new System.Text.StringBuilder(32);
            Append4(sb, y); sb.Append('-'); Append2(sb, m); sb.Append('-'); Append2(sb, d);
            sb.Append('T'); Append2(sb, hh); sb.Append(':'); Append2(sb, mm); sb.Append(':'); Append2(sb, ss);
            if (sub != 0)
            {
                sb.Append('.');
                // normalizuj subTick na základě TicksPerSecond (vypiš bez zbytečných nul)
                var scale = Spec.TicksPerSecond;
                // vytiskneme jako celé číslo s base-10; pro velká scale lze omezit
                sb.Append(sub.ToString());
                sb.Append('W'); // volitelná značka “světový podtick” – ať se to neplete s ns
            }
            return sb.ToString();

            static void Append2(System.Text.StringBuilder b, int v)
            { b.Append((char)('0' + v / 10)); b.Append((char)('0' + v % 10)); }
            static void Append4(System.Text.StringBuilder b, int v)
            { b.Append((char)('0' + (v / 1000) % 10)); b.Append((char)('0' + (v / 100) % 10)); b.Append((char)('0' + (v / 10) % 10)); b.Append((char)('0' + v % 10)); }
        }

        public WDateTime WithDate(WDateOnly date) => From(date, this.TimeOnly);

        public WDateTime WithTime(WTimeOnly time) => From(this.DateOnly, time);
    }
}
