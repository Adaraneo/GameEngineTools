﻿// AskForConsent.cs
// Copyright (c) 50PSoftware

using GameEngineTools.Characters.CharacterModel.Homo;
using GameEngineTools.Characters.CharacterModel.Relationships;

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    /// Explicitní žádost o souhlas (etiketa před intimnější eskalací).
    /// Typicky jemná "Honesty" s malým ↑Depth/Warmth, mírné ↑Risk.
    public sealed class AskForConsent : IBehaviorOption
    {
        // Reuse honesty cooldown koše
        public BehaviorType Type => BehaviorType.AskForConsent;

        public void Apply(in BehaviorContext ctx)
        {
            // Jemná, explicitní "Honesty" – posune Depth/Warmth a Continuity,
            // lehce zvedne Risk (zranitelnost) a SharedGoal (společné naladění).
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Honesty,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    Privacy = Math.Max(ctx.Ix.Privacy, 0.60f),
                    SocialAudience = 0.0f,
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.12f, 0f, 1f),
                    Warmth = Math.Clamp(ctx.Ix.Warmth + 0.12f, 0f, 1f),
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.08f, -1f, 1f),
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.06f, 0f, 1f),
                    SharedGoal = Math.Clamp(ctx.Ix.SharedGoal + 0.10f, 0f, 1f),
                    Continuity = Math.Clamp(ctx.Ix.Continuity + 0.10f, 0f, 1f),
                    Physicality = ctx.Ix.Physicality,
                    Surprise = ctx.Ix.Surprise
                }
            };

            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
        {
            if (ctx.Target is null || !ctx.Rel.HasValue) return false;
            var r = ctx.Rel.Value;

            // Bezpečný rámec pro dotaz
            bool stageOk = r.Stage >= BondStage.Intimate;
            bool trustOk = r.Trust >= 55f;                 // nechť je to spíš pozitivní gesto než sázka do loterie
            bool privacyOk = ctx.Ix.Privacy >= 0.55f && ctx.Ix.SocialAudience <= 0.10f;
            bool toneOk = ctx.Ix.EmotionalTone >= -0.10f; // neptáme se u velmi negativní nálady
            bool readiness = (ctx.Ix.Depth >= 0.30f || ctx.Ix.Physicality >= 0.20f);

            return stageOk && trustOk && privacyOk && toneOk && readiness;
        }

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality;
            var psy = ctx.Actor.Psychology;
            var r = ctx.Rel!.Value;

            double A = per.BigFive[BigFiveTrait.Agreeableness];
            double C = per.BigFive[BigFiveTrait.Conscientiousness];

            double u =
                0.10
              + 0.25 * A
              + 0.15 * C
              + 0.20 * (r.Trust / 100.0)
              + 0.15 * ctx.Ix.Privacy
              + 0.10 * (0.5 + 0.5 * psy.Mood)
              - 0.10 * psy.StressLevel
              - 0.08 * ctx.Ix.SocialAudience;

            return Bx.Clamp01(u);
        }
    }
}
