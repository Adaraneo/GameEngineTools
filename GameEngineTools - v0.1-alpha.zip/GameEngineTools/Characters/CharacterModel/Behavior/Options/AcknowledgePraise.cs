﻿// AcknowledgePraise.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// Klidné přijetí pochvaly – potvrzení vztahové vazby, malý růst depth/warmth.
    public sealed class AcknowledgePraise : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.GreetWarmly;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.SpendTime,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    EmotionalTone = System.Math.Clamp(ctx.Ix.EmotionalTone + 0.20f, -1f, 1f),
                    Depth = System.Math.Clamp(ctx.Ix.Depth + 0.10f, 0f, 1f),
                    Privacy = ctx.Ix.Privacy,
                    Risk = ctx.Ix.Risk,
                    SocialAudience = ctx.Ix.SocialAudience,
                    SharedGoal = ctx.Ix.SharedGoal,
                    Continuity = System.Math.Clamp(ctx.Ix.Continuity + 0.10f, 0f, 1f)
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && ctx.Situation == SituationType.PraiseReceived;

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality;
            var psy = ctx.Actor.Psychology;
            double A = per.BigFive[BigFiveTrait.Agreeableness];
            double E = per.BigFive[BigFiveTrait.Extraversion];

            // Afiliační cíl pomáhá „otevřít se“ – přidej váhu Goals.AffiliationNeed01
            double u = 0.15 + 0.25 * A + 0.20 * E
                       + 0.20 * (0.5 + 0.5 * psy.Mood)
                       + 0.20 * ctx.Goals.AffiliationNeed01
                       - 0.10 * psy.StressLevel;
            return Bx.Clamp01(u);
        }
    }
}
