﻿// GracefulExit.cs
// Copyright (c) 50PSoftware

using GameEngineTools.Characters.CharacterModel.Homo;

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    /// Zdvořilý ústup (dát prostor), minimální zásah.
    public sealed class GracefulExit : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.Withdraw;

        public void Apply(in BehaviorContext ctx)
        {
            // Necháme to „beze slova“ – signalizuje tím, že se nic neenqueuje.
            // Alternativně by šlo přidat mikro SpendTime se sníženou Continuity.
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && (ctx.Actor.Psychology.Fatigue > 0.6f || ctx.CrowdNoise01 > 0.5f);

        public float Utility(in BehaviorContext ctx)
        {
            var psy = ctx.Actor.Psychology;
            double u = 0.10 + 0.35 * psy.Fatigue + 0.20 * psy.StressLevel + 0.15 * ctx.CrowdNoise01
                       - 0.20 * ctx.Actor.Personality.BigFive[BigFiveTrait.Extraversion];
            return Bx.Clamp01(u);
        }
    }
}
