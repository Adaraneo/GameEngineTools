﻿// PlayableCharacter.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.GameObjects
{
    using GameEngineTools.Characters.CharacterModel.Homo;

    /// <summary>
    /// Playable character
    /// </summary>
    public class PC : NPPC
    {
        public PC() : base()
        {
        }

        public PC(int maxHealth, Person person) : base(maxHealth, person)
        {
        }
    }
}
