﻿// HonestDisclosureLight.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    public sealed class HonestDisclosureLight : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.HonestDisclosureLight;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Honesty,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.30f, 0f, 1f),
                    Privacy = ctx.Ix.Privacy,
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.05f, -1f, 1f),
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.05f, 0f, 1f),
                    SocialAudience = 0f,
                    SharedGoal = ctx.Ix.SharedGoal,
                    Continuity = Math.Clamp(ctx.Ix.Continuity + 0.10f, 0f, 1f)
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx) => ctx.Target is not null;

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality;
            var psy = ctx.Actor.Psychology;
            double O = per.BigFive[Homo.BigFiveTrait.Openness];
            double honesty = per.Morality.Scores.GetValueOrDefault(Homo.MoralDimension.Honesty);

            double privacy = ctx.Ix.Privacy;
            double trust = (ctx.Rel?.Trust ?? 50f) / 100.0;

            double u = 0.05 + 0.25 * O + 0.20 * honesty + 0.20 * privacy + 0.20 * trust
                       + 0.10 * (0.5 + 0.5 * psy.Mood);
            return Bx.Clamp01(u);
        }
    }
}
