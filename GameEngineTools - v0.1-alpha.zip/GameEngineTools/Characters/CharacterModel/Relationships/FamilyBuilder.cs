﻿// FamilyBuilder.cs — modern rewrite for fast family wiring and optional romance fast‑forward
// Target: .NET 8 / C# 12

#nullable enable

using System;
using System.Collections.Generic;
using System.Linq;
using GameEngineTools.Characters.CharacterModel.Homo;
using GameEngineTools.World.Utils.Time; // assumes WDateTime/WTimeSpan live here

namespace GameEngineTools.Characters.CharacterModel.Relationships
{
    /// <summary>
    /// Builds a nuclear family (parents + children) and (optionally) fast‑forwards
    /// partner romance without running the full simulation. Keeps old convenience
    /// overloads but adds a configurable <see cref="FamilyOptions"/>.
    /// </summary>
    public static class FamilyBuilder
    {
        // ===== Public API ======================================================

        public sealed record FamilyOptions(
            bool ParentsAsPartners = true,
            bool ParentsMarried = true,
            bool AssignChildrenSurnameFromFather = true,
            BondStageVector.BondStageVectorAxes? ParentsAxes = null,
            ((float min, float max) liking, (float min, float max) trust, (float min, float max) closeness)? ParentChildAxesRange = null,
            ((float min, float max) liking, (float min, float max) trust, (float min, float max) closeness)? SiblingAxesRange = null,
            RomanceSeedingMode RomanceMode = RomanceSeedingMode.InstantPlateau,
            RomancePlan? Romance = null,
            WDateTime? Now = null,
            BondStageVector? StageThresholds = null,
            float StageEmaDaysForSeeding = 0f
        )
        {
            public static FamilyOptions Default => new(
                ParentsAsPartners: true,
                ParentsMarried: true,
                AssignChildrenSurnameFromFather: true,
                ParentsAxes: new BondStageVector.BondStageVectorAxes(85, 88, 78, 81),
                ParentChildAxesRange: ((30, 45), (40, 55), (25, 40)),
                SiblingAxesRange: ((25, 42), (18, 28), (25, 38)),
                RomanceMode: RomanceSeedingMode.InstantPlateau,
                Romance: RomancePlan.Default,
                Now: null,
                StageThresholds: null,
                StageEmaDaysForSeeding: 0f
            );
            public static FamilyOptions Simulated => new(
                ParentsAsPartners: true,
                ParentsMarried: false,
                AssignChildrenSurnameFromFather: true,
                ParentsAxes: new BondStageVector.BondStageVectorAxes(70, 65, 70, 75),
                ParentChildAxesRange: ((30, 45), (40, 55), (25, 40)),
                SiblingAxesRange: ((25, 42), (18, 28), (25, 38)),
                RomanceMode: RomanceSeedingMode.FastMontage,
                Romance: RomancePlan.Default,
                Now: null,
                StageThresholds: null,
                StageEmaDaysForSeeding: 3f
            );
        }

        public enum RomanceSeedingMode
        {
            /// <summary>No romance seeding; only kinship/bonds + (optional) parent axes.</summary>
            None = 0,
            /// <summary>Directly set high axes and stage for partners (no timeline).</summary>
            InstantPlateau = 1,
            /// <summary>Apply a short, back‑dated interaction montage to reach stable stage.</summary>
            FastMontage = 2
        }

        public sealed record RomancePlan(
            int Months = 6,
            int InteractionsPerWeek = 3,
            float BaseEffect = 1.0f,
            float ConflictProbability = 0.08f,
            float RepairProbability = 0.50f,
            bool IncludeFlirt = true,
            bool IncludeKiss = true,
            bool IncludeSex = false
        )
        {
            public static RomancePlan Default => new();
        }

        public sealed record FamilyN(Person Father, Person Mother, IReadOnlyList<Person> Children);

        /// <summary>
        /// Modern entry point: creates kinship + bonds, seeds axes, and optionally
        /// fast‑forwards partner romance.
        /// </summary>
        public static FamilyN WireUp(
            RelationshipManager rm,
            Person father,
            Person mother,
            IEnumerable<Person> children,
            FamilyOptions? options = null,
            Random? rng = null)
        {
            if (rm is null) throw new ArgumentNullException(nameof(rm));
            if (father is null || mother is null) throw new ArgumentNullException("Father and mother must be provided.");
            if (children is null) throw new ArgumentNullException(nameof(children));

            var opts = options ?? FamilyOptions.Default;
            rng ??= new Random(1337);

            var now = opts.Now ?? SafeNow();
            var kids = children.ToList();
            if (kids.Count == 0) throw new ArgumentException("At least one child must be provided.", nameof(children));

            EnsureDistinctPersons(new[] { father, mother }.Concat(kids));
            ValidateParentAge(father, mother, kids);

            // Civil status + surname
            TrySetCivilStatusCouple(father, mother, married: opts.ParentsMarried);
            if (opts.AssignChildrenSurnameFromFather)
            {
                foreach (var c in kids)
                {
                    try { c.SetSurname(father.GetSurname()); }
                    catch { /* ignore if not supported */ }
                }
            }

            // 1) Kinship
            foreach (var c in kids)
            {
                rm.SetKinship(father, c, KinshipRole.Father);
                rm.SetKinship(mother, c, KinshipRole.Mother);
            }

            for (int i = 0; i < kids.Count; i++)
            {
                for (int j = i + 1; j < kids.Count; j++)
                {
                    var a = kids[i];
                    var b = kids[j];
                    var roleAB = a.Genus == GenusType.Female ? KinshipRole.Sister : KinshipRole.Brother;
                    rm.SetKinship(a, b, roleAB);
                }
            }

            // 2) BondKind/Tags
            SetFamilyBond(rm, father, mother, partner: opts.ParentsAsPartners, areMarried: opts.ParentsMarried);
            foreach (var c in kids)
            {
                SetFamilyBond(rm, father, c);
                SetFamilyBond(rm, mother, c);
            }
            for (int i = 0; i < kids.Count; i++)
                for (int j = i + 1; j < kids.Count; j++)
                    SetFamilyBond(rm, kids[i], kids[j]);

            // 3) Seed axes (parents, parent-child, siblings)
            var parentsAxes = opts.ParentsAxes ?? new BondStageVector.BondStageVectorAxes(85, 88, 78, 81);
            SeedAxesPair(rm, father, mother, (int)parentsAxes.LikingMin, (int)parentsAxes.TrustMin, (int)parentsAxes.ClosenessMin, (int)parentsAxes.AttractionMin.GetValueOrDefault());

            var pc = opts.ParentChildAxesRange ?? ((30, 45), (40, 55), (25, 40));
            foreach (var c in kids)
            {
                SeedAxesPair(rm, father, c,
                    rng.Next((int)pc.liking.min, (int)pc.liking.max + 1),
                    rng.Next((int)pc.trust.min, (int)pc.trust.max + 1),
                    rng.Next((int)pc.closeness.min, (int)pc.closeness.max + 1),
                    0);

                SeedAxesPair(rm, mother, c,
                    rng.Next((int)pc.liking.min, (int)pc.liking.max + 1),
                    rng.Next((int)pc.trust.min, (int)pc.trust.max + 1),
                    rng.Next((int)pc.closeness.min, (int)pc.closeness.max + 1),
                    0);
            }

            var sib = opts.SiblingAxesRange ?? ((25, 42), (18, 28), (25, 38));
            for (int i = 0; i < kids.Count; i++)
                for (int j = i + 1; j < kids.Count; j++)
                    SeedAxesPair(rm, kids[i], kids[j],
                        rng.Next((int)sib.liking.min, (int)sib.liking.max + 1),
                        rng.Next((int)sib.trust.min, (int)sib.trust.max + 1),
                        rng.Next((int)sib.closeness.min, (int)sib.closeness.max + 1),
                        0);

            // 4) Romance seeding for parents
            if (opts.ParentsAsPartners)
            {
                switch (opts.RomanceMode)
                {
                    case RomanceSeedingMode.None:
                        break;

                    case RomanceSeedingMode.InstantPlateau:
                        InstantRomancePlateau(rm, father, mother, opts);
                        break;

                    case RomanceSeedingMode.FastMontage:
                        var plan = opts.Romance ?? RomancePlan.Default;
                        RunPartnerMontage(rm, father, mother, now, opts, plan, rng);
                        break;
                }
            }

            // 5) Stage recompute (after both directions are seeded)
            // Partners has been handled in montage.
            foreach (var c in kids)
            {
                RecomputeStagesFor(rm, father, c, opts);
                RecomputeStagesFor(rm, mother, c, opts);
            }
            for (int i = 0; i < kids.Count; i++)
                for (int j = i + 1; j < kids.Count; j++)
                    RecomputeStagesFor(rm, kids[i], kids[j], opts);

            return new FamilyN(father, mother, kids);
        }

        /// <summary>
        /// Back‑compat: father+mother+2 kids wrapper using defaults.
        /// </summary>
        public static FamilyN WireUp(RelationshipManager rm, Person father, Person mother, Person child1, Person child2,
                                     bool parentsAsPartners = true, FamilyOptions? options = null, Random? rng = null)
            => WireUp(rm, father, mother, new[] { child1, child2 },
                      options ?? FamilyOptions.Default with { ParentsAsPartners = parentsAsPartners }, rng);

        // ===== Romance helpers =================================================

        private static void InstantRomancePlateau(RelationshipManager rm, Person a, Person b, FamilyOptions opts)
        {
            // High-but-plausible starting values
            const int L = 88, T = 90, C = 82, A = 80;
            SeedAxesPair(rm, a, b, L, T, C, A);
            var r1 = rm.GetRelationship(a, b);
            var r2 = rm.GetRelationship(b, a);
            if (opts.StageThresholds is not null)
            {
                r1.UpdateEma(opts.StageEmaDaysForSeeding);
                r1.EvaluateStage(opts.StageThresholds, opts.StageEmaDaysForSeeding);
                r2.UpdateEma(opts.StageEmaDaysForSeeding);
                r2.EvaluateStage(opts.StageThresholds, opts.StageEmaDaysForSeeding);
            }
            else
            {
                r1.SetStage(GuessStage(r1));
                r2.SetStage(GuessStage(r2));
            }
        }

        private static void RunPartnerMontage(RelationshipManager rm, Person a, Person b, WDateTime now, FamilyOptions opts, RomancePlan plan, Random rng)
        {
            // Build a short back‑dated timeline and apply interactions via ApplyInteractionAt.
            // NOTE: We assume central Decay service handles decay globally. For safety, we monotonically increase `when`.
            var start = now - WTimeSpan.FromDays(plan.Months * 30);
            var weeks = Math.Max(1, (int)Math.Ceiling(plan.Months * 4.345));

            // Gentle warmup: first month fewer interactions
            for (int w = 0; w < weeks; w++)
            {
                var perWeek = plan.InteractionsPerWeek;
                if (w < 4) perWeek = Math.Max(1, (int)Math.Round(perWeek * 0.6));

                for (int i = 0; i < perWeek; i++)
                {
                    var dayOffset = rng.Next(0, 7);
                    var hour = rng.Next(9, 22);
                    var minute = rng.Next(0, 60);
                    var when = start + WTimeSpan.FromDays(w * 7 + dayOffset)
                                       + WTimeSpan.FromHours(hour)
                                       + WTimeSpan.FromMinutes(minute);

                    var type = PickRomanceInteraction(rng, plan.IncludeFlirt, plan.IncludeKiss, plan.IncludeSex);
                    rm.ApplyInteractionAt(a, b, type, when, baseEffect: plan.BaseEffect);
                    RecomputeStagesFor(rm, a, b, opts); // keep stage up-to-date
                    rm.ApplyInteractionAt(b, a, type, when, baseEffect: plan.BaseEffect);
                    RecomputeStagesFor(rm, b, a, opts); // keep stage up-to-date

                    // occasional conflict, mostly tiny, followed by repair
                    if (rng.NextDouble() < plan.ConflictProbability)
                    {
                        var cWhen = when + WTimeSpan.FromHours(rng.Next(2, 18));
                        rm.ApplyInteractionAt(a, b, InteractionType.Argument, cWhen, baseEffect: 0.6f * plan.BaseEffect);
                        RecomputeStagesFor(rm, a, b, opts); // keep stage up-to-date

                        if (rng.NextDouble() < plan.RepairProbability)
                        {
                            var rWhen = cWhen + WTimeSpan.FromHours(rng.Next(8, 48));
                            rm.ApplyInteractionAt(b, a, InteractionType.Apology, rWhen, baseEffect: 1.1f * plan.BaseEffect);
                            RecomputeStagesFor(rm, b, a, opts); // keep stage up-to-date
                        }
                    }
                }
            }
        }

        private static InteractionType PickRomanceInteraction(Random rng, bool includeFlirt, bool includeKiss, bool includeSex)
        {
            // Very simple discrete distribution geared toward bonding
            var roll = rng.NextDouble();
            if (roll < 0.35) return InteractionType.Conversation;
            if (roll < 0.60) return InteractionType.SharedActivity;
            if (roll < 0.75) return InteractionType.Help;
            if (roll < 0.88) return InteractionType.Compliment;
            if (includeFlirt && roll < 0.96) return InteractionType.Flirt;
            if (includeKiss) return InteractionType.Kiss;
            if (includeSex) return InteractionType.Sex;
            return InteractionType.Conversation;
        }

        // ===== Plumbing ========================================================

        private static BondStage GuessStage(Relationship r)
        {
            float c = r.Closeness, l = r.Liking, t = r.Trust, a = r.Attraction;
            if (c >= 70 && l >= 65 && t >= 70 && a >= 60) return BondStage.Intimate;
            if (c >= 50 && l >= 55 && t >= 60) return BondStage.Friend;
            if (c >= 30 && l >= 40 && t >= 40) return BondStage.Familiar;
            return BondStage.Stranger;
        }

        private static void SeedAxesPair(RelationshipManager rm, Person a, Person b, int liking, int trust, int closeness, int attraction)
        {
            SeedAxesOneWay(rm, a, b, liking, trust, closeness, attraction);
            SeedAxesOneWay(rm, b, a, liking, trust, closeness, attraction);
        }

        private static void SeedAxesOneWay(RelationshipManager rm, Person from, Person to, int liking, int trust, int closeness, int attraction)
        {
            var rel = rm.GetRelationship(from, to);
            rel.SetLiking(liking);
            rel.SetTrust(trust);
            rel.SetCloseness(closeness);
            rel.SetAttraction(attraction);
        }

        private static void RecomputeStagesFor(RelationshipManager rm, Person a, Person b, FamilyOptions opts)
        {
            var r1 = rm.GetRelationship(a, b);
            var r2 = rm.GetRelationship(b, a);
            if (opts.StageThresholds is not null)
            {
                r1.UpdateEma(opts.StageEmaDaysForSeeding);
                r1.EvaluateStage(opts.StageThresholds, opts.StageEmaDaysForSeeding);
                r2.UpdateEma(opts.StageEmaDaysForSeeding);
                r2.EvaluateStage(opts.StageThresholds, opts.StageEmaDaysForSeeding);
            }
            else
            {
                r1.SetStage(GuessStage(r1));
                r2.SetStage(GuessStage(r2));
            }
        }

        private static void SetFamilyBond(RelationshipManager rm, Person a, Person b, bool partner = false, bool areMarried = false)
        {
            var ab = rm.GetRelationship(a, b);
            var ba = rm.GetRelationship(b, a);

            ab.SetKind(BondKind.Family);
            ba.SetKind(BondKind.Family);

            if (partner)
            {
                if (areMarried)
                {
                    if (b.Genus == GenusType.Female) { ab.SetKinship(KinshipRole.Husband); ba.SetKinship(KinshipRole.Wife); }
                    else { ab.SetKinship(KinshipRole.Wife); ba.SetKinship(KinshipRole.Husband); }
                }
                else
                {
                    ab.SetKinship(KinshipRole.Partner);
                    ba.SetKinship(KinshipRole.Partner);
                }

                ab.AddTags(BondTag.Partner);
                ba.AddTags(BondTag.Partner);

                // In current model, Romantic excludes Family as Kind. Keep it for partners.
                ab.SetKind(BondKind.Romantic);
                ba.SetKind(BondKind.Romantic);
            }
        }

        private static void TrySetCivilStatusCouple(Person a, Person b, bool married = false)
        {
            try
            {
                a.CivilStatus = b.CivilStatus = married ? CivilStatus.Married : CivilStatus.InRelationship;
                // adopt surname by convention (if supported)
                try { b.SetSurname(a.GetSurname()); } catch { /* ignore */ }
            }
            catch { /* CivilStatus not present in some builds */ }
        }

        private static void ValidateParentAge(Person father, Person mother, IReadOnlyList<Person> children)
        {
            foreach (var c in children)
            {
                if (father.Age <= c.Age)
                    throw new InvalidOperationException($"Parent age check failed: Father {father.Age} <= Child {c.Name} {c.Age}.");
                if (mother.Age <= c.Age)
                    throw new InvalidOperationException($"Parent age check failed: Mother {mother.Age} <= Child {c.Name} {c.Age}.");
            }
        }

        private static void EnsureDistinctPersons(IEnumerable<Person> persons)
        {
            var set = new HashSet<Person>(ReferenceEqualityComparer<Person>.Instance);
            foreach (var p in persons)
                if (!set.Add(p)) throw new InvalidOperationException($"Duplicate person detected in FamilyBuilder: {p.Name}.");
        }

        private static WDateTime SafeNow()
        {
            try { return WDateTime.Now; } // if your custom struct exposes Now
            catch { return new WDateTime(2000, 1, 1, 12, 0, 0); } // harmless default
        }

        private sealed class ReferenceEqualityComparer<T> : IEqualityComparer<T> where T : class
        {
            public static readonly ReferenceEqualityComparer<T> Instance = new();
            public bool Equals(T? x, T? y) => ReferenceEquals(x, y);
            public int GetHashCode(T obj) => System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(obj);
        }
    }
}
