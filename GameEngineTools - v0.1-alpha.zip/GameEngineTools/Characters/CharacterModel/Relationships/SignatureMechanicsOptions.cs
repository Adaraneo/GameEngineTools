﻿// SignatureMechanicsOptions.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    public sealed class SignatureMechanicsOptions
    {
        public float ResonanceTrustMul { get; init; } = 0.25f; // +25 %
        public float ResonanceCloseMul { get; init; } = 0.35f; // +35 %
        public float ResonanceAttractMul { get; init; } = 0.15f; // +15 %
        public float MisreadMaxP { get; init; } = 0.35f;
        public float RepairTrustPenalty { get; init; } = 0.40f; // +40 % k prahu Trust
        public float RepairAttrPenalty { get; init; } = 0.20f; // +20 % k prahu Attraction
        public float EnergyGateScale { get; init; } = 0.20f; // ±20 % efekt na score
    }
}
