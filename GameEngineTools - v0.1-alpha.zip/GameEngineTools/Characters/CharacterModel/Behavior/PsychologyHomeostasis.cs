﻿// PsychologyHomeostasis.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.World.Utils.Time;

    public static class PsychologyHomeostasis
    {
        // časová konstanta ~ hodinový relax/spánek
        private const double TauMoodHours = 10.0;
        private const double TauStressHours = 8.0;
        private const double TauConfHours = 20.0;

        public static void Tick(IHuman h, WTimeSpan dt)
        {
            double hours = Math.Max(0, dt.TotalHours);
            if (hours <= 0) return;

            var p = h.Psychology;

            p.Mood = RelaxTo(p.Mood, 0.55, hours / TauMoodHours);
            p.StressLevel = RelaxTo(p.StressLevel, 0.30, hours / TauStressHours);
            p.Confidence = RelaxTo(p.Confidence, 0.50, hours / TauConfHours);
        }

        private static double RelaxTo(double x, double baseline, double k)
        {
            k = Math.Clamp(k, 0, 1);
            return x + (baseline - x) * k;
        }
    }
}
