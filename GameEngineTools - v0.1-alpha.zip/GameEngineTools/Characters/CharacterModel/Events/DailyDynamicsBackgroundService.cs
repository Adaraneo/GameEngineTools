﻿// DailyDynamicsBackgroundService.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Events
{
    using System.Collections.Generic;
    using System.Diagnostics;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Logging;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;
    using GameEngineTools.Characters.CharacterModel.Relationships.Rules;
    using GameEngineTools.Logging;
    using GameEngineTools.World.Core.Time;
    using GameEngineTools.World.Utils.Time;

    public sealed class DailyDynamicsBackgroundService : BackgroundService
    {
        private readonly IClock clock;
        private readonly RelationshipManager rm;
        private readonly BondRulesEngine rules;

        private readonly ILogger<DailyDynamicsBackgroundService> log;

        public DailyDynamicsBackgroundService(IClock clock, RelationshipManager rm, BondRulesEngine rules, ILogger<DailyDynamicsBackgroundService> log)
        { this.clock = clock; this.rm = rm; this.rules = rules; this.log = log; }

        public override Task StartAsync(CancellationToken cancellationToken)
        {
            log.LogInformation(LogIds.DailySvcStarted, $"{nameof(DailyDynamicsBackgroundService)} starting...");
            return base.StartAsync(cancellationToken);
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            log.LogInformation(LogIds.DailySvcStarted, $"{nameof(DailyDynamicsBackgroundService)} stopping...");
            return base.StopAsync(cancellationToken);
        }

        protected override async Task ExecuteAsync(CancellationToken stop)
        {
            WDateOnly? last = null;
            
            while (!stop.IsCancellationRequested)
            {
                var now = clock.Now;

                var sw = Stopwatch.StartNew();
                try
                {
                    if (last is null || now.DateOnly > last.Value)
                    {
                        log.LogInformation(LogIds.DailyTickStart,"Daily tick for {Day} starting at {Now}.", now.Date, now);
                        ProcessDay(now.Date);
                        last = now.DateOnly;
                        log.LogInformation(LogIds.DailyTickDone, "Daily tick finnished for {Day}.", now.Date);
                    }

                    await Task.Delay(250, stop);
                }
                catch (OperationCanceledException) when (stop.IsCancellationRequested)
                {
                    // Graceful shutdown
                    break;
                }
                catch (Exception ex)
                {
                    log.LogError(LogIds.DailyTickFailed, ex, $"{nameof(DailyDynamicsBackgroundService)} unhandled exception: {ex.Message}");
                }
                finally
                {
                    sw.Stop();
                }
            }
        }

        private void ProcessDay(WDateTime dayEnd)
        {
            var rels = rm.GetAllRelationships();

            // Ghosting po 7+ dnech, logika převzatá 1:1
            foreach (var r in rels)
            {
                float gap = (float)(dayEnd - r.LastInteraction).TotalDays;
                if (gap > 7f)
                {
                    float ghost = MathF.Min(10f, 0.6f * MathF.Log(1f + (gap - 7f)));
                    r.SetTrust(r.Trust - ghost);
                    r.SetCloseness(r.Closeness - ghost * 0.7f);
                }
            }

            // Boredom po 3+ dnech (1:1)
            foreach (var r in rels)
            {
                float gapDays = (float)(dayEnd.AddDays(0) - r.LastInteraction).TotalDays;
                if (gapDays >= 3f)
                {
                    float O = (float)r.From.Personality.BigFive[BigFiveTrait.Openness];
                    float boredom = 0.004f * (gapDays - 2f) * O;
                    r.SetAttraction(r.Attraction * (1f - boredom));
                    r.SetCloseness(r.Closeness * (1f - 0.5f * boredom));
                }
            }

            // Cross-lag (1:1)
            foreach (var r in rels)
            {
                float t01 = Math.Clamp(r.Trust / r.MaxTrust, 0f, 1f);
                var (c, t) = RelationshipMath.CrossLagCouple(
                    r.Closeness, r.Trust,
                    kappaPerDay: 0.002f, deadband: 5f, trustGate01: t01, dtDays: 1f);
                r.SetCloseness(c); r.SetTrust(t);
            }

            // Hysterese + milníky + asymetrie
            rules.Apply(rels, dayEnd);
        }
    }

}
