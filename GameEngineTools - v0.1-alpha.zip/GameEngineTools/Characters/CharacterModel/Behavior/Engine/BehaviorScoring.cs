﻿// BehaviorScoring.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Engine
{
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Config;

    internal static class BehaviorScoring
    {
        private static BehaviorTuningOptions _tuning = new BehaviorTuningOptions();
        public static void SetTuning(BehaviorTuningOptions opts) => _tuning = opts ?? new BehaviorTuningOptions();

        public static double Epsilon => _tuning.EpsilonGreedy;
        public static double EffortOf(BehaviorType type)
            => EffortCost.TryGetValue(type, out var v) ? v : 0.15;

        // „Cena“ akce podle typu (neleze do Relationships)
        private static readonly Dictionary<BehaviorType, double> EffortCost = new()
        {
            // lehké signály
            [BehaviorType.FlirtLight] = 0.10,
            [BehaviorType.HonestDisclosureLight] = 0.12,
            [BehaviorType.SuggestSharedActivity] = 0.15,
            // střední
            [BehaviorType.FlirtBold] = 0.35,
            [BehaviorType.Retort] = 0.30,
            [BehaviorType.Refuse] = 0.25,
            // těžší
            [BehaviorType.Confront] = 0.55,
        };

        /// <summary>
        /// helper: rizikovost chování 0..1 (podle tvých typů)
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        private static double RiskOf(BehaviorType t) => t switch
        {
            BehaviorType.Kiss or BehaviorType.KissLight => 0.75,
            BehaviorType.InitiateIntimacySoft or BehaviorType.InitiateIntimacyBold => 0.90,
            BehaviorType.FlirtBold => 0.60,
            BehaviorType.FlirtLight => 0.35,
            BehaviorType.Confront or BehaviorType.Retort => 0.70,
            _ => 0.25
        };

        /// <summary>
        /// multiplikátor podle aktuální psychiky a rysů
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static double PsychologicalMultiplier(BehaviorContext ctx, BehaviorType type)
        {
            // očekávám, že tyhle hodnoty už v psychologii máš; drž je 0..1
            var mood = Math.Clamp(ctx.Actor.Psychology.Mood, 0 ,1);       // spíš dobrá nálada → vyšší drive
            var stress = Math.Clamp(ctx.Actor.Psychology.StressLevel, 0, 1);     // stres brzdí rizikové věci
            var extra = Math.Clamp(ctx.Actor.Personality.GetBigFiveTrait(BigFiveTrait.Extraversion), 0, 1);

            var risk = RiskOf(type);

            // váhy drž střídmé; tohle je realisticky “jemné” zabarvení
            double mult = 1.0
                          + 0.25 * (mood - 0.5)
                          + 0.20 * (extra - 0.5)
                          - 0.30 * (stress * risk);

            return Math.Clamp(mult, 0.60, 1.40);
        }

        private static double CostPenalty(in BehaviorContext ctx, BehaviorType type)
        {
            double cost = EffortCost.TryGetValue(type, out var c) ? c : 0.15;
            // vitaly, ať ti to přirozeně brzdí těžké volby
            var v = ctx.Actor.Psychology;
            double hunger = v.Hunger; // 0..1
            double thirst = v.Thirst; // 0..1
            double fatigue = ctx.Actor.Psychology.Fatigue;

            double load = 0.4 * fatigue + 0.35 * hunger + 0.25 * thirst;
            return cost * load; // 0..~0.7
        }

        private static double StatePull(in BehaviorContext ctx, BehaviorType type)
        {
            var psy = ctx.Actor.Psychology;
            // Mood (-1..+1) → map na 0..1
            double mood = 0.5 + 0.5 * psy.Mood;
            double stress = psy.StressLevel;   // 0..1
            double fatigue = psy.Fatigue;      // 0..1
            double arousal = psy.Arousal;      // 0..1

            double r = 0.0;

            // jemná preferenční logika dle stavu
            if (type == BehaviorType.FlirtLight || type == BehaviorType.FlirtBold)
                r += 0.15 * arousal - 0.08 * stress - 0.06 * fatigue;

            if (type == BehaviorType.HonestDisclosureLight)
                r += 0.10 * mood - 0.10 * fatigue - 0.06 * stress;

            if (type == BehaviorType.SuggestSharedActivity)
                r += 0.08 * mood - 0.04 * fatigue;

            if (type == BehaviorType.Retort || type == BehaviorType.Confront)
                r += 0.12 * stress + 0.05 * fatigue - 0.10 * mood;

            if (type == BehaviorType.Refuse)
                r += 0.06 * fatigue + 0.05 * stress - 0.04 * mood;

            // Přidej na konec StatePull (nebo zavolej jako poslední krok v Score)
            var tr = ctx.Actor.Personality.Traits;
            bool Has(PersonalityTrait t) => tr.Contains(t);

            double soft = 0.0;
            if (Has(PersonalityTrait.Paranoid) && ctx.Ix.Privacy < 0.5f) soft -= 0.08;
            if (Has(PersonalityTrait.Loyal) && ctx.Ix.SocialAudience > 0.3f && (type == BehaviorType.FlirtBold || type == BehaviorType.HonestDisclosureLight))
                soft -= 0.06;
            if (Has(PersonalityTrait.Lazy) && (type == BehaviorType.Confront || type == BehaviorType.SuggestSharedActivity))
                soft -= 0.05;

            return r + soft;
        }

        private static double TraitPullBigFiveAndFlags(in BehaviorContext ctx, BehaviorType type)
        {
            var p = ctx.Actor.Personality;
            var bf = p.BigFive;
            var tr = p.Traits; // HashSet<PersonalityTrait>

            bool Has(PersonalityTrait t) => tr.Contains(t);

            // --- Big Five (ponecháme mírný vliv, aby se to chovalo známě) ---
            double A = bf[BigFiveTrait.Agreeableness];
            double C = bf[BigFiveTrait.Conscientiousness];
            double E = bf[BigFiveTrait.Extraversion];
            double N = bf[BigFiveTrait.Neuroticism];
            double O = bf[BigFiveTrait.Openness];

            double z = type switch
            {
                BehaviorType.FlirtLight => 0.12 * E + 0.05 * O - 0.04 * N,
                BehaviorType.FlirtBold => 0.20 * E + 0.08 * O - 0.06 * N,
                BehaviorType.HonestDisclosureLight => 0.10 * C + 0.08 * A - 0.04 * N,
                BehaviorType.SuggestSharedActivity => 0.08 * A + 0.06 * E,
                BehaviorType.Retort => -0.12 * A + 0.06 * N,
                BehaviorType.Refuse => 0.06 * C + 0.04 * N - 0.04 * A,
                BehaviorType.Confront => -0.10 * A + 0.10 * N + 0.05 * C,
                _ => 0.0
            };

            // --- Traits (bit-flags) – malé, ale čitelné příspěvky ---
            switch (type)
            {
                case BehaviorType.FlirtLight:
                    if (Has(PersonalityTrait.Bold)) z += 0.10;
                    if (Has(PersonalityTrait.Brave)) z += 0.06;
                    if (Has(PersonalityTrait.Empathetic)) z += 0.04;
                    if (Has(PersonalityTrait.Paranoid) && ctx.Ix.Privacy < 0.5f) z -= 0.08;
                    if (Has(PersonalityTrait.Steady)) z -= 0.03;
                    break;

                case BehaviorType.FlirtBold:
                    if (Has(PersonalityTrait.Bold)) z += 0.16;
                    if (Has(PersonalityTrait.Brave)) z += 0.10;
                    if (Has(PersonalityTrait.Paranoid)) z -= 0.10;
                    if (Has(PersonalityTrait.Steady)) z -= 0.06;
                    if (Has(PersonalityTrait.Loyal) && ctx.Ix.Privacy < 0.4f) z -= 0.05; // „veřejné odvážné“ spíš ne
                    break;

                case BehaviorType.HonestDisclosureLight:
                    if (Has(PersonalityTrait.Introspective)) z += 0.12;
                    if (Has(PersonalityTrait.Kind)) z += 0.06;
                    if (Has(PersonalityTrait.Empathetic)) z += 0.06;
                    if (Has(PersonalityTrait.Paranoid) && ctx.Ix.Privacy < 0.5f) z -= 0.08;
                    if (Has(PersonalityTrait.Greedy)) z -= 0.04;
                    break;

                case BehaviorType.SuggestSharedActivity:
                    if (Has(PersonalityTrait.Loyal)) z += 0.10;
                    if (Has(PersonalityTrait.Kind)) z += 0.06;
                    if (Has(PersonalityTrait.Lazy)) z -= 0.05; // „něco dělat“ = menší chuť
                    if (Has(PersonalityTrait.Practical)) z += 0.06; // praktická spolupráce
                    break;

                case BehaviorType.Retort:
                    if (Has(PersonalityTrait.Steady)) z -= 0.08;
                    if (Has(PersonalityTrait.Kind)) z -= 0.06;
                    if (Has(PersonalityTrait.Bold)) z += 0.05;
                    if (Has(PersonalityTrait.Paranoid)) z += 0.05;
                    break;

                case BehaviorType.Confront:
                    if (Has(PersonalityTrait.Brave)) z += 0.10;
                    if (Has(PersonalityTrait.Steady)) z -= 0.10;
                    if (Has(PersonalityTrait.Kind)) z -= 0.08;
                    break;

                case BehaviorType.Refuse:
                    if (Has(PersonalityTrait.Practical)) z += 0.05; // stanoví hranici
                    if (Has(PersonalityTrait.Loyal)) z += 0.04; // „zachovat rámec“
                    if (Has(PersonalityTrait.Empathetic)) z -= 0.04;
                    break;
            }

            // --- Temperament (jemné barvení) ---
            z += p.Temperament switch
            {
                TemperamentType.Sanguine => (type is BehaviorType.FlirtLight or BehaviorType.SuggestSharedActivity) ? 0.05 : 0.00,
                TemperamentType.Choleric => (type is BehaviorType.Retort or BehaviorType.Confront) ? 0.06 : 0.00,
                TemperamentType.Phlegmatic => (type is BehaviorType.HonestDisclosureLight) ? 0.04 : 0.00,
                TemperamentType.Melancholic => (type is BehaviorType.HonestDisclosureLight) ? 0.06 : 0.00,
                _ => 0.00
            };

            // --- DecisionStyle (jak se rozhoduje) ---
            z += p.DecisionStyle switch
            {
                DecisionStyle.Impulsive => (type is BehaviorType.FlirtLight or BehaviorType.FlirtBold) ? 0.06 : -0.02,
                DecisionStyle.Intuitive => (type is BehaviorType.SuggestSharedActivity or BehaviorType.FlirtLight) ? 0.04 : 0.00,
                DecisionStyle.Analytical => (type is BehaviorType.HonestDisclosureLight) ? 0.05 : (type is BehaviorType.FlirtBold ? -0.04 : 0.00),
                DecisionStyle.Reflective => (type is BehaviorType.HonestDisclosureLight or BehaviorType.Refuse) ? 0.04 : 0.00,
                DecisionStyle.Deliberate => (type is BehaviorType.Refuse or BehaviorType.SuggestSharedActivity) ? 0.04 : 0.00,
                _ => 0.00
            };

            // zjemni dopad a omez do ±0.25
            return Math.Clamp(z, -0.25, 0.25);
        }

        private static double VarietyBonus(BehaviorMemory mem, BehaviorType type)
        {
            // Čím častěji se točilo v posledních X hodinách, tím větší malus.
            double freq = mem.RecentFrequency(type); // 0..1
            return (1.0 - freq) * 0.20; // max +0.20, když jsme to dlouho nedělali
        }

        public static double Score(in BehaviorContext ctx, IBehaviorOption option, BehaviorMemory memory)
        {
            // 1) Base utilita z Optionu
            double u_base = Bx.Clamp01(option.Utility(ctx));

            // 2) Traits (Big Five) → „přitažlivost“ typu chování
            double u_traits = TraitPullBigFiveAndFlags(ctx, option.Type);

            // 3) Psychostav (M, S, F, A) – jak se to teď dělá tělu/mozku
            double u_psycho = StatePull(ctx, option.Type);

            // 4) Morálka – alignment akce s profilem aktéra + kontext (publikum, privacy)
            double u_moral = MoralAppraisal.Evaluate(ctx, option);

            // 5) Cena akce (vyšší únava/stress/hunger → větší penalizace náročných typů)
            double u_cost = CostPenalty(ctx, option.Type);

            // 6) Pestrost (potlačit spam jedné volby v krátkém okně)
            double u_variety = VarietyBonus(memory, option.Type);

            double pref = memory.Preference(option.Type, ctx.Target?.DNA);

            // Agregace (logit/lineárně; drž to v rozumném rozsahu)
            double u =
                _tuning.W_Base * u_base +
                _tuning.W_Traits * u_traits +
                _tuning.W_Psycho * u_psycho +
                _tuning.W_Moral * u_moral +
                _tuning.W_Variety * u_variety -
                _tuning.W_Cost * u_cost;

            // Uprava náročnosti dle stavu postavy (fatigue/stress/energy)
            {
                var psy = ctx.Actor.Psychology;
                double energy = 1.0 - psy.Fatigue;
                double stress = psy.StressLevel;
                double budget = Math.Clamp(0.7 * energy + 0.3 * (1.0 - stress), 0.0, 1.0);
                double effort = EffortCost.TryGetValue(option.Type, out var c) ? c : 0.15;

                // navýšení u_cost o 0..0.2 dle (effort - budget)
                u_cost += Math.Max(0.0, effort - budget) * 0.20;
            }

            u += _tuning.W_Pref * pref;

            // jemný šum (aby nerozhodovala jen 3. cifra)
            u += memory.SmallNoise();

            u *= PsychologicalMultiplier(ctx, option.Type);
            return Bx.Clamp01(u);
        }
    }
}
