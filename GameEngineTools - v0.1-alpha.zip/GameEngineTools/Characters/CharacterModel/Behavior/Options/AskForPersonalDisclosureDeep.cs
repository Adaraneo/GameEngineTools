﻿// AskForPersonalDisclosureDeep.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using GameEngineTools.Characters.CharacterModel.Relationships;

    public sealed class AskForPersonalDisclosureDeep : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.AskForPersonalDisclosureDeep;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = Relationships.InteractionType.Talk,
                When = ctx.When,
                IsMicro = false,
                Context = ctx.Ix
                    .WithDepth(Math.Max(ctx.Ix.Depth, 0.65f))
                    .WithSincerity(Math.Max(ctx.Ix.Sincerity, 0.65f))
                    .WithPrivacy(Math.Max(ctx.Ix.Privacy, 0.55f))
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
            => ctx.Target is not null
               && (ctx.Rel?.Trust ?? 0f) >= 30f
               && ctx.Ix.Privacy >= 0.55f;

        public float Utility(in BehaviorContext ctx)
        {
            var A = (float)ctx.Actor.Personality.BigFive[Homo.BigFiveTrait.Agreeableness];
            var C = (float)ctx.Actor.Personality.BigFive[Homo.BigFiveTrait.Conscientiousness];
            var mood01 = 0.5f + 0.5f * ctx.Actor.Psychology.Mood;
            var trust01 = (ctx.Rel?.Trust ?? 0f) / 100f;

            var u = 0.06f + 0.25f * trust01 + 0.15f * mood01 + 0.10f * A + 0.06f * C
                    - 0.18f * (1f - ctx.Ix.Privacy);

            return Bx.Clamp01(u);
        }
    }
}

