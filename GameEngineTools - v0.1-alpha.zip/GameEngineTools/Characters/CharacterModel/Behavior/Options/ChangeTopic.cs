﻿// ChangeTopic.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// Jemné přehození tématu, když je tón/hloubka nepohodlná.
    public sealed class ChangeTopic : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.SuggestSharedActivity;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.SpendTime,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    Privacy = ctx.Ix.Privacy,
                    Risk = Math.Max(0f, ctx.Ix.Risk - 0.05f),
                    SharedGoal = ctx.Ix.SharedGoal,
                    SocialAudience = ctx.Ix.SocialAudience,
                    Continuity = Math.Clamp(ctx.Ix.Continuity + 0.05f, 0f, 1f),
                    Depth = Math.Clamp(ctx.Ix.Depth - 0.15f, 0f, 1f),
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.10f, -1f, 1f),
                    Warmth = Math.Clamp(ctx.Ix.Warmth + 0.05f, 0f, 1f)
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && (ctx.Ix.Depth > 0.5f || ctx.Ix.EmotionalTone < 0f);

        public float Utility(in BehaviorContext ctx)
        {
            double u = 0.15 + 0.25 * (ctx.NormPressure01) + 0.20 * (1 - ctx.Ix.Privacy)
                       + 0.20 * (0.5 - 0.5 * ctx.Ix.EmotionalTone);
            return Bx.Clamp01(u);
        }
    }
}
