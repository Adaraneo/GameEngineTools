﻿// RelationshipSnapshotAdapter.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Adapters
{
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// Převod z tvého runtime modelu vztahů na read-only snapshot.
    public sealed class RelationshipSnapshotAdapter : IRelationshipSnapshotProvider
    {
        private readonly RelationshipManager _rm;

        public RelationshipSnapshotAdapter(RelationshipManager rels)
        {
            _rm = rels;
        }

        public RelationshipSnapshotForBehavior? TryGet(IHuman a, IHuman b)
        {
            if (_rm.TryGetRelationship(a, b, out var rel))
            {
                return new RelationshipSnapshotForBehavior(
                    liking: rel.Liking,
                    trust: rel.Trust,
                    closeness: rel.Closeness,
                    attraction: rel.Attraction,
                    stage: rel.Stage,
                    tags: rel.Tags,
                    conflict: rel.Repair?.Debt > 0.25f
                );
            }
            else
            {
                return null;
            }
        }
    }
}
