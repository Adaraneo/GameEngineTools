﻿// ICharacterManager.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools
{
    using System.Collections.Generic;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;
    using GameEngineTools.Characters.GameObjects;

    public interface IGameEngineToolsManager
    {
        List<NPPC> NPPCs { get; }

        //IServiceProvider ServiceProvider { get; }
        RelationshipManager RelationshipManager { get; }

        //IEventBus EventBus { get; }
        void Initialize();

        Person RandomizePerson(in double minAge = 0, in double maxAge = 100, GenusType? genus = null, in double? heightCm = null, in double? weightKg = null, bool useArchetypeAndMagicMeging = false);

        //IClock Clock { get; }
    }
}
