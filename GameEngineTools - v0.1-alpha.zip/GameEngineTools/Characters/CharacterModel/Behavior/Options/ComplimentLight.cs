﻿// ComplimentLight.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    public sealed class ComplimentLight : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.ComplimentLight;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Compliment,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.30f, -1f, 1f),
                    Privacy = ctx.Ix.Privacy,
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.10f, 0f, 1f),
                    SocialAudience = ctx.Ix.SocialAudience,
                    Continuity = ctx.Ix.Continuity,
                    SharedGoal = ctx.Ix.SharedGoal,
                    Risk = ctx.Ix.Risk,
                    Physicality = Math.Clamp(ctx.Ix.Physicality + 0.05f, 0f, 1f)
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx) => ctx.Target is not null && ctx.Rel.HasValue;

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality;
            var psy = ctx.Actor.Psychology;
            var (O, C, E, A, N) = Bx.ReadBigFive(per);

            // Preferuje se, když je nálada ok, extraverze/agreab. vyšší, a vztah není v konfliktu
            var rel = ctx.Rel!.Value;
            double okRel = rel.HasActiveConflict ? -0.20 : +0.10;

            double u = 0.10 + 0.25 * E + 0.25 * A + 0.15 * (0.5 + 0.5 * psy.Mood) + 0.15 * (rel.Liking / 100.0)
                       - 0.15 * psy.StressLevel - 0.10 * psy.Fatigue + okRel - 0.10 * ctx.NormPressure01
                       + 0.08 * ctx.Goals.AffiliationNeed01;

            return Bx.Clamp01(u);
        }
    }
}
