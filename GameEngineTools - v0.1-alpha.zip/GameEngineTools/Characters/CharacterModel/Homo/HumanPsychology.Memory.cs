﻿// HumanPsychology.Memory.cs
// Copyright (c) 50PSoftware
// Episodická paměť a biasy

namespace GameEngineTools.Characters.Homo
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using GameEngineTools.Characters.CharacterModel.Behavior.Engine;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.World.Utils.Time;

    public record EpisodicMemoryItem(double Valence, double Salience, WDateTime When, Guid ActorId);

    public partial class HumanPsychology
    {
        private readonly List<EpisodicMemoryItem> memory = new();

        public BehaviorMemory ShortMemory { get; set; }

        /// <summary>Vrátí průměrnou valenci vzpomínek na aktéra v časovém okně.</summary>
        public double RecallValence(Guid actorDNA, WTimeSpan window, Personality? p = null)
        {
            var cutoff = WDateTime.Now - window;
            var relevant = memory.Where(m => m.ActorId == actorDNA && m.When >= cutoff).ToList();
            if (relevant.Count == 0) return 0;

            double avg = relevant.Average(m => m.Valence);
            // bias podle neuroticismu: vyšší → posouvá k negativnímu
            if (p != null)
            {
                var snap = ReadPersonality(p);
                avg -= 0.2 * (snap.Neuroticism - 0.5);
            }
            return Math.Clamp(avg, -1, 1);
        }

        /// <summary>Ulož vzpomínku (valence −1..+1, salience 0..1).</summary>
        public void Remember(double valence, double salience, Guid actorDNA)
        {
            memory.Add(new EpisodicMemoryItem(valence, salience, WDateTime.Now, actorDNA));
            if (memory.Count > 2000) memory.RemoveAt(0); // jednoduchý limit
        }
    }
}
