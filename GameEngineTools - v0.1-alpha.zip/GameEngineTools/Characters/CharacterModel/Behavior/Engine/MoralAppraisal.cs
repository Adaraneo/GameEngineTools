﻿// MoralAppraisal.cs
// Copyright (c) 50PSoftware

using GameEngineTools.Characters.CharacterModel.Homo;

namespace GameEngineTools.Characters.CharacterModel.Behavior.Engine
{
    internal static class MoralAppraisal
    {
        private static double Clamp01(double v) => Math.Clamp(v, 0.0, 1.0);

        private static double Lerp(double a, double b, double t) => a + (b - a) * Math.Clamp(t, 0.0, 1.0);

        public static double Evaluate(in BehaviorContext ctx, IBehaviorOption option)
        {
            var p = ctx.Actor.Personality;
            var mp = p.Morality; // MoralProfile (0..1 per dimenze)
            bool Has(PersonalityTrait t) => p.Traits.Contains(t);

            // Vytáhni dimenze a uprav je podle traits (jemně ±0.10)
            double care = Clamp01(mp[MoralDimension.Care] + (Has(PersonalityTrait.Empathetic) ? 0.10 : 0.0) + (Has(PersonalityTrait.Kind) ? 0.06 : 0.0));
            double fairness = Clamp01(mp[MoralDimension.Fairness] - (Has(PersonalityTrait.Greedy) ? 0.08 : 0.0) + (Has(PersonalityTrait.Practical) ? 0.04 : 0.0));
            double loyalty = Clamp01(mp[MoralDimension.Loyalty] + (Has(PersonalityTrait.Loyal) ? 0.12 : 0.0));
            double honesty = Clamp01(mp[MoralDimension.Honesty] + (Has(PersonalityTrait.Introspective) ? 0.08 : 0.0));
            double sanctity = Clamp01(mp[MoralDimension.Sanctity] + (Has(PersonalityTrait.Aesthetic) ? 0.06 : 0.0));
            double liberty = Clamp01(mp[MoralDimension.Liberty]); // teď bez trait posunu
            double authority = Clamp01(mp[MoralDimension.Authority]);

            double privacy = ctx.Ix.Privacy;
            double audience = ctx.Ix.SocialAudience;

            double s = 0.5; // default

            switch (option.Type)
            {
                case BehaviorType.HonestDisclosureLight:
                    s = 0.55 + 0.35 * honesty + 0.10 * fairness;
                    // v nízké privacy méně vhodné
                    s *= Lerp(0.85, 1.05, privacy);
                    break;

                case BehaviorType.FlirtLight:
                case BehaviorType.FlirtBold:
                    s = 0.50 + 0.25 * care + 0.25 * loyalty + 0.10 * sanctity;
                    s *= Lerp(1.05, 0.90, audience); // veřejnost sráží
                    s *= Lerp(0.90, 1.08, privacy);  // soukromí pomáhá
                    break;

                case BehaviorType.SuggestSharedActivity:
                    s = 0.55 + 0.20 * care + 0.15 * fairness + 0.10 * loyalty + 0.05 * authority;
                    break;

                case BehaviorType.Refuse:
                    s = 0.50 + 0.20 * fairness + 0.15 * authority + 0.10 * loyalty;
                    s *= Lerp(1.00, 0.90, audience); // odmítnutí na očích = spíš hůř
                    break;

                case BehaviorType.Retort:
                case BehaviorType.Confront:
                    // agresi brzdí care/fairness; když je vysoká autorita/loajalita, může být lépe obhájené „vynucení hranic“
                    double brake = 0.5 * care + 0.5 * fairness; // 0..1
                    s = 0.55 - 0.35 * brake + 0.10 * authority + 0.05 * loyalty;
                    s *= Lerp(1.00, 0.85, audience);
                    break;

                default:
                    s = 0.50;
                    break;
            }

            // mapuj 0.2..1.1 -> 0..1 + clamp
            return Math.Clamp((s - 0.2) / 0.9, 0.0, 1.0);
        }
    }
}
