﻿// LieWhite.cs
// Copyright (c) 50PSoftware
namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// Malá účelová lež – jemně negativní dopad (spíš na důvěru).
    public sealed class LieWhite : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.Lie;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Lie,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone - 0.10f, -1f, 1f),
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.10f, 0f, 1f),
                    Depth = Math.Max(0f, ctx.Ix.Depth - 0.05f),
                    Warmth = Math.Max(0f, ctx.Ix.Warmth - 0.05f),
                    Privacy = ctx.Ix.Privacy,
                    SocialAudience = ctx.Ix.SocialAudience,
                    SharedGoal = ctx.Ix.SharedGoal,
                    Continuity = ctx.Ix.Continuity
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && ctx.Ix.Risk < 0.6f;

        public float Utility(in BehaviorContext ctx)
        {
            var p = ctx.Actor.Psychology;
            double u = 0.05 + 0.25 * p.StressLevel + 0.20 * (1 - ctx.Ix.Privacy)
                       - 0.15 * (ctx.Rel?.Trust ?? 50f) / 100.0;
            return Bx.Clamp01(u);
        }
    }
}
