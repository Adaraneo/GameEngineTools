﻿// IPeopleProvider.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.GameObjects
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Immutable;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using GameEngineTools.Characters.CharacterModel.Homo;

    public interface IPeopleProvider
    {
        ImmutableArray<IHuman> GetAll();
    }
}
