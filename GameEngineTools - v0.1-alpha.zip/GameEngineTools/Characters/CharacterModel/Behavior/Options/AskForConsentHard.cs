﻿// AskForConsentHard.cs
// Copyright (c) 50PSoftware

using GameEngineTools.Characters.CharacterModel.Homo;
using GameEngineTools.Characters.CharacterModel.Relationships;

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    /// Explicitní „můžu?“ i v méně ideálních podmínkách.
    /// Je to pořád Honesty (etiketa), ale s vyšším vnímaným rizikem a menším ziskem.
    public sealed class AskForConsentHard : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.AskForConsent;

        public void Apply(in BehaviorContext ctx)
        {
            // Mikrokrok: menší posuny než „soft“ verze, ale víc zranitelnosti (↑Risk)
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Honesty,
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    Privacy = Math.Max(ctx.Ix.Privacy, 0.45f),
                    SocialAudience = Math.Min(ctx.Ix.SocialAudience, 0.20f),
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.08f, 0f, 1f),
                    Warmth = Math.Clamp(ctx.Ix.Warmth + 0.06f, 0f, 1f),
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.06f, -1f, 1f),
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.10f, 0f, 1f), // víc zranitelnosti
                    SharedGoal = Math.Clamp(ctx.Ix.SharedGoal + 0.08f, 0f, 1f),
                    Continuity = Math.Clamp(ctx.Ix.Continuity + 0.08f, 0f, 1f),
                    Physicality = ctx.Ix.Physicality,
                    Surprise = ctx.Ix.Surprise
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
        {
            if (ctx.Target is null || !ctx.Rel.HasValue) return false;
            var r = ctx.Rel.Value;

            // „Těžší“ verze: dovolíme horší stav, ale stále bezpečné minimum
            bool stageOk = r.Stage >= BondStage.Intimate || (r.Stage >= BondStage.Friend && r.Closeness >= 60f);
            bool trustOk = r.Trust >= 45f;                // nižší než u soft verze
            bool privacyOk = ctx.Ix.Privacy >= 0.35f && ctx.Ix.SocialAudience <= 0.25f;
            bool toneOk = ctx.Ix.EmotionalTone >= -0.35f;
            bool readiness = (ctx.Ix.Depth >= 0.20f || ctx.Ix.Physicality >= 0.20f);

            return stageOk && trustOk && privacyOk && toneOk && readiness;
        }

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality;
            var psy = ctx.Actor.Psychology;
            var r = ctx.Rel!.Value;

            double A = per.BigFive[BigFiveTrait.Agreeableness];
            double C = per.BigFive[BigFiveTrait.Conscientiousness];

            // V těžších podmínkách motivuje i „opravný“ impuls (negativní tón zvedá potřebu vyjasnit)
            double u =
                0.10
              + 0.20 * A
              + 0.15 * C
              + 0.15 * (r.Trust / 100.0)
              + 0.10 * ctx.Ix.Privacy
              + 0.08 * (0.5 + 0.5 * psy.Mood)
              + 0.08 * Math.Max(0.0, -ctx.Ix.EmotionalTone)    // čím horší nálada, tím víc dává smysl zeptat se jasně
              - 0.12 * psy.StressLevel
              - 0.06 * ctx.Ix.SocialAudience;

            return Bx.Clamp01(u);
        }
    }
}
