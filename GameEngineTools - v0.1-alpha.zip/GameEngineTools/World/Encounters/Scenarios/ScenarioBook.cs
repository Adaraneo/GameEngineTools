﻿// ScenarioBook.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.World.Encounters.Scenarios
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using GameEngineTools.Characters.CharacterModel.Behavior;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.World.Encounters;
    using GameEngineTools.World.Utils.Time;

    public sealed class ScenarioBook
    {
        private readonly PlaceRegistry _places;
        private readonly Dictionary<WDateOnly, ScenarioPlan> _plans = new();
        private readonly IRelationshipSnapshotProvider _shipSnapshotProvider;

        public ScenarioBook(PlaceRegistry places, IRelationshipSnapshotProvider relationshipSnapshotProvider)
        {
            _places = places;
            _shipSnapshotProvider = relationshipSnapshotProvider;
        }

        public IEnumerable<PresenceSegment> GetExtraPresence(WDateTime dayStart, WDateTime dayEnd)
        {
            var key = WDateOnly.FromDateTime(dayStart);
            return _plans.TryGetValue(key, out var plan)
                ? plan.ExtraPresence.Where(p => p.Overlaps(dayStart, dayEnd))
                : Enumerable.Empty<PresenceSegment>();
        }

        public IEnumerable<Encounter> GetForcedEncountersForDay(WDateTime dayStart)
        {
            var key = WDateOnly.FromDateTime(dayStart);
            return _plans.TryGetValue(key, out var plan)
                ? plan.ForcedEncounters
                : Enumerable.Empty<Encounter>();
        }

        public ScenarioPlan Plan(WDateOnly day)
        {
            if (!_plans.TryGetValue(day, out var plan))
            {
                plan = new ScenarioPlan(day, _places, _shipSnapshotProvider);
                _plans[day] = plan;
            }
            return plan;
        }
    }

    public sealed class ScenarioPlan
    {
        private readonly PlaceRegistry _places;
        private readonly IRelationshipSnapshotProvider _relationshipSnapshotProvider;
        private readonly Random _rng = Random.Shared;

        private WDateTime RandomBetween(WDateTime a, WDateTime b)
        {
            var span = b - a; var r = _rng.NextDouble();
            return a + WTimeSpan.FromSeconds(span.TotalSeconds * r);
        }

        // --- helpers ---
        private IEnumerable<(IHuman A, IHuman B)> SamplePairs(List<IHuman> ppl, int take)
        {
            var pairs = new List<(IHuman, IHuman)>();
            for (int i = 0; i < ppl.Count; i++)
                for (int j = i + 1; j < ppl.Count; j++)
                    pairs.Add((ppl[i], ppl[j]));
            // shuffle
            for (int i = pairs.Count - 1; i > 0; i--)
            {
                int k = _rng.Next(i + 1);
                (pairs[i], pairs[k]) = (pairs[k], pairs[i]);
            }
            return pairs.Take(take);
        }

        internal ScenarioPlan(WDateOnly day, PlaceRegistry places, IRelationshipSnapshotProvider relationshipSnapshotProvider)
        {
            Day = day; _places = places;
            _relationshipSnapshotProvider = relationshipSnapshotProvider;
        }

        public readonly List<PresenceSegment> ExtraPresence = new();
        public readonly List<Encounter> ForcedEncounters = new();
        public WDateOnly Day { get; }

        /// <summary>
        /// Přidej rovnou vynucený Encounter (když chceš jistou interakci)
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="place"></param>
        /// <param name="when"></param>
        /// <param name="situation"></param>
        /// <param name="occupantCountHint"></param>
        /// <param name="privacyOverride"></param>
        /// <param name="depthOverride"></param>
        /// <returns></returns>
        public ScenarioPlan AddForcedEncounter(IHuman a, IHuman b, Place place, WDateTime when,
                                               SituationType? situation = null, int occupantCountHint = 2,
                                               float? privacyOverride = null, float? depthOverride = null)
        {
            var prof = EncounterProfiles.Profiles[place.Archetype];
            var ix = EncounterProfiles.BuildIx(prof, occupantCountHint, Math.Max(2, place.CapacityHint));
            if (privacyOverride is not null) ix.Privacy = privacyOverride.Value;
            if (depthOverride is not null) ix.Depth = depthOverride.Value;

            var sit = situation ?? EncounterProfiles.ClassifySituation(
                prof, occupantCountHint, isTransit: place.IsTransit, (_relationshipSnapshotProvider.TryGet(a, b).GetValueOrDefault(), _relationshipSnapshotProvider.TryGet(b, a).GetValueOrDefault()));

            ForcedEncounters.Add(new Encounter { A = a, B = b, When = when, Ix = ix, Situation = sit, Source = EncounterSource.Forced, PlaceId = place.Id });
            return this;
        }

        public ScenarioPlan AddForcedEncounter(
            IHuman a, IHuman b, Place place, WDateTime when,
            SituationType? situation = null, int occupantCountHint = 2,
            float? privacyOverride = null, float? depthOverride = null,
            string? tag = null)
        {
            var prof = EncounterProfiles.Profiles[place.Archetype];
            var ix = EncounterProfiles.BuildIx(prof, occupantCountHint, Math.Max(2, place.CapacityHint));
            if (privacyOverride is not null) ix.Privacy = privacyOverride.Value;
            if (depthOverride is not null) ix.Depth = depthOverride.Value;

            var sit = situation ?? EncounterProfiles.ClassifySituation(prof,
                occupantCountHint,
                isTransit: place.IsTransit,
                (_relationshipSnapshotProvider.TryGet(a, b).GetValueOrDefault(), _relationshipSnapshotProvider.TryGet(b, a).GetValueOrDefault()));

            ForcedEncounters.Add(new Encounter
            {
                A = a,
                B = b,
                When = when,
                Ix = ix,
                Situation = sit,
                Source = EncounterSource.Forced,
                PlaceId = place.Id,
                Tag = tag
            });
            return this;
        }

        public ScenarioPlan AddGroupPresence(IEnumerable<IHuman> people, Place place, WDateTime startUtc, WDateTime endUtc)
        {
            foreach (var h in people) AddPresence(h, place, startUtc, endUtc);
            return this;
        }

        public ScenarioPlan AddPresence(IHuman human, Place place, WDateTime startUtc, WDateTime endUtc)
        {
            ExtraPresence.Add(new PresenceSegment(human, place.Id, startUtc, endUtc, place.CapacityHint));
            return this;
        }
    }
}
