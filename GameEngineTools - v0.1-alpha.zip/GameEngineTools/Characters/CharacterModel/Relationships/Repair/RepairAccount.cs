﻿// RepairAccount.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships.Repair
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public sealed class RepairAccount
    {
        /// 0..1 – kolik „dluhu“ je aktuálně neopraveno.
        public float Debt { get; private set; }
        public void AddRupture(float severity)
        => Debt = Math.Clamp(Debt + Math.Clamp(severity, 0f, 1f), 0f, 1f);
        public void ApplyRepair(float sincerity01, float effort01)
        {
            var pay = MathF.Pow(Math.Clamp(sincerity01 * effort01, 0f, 1f), 0.9f) * (0.5f + 0.5f * Debt);
            Debt = Math.Clamp(Debt - pay, 0f, 1f);
        }
    }
}
