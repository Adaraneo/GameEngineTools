﻿// UndermineInPublic.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// Ponížení partnera před publikem (tvrdší než InsultDirect).
    public sealed class UndermineInPublic : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.UndermineInPublic;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Insult,
                When = ctx.When,
                IsMicro = false,
                Context = new InteractionContext
                {
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone - 0.45f, -1f, 1f),
                    Warmth = Math.Max(0f, ctx.Ix.Warmth - 0.35f),
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.25f, 0f, 1f),
                    Privacy = Math.Min(ctx.Ix.Privacy, 0.35f),
                    SocialAudience = Math.Max(ctx.Ix.SocialAudience, 0.60f),
                    Depth = Math.Max(0f, ctx.Ix.Depth - 0.10f),
                    SharedGoal = Math.Max(0f, ctx.Ix.SharedGoal - 0.15f),
                    Continuity = ctx.Ix.Continuity
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && ctx.Ix.SocialAudience > 0.25f;

        public float Utility(in BehaviorContext ctx)
        {
            double u = 0.05 + 0.30 * (1 - ctx.Ix.Privacy) + 0.25 * ctx.Ix.SocialAudience
                       + 0.20 * (ctx.Ix.Risk);
            return Bx.Clamp01(u);
        }
    }
}
