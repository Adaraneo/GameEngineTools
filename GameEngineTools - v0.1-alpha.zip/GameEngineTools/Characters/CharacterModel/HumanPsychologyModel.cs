﻿// HumanPsychologyModel.cs
// Copyright (c) 50PSoftware
// DTO + mapování pro JSON serializaci/deserializaci HumanPsychology.

namespace GameEngineTools.Characters.Homo
{
    using System.Text.Json;
    using System.Text.Json.Serialization;
    using GameEngineTools.Characters.CharacterModel;

    public partial class HumanPsychology
    {
        // V Memory partialu je 'memory' privátní; připravíme bezpečné snapshot/replace.
        private IReadOnlyList<EpisodicMemoryItem> GetMemorySnapshot()
            => memory.AsReadOnly();

        // -------------------- Interní mosty na privátní seznamy --------------------
        private void ReplaceMemory(List<EpisodicMemoryItemModel>? items)
        {
            memory.Clear();
            if (items == null) return;
            foreach (var it in items)
            {
                memory.Add(new EpisodicMemoryItem(
                    Math.Clamp(it.Valence, -1, 1),
                    Math.Clamp(it.Salience, 0, 1),
                    it.When,
                    it.ActorId
                ));
            }
            if (memory.Count > 2000)
            {
                int excess = memory.Count - 2000;
                memory.RemoveRange(0, excess);
            }
        }

        /// <summary>Default JSON options – enumy jako stringy, hezké odsazení.</summary>
        public static JsonSerializerOptions JsonOptions { get; } = new JsonSerializerOptions
        {
            WriteIndented = true,
            Converters = { new JsonStringEnumConverter() }
        };

        /// <summary>Aplikuj hodnoty z modelu do instance psychologie.</summary>
        public void ApplyModel(HumanPsychologyModel m)
        {
            if (m == null) return;

            // Config (nejdřív, kvůli bránám)
            if (m.Config != null)
                this.ApplyConfig(m.Config);

            // Hlavní stavy
            StressLevel = Clamp01(m.StressLevel);
            Motivation = Clamp01(m.Motivation);
            Focus = Clamp01(m.Focus);
            Fatigue = Clamp01(m.Fatigue);

            Mood = Clamp11(m.Mood);
            Arousal = Clamp01(m.Arousal);
            Anxiety = Clamp01(m.Anxiety);
            Confidence = Clamp01(m.Confidence);
            SelfControl = Clamp01(m.SelfControl);
            Resilience = Clamp01(m.Resilience);

            SleepDebtHours = Math.Max(0, m.SleepDebtHours);
            Hunger = Clamp01(m.Hunger);
            Thirst = Clamp01(m.Thirst);
            Pain = Clamp01(m.Pain);

            SocialDrive = Clamp01(m.SocialDrive);
            Curiosity = Clamp01(m.Curiosity);
            Aggression = Clamp01(m.Aggression);

            InteroceptionSensitivity = Clamp01(m.InteroceptionSensitivity);

            CopingPreference = m.CopingPreference;

            // Hysterézové brány – re-init s aktuálními prahy z Configu
            highStressGate = new HysteresisGate(Config.HighStressOn, Config.HighStressOff, m.HighStressGateState);
            highFatigueGate = new HysteresisGate(Config.HighFatigueOn, Config.HighFatigueOff, m.HighFatigueGateState);

            // Emocionální epizody – nahradíme
            activeEmotions.Clear();
            if (m.ActiveEmotions != null)
            {
                foreach (var e in m.ActiveEmotions)
                {
                    activeEmotions.Add(new EmotionEpisode(
                        e.Type,
                        Math.Clamp(e.Intensity, 0, 1),
                        Math.Max(0.01, e.HalfLifeHours),
                        e.Source
                    ));
                }
            }

            // Paměť – nahradíme
            ReplaceMemory(m.Memory);
        }

        /// <summary>Export aktuálního psychologického stavu do serializovatelného modelu.</summary>
        public HumanPsychologyModel ToModel(bool includeConfig = false)
        {
            var m = new HumanPsychologyModel
            {
                StressLevel = this.StressLevel,
                Motivation = this.Motivation,
                Focus = this.Focus,
                Fatigue = this.Fatigue,

                Mood = this.Mood,
                Arousal = this.Arousal,
                Anxiety = this.Anxiety,
                Confidence = this.Confidence,
                SelfControl = this.SelfControl,
                Resilience = this.Resilience,

                SleepDebtHours = this.SleepDebtHours,
                Hunger = this.Hunger,
                Thirst = this.Thirst,
                Pain = this.Pain,

                SocialDrive = this.SocialDrive,
                Curiosity = this.Curiosity,
                Aggression = this.Aggression,

                InteroceptionSensitivity = this.InteroceptionSensitivity,

                CopingPreference = this.CopingPreference,
                HighStressGateState = this.IsHighStress,
                HighFatigueGateState = this.IsHighFatigue
            };

            if (includeConfig)
                m.Config = this.Config;

            // Aktivní emoce
            foreach (var e in ActiveEmotions)
            {
                m.ActiveEmotions.Add(new EmotionEpisodeModel
                {
                    Type = e.Type,
                    Intensity = e.Intensity,
                    HalfLifeHours = e.HalfLifeHours,
                    Source = e.Source
                });
            }

            // Episodická paměť (interní seznam 'memory')
            // (V jiném partialu: HumanPsychology.Memory.cs)
            foreach (var item in GetMemorySnapshot())
            {
                m.Memory.Add(new EpisodicMemoryItemModel
                {
                    Valence = item.Valence,
                    Salience = item.Salience,
                    When = item.When,
                    ActorId = item.ActorId
                });
            }

            return m;
        }

        #region json helpers

        //public string ToJson(bool includeConfig = false, JsonSerializerOptions? options = null)
        //    => JsonSerializer.Serialize(ToModel(includeConfig), options ?? JsonOptions);

        //public static HumanPsychologyModel FromJson(string json, JsonSerializerOptions? options = null)
        //    => JsonSerializer.Deserialize<HumanPsychologyModel>(json, options ?? JsonOptions)!;

        //public void ApplyModelJson(string json, JsonSerializerOptions? options = null)
        //    => ApplyModel(FromJson(json, options));

        #endregion json helpers
    }
}

namespace GameEngineTools.Characters.CharacterModel
{
    using System;
    using System.Collections.Generic;
    using GameEngineTools.Characters.Homo;
    using GameEngineTools.Config;
    using GameEngineTools.World.Utils.Time;

    // -------------------- DTOs (serializovatelný stav) --------------------

    public sealed class EmotionEpisodeModel
    {
        public double HalfLifeHours { get; set; }
        public double Intensity { get; set; }
        public Guid Source { get; set; }
        public EmotionType Type { get; set; }
    }

    public sealed class EpisodicMemoryItemModel
    {
        public Guid ActorId { get; set; }
        public double Salience { get; set; }
        public double Valence { get; set; }
        public WDateTime When { get; set; }
    }

    public sealed class HumanPsychologyModel
    {
        // Aktivní emoční epizody a episodická paměť
        public List<EmotionEpisodeModel> ActiveEmotions { get; set; } = new();

        public double Aggression { get; set; }

        public double Anxiety { get; set; }

        public double Arousal { get; set; }

        // 0..1
        public double Confidence { get; set; }

        // Volitelné: snapshot configu (umožní full round-trip bez separátního configu)
        public PsychophysConfig? Config { get; set; }

        // Coping
        public CopingStyle CopingPreference { get; set; }

        public double Curiosity { get; set; }

        public double Fatigue { get; set; }

        public double Focus { get; set; }

        public bool HighFatigueGateState { get; set; }

        // Hysterézové stavy (pouze boolean – prahy si bere z Configu)
        public bool HighStressGateState { get; set; }

        public double Hunger { get; set; }

        public double InteroceptionSensitivity { get; set; }

        // 0..1
        public List<EpisodicMemoryItemModel> Memory { get; set; } = new();

        public double Mood { get; set; }

        public double Motivation { get; set; }

        public double Pain { get; set; }

        public double Resilience { get; set; }

        // −1..+1
        public double SelfControl { get; set; }

        public double SleepDebtHours { get; set; }

        public double SocialDrive { get; set; }

        // Hlavní stavy
        public double StressLevel { get; set; }

        public double Thirst { get; set; }
    }
}
