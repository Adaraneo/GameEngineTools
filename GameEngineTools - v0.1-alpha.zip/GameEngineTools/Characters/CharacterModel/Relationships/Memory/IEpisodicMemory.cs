﻿// IEpisodicMemory.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships.Memory
{
    public interface IEpisodicMemory
    {
        void Add(Episode e);
        /// 0..1 – jak moc nová interakce „ladí“ s pamětí.
        float ResonanceScore(ThemeTag[] tags, float valence, float intimacy);
    }
}
