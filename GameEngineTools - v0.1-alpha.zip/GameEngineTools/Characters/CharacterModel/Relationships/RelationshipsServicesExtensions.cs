﻿// RelationshipsServicesExtensions.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships
{
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Options;
    using GameEngineTools.Characters.CharacterModel.Events;
    using GameEngineTools.Characters.CharacterModel.Relationships.Decay;
    using GameEngineTools.Characters.CharacterModel.Relationships.Rules;
    using GameEngineTools.World.Utils.Time;
    using GameEngineTools.Config;
    using Microsoft.Extensions.Configuration;

    /// <summary>
    /// DI rozšíření pro Relationships modul.
    /// Počítá s tím, že jinde už registruješ IEventBus, IClock a IHumanResolver.
    /// </summary>
    public static class RelationshipsServicesExtensions
    {
        public static IServiceCollection AddBondRules(this IServiceCollection services, IConfiguration cfg)
        {
            services.AddOptions<BondRulesOptions>()
                .Bind(cfg.GetSection("BondRulesOptions"))
                .ValidateOnStart();

            services.AddSingleton<BondRulesEngine>();
            return services;
        }

        private static IServiceCollection AddRelationshipsDecayLoop(
                    this IServiceCollection services,
                    Action<RelationshipsDecayOptions>? configure = null)
        {
            if (configure is not null)
                services.Configure(configure);
            else
                services.Configure<RelationshipsDecayOptions>(_ => { });

            services.AddHostedService<RelationshipsDecayBackgroundService>();
            return services;
        }

        private static IServiceCollection AddRelationshipsEventBridge(this IServiceCollection services)
        {
            services.AddSingleton<RelationshipsEventSubscriber>();
            return services;
        }

        private static IServiceCollection AddWorldKnowledge(this IServiceCollection services)
        {
            services.AddSingleton<GameEngineTools.World.Knowledge.IKnowledgeLedger, GameEngineTools.World.Knowledge.InMemoryKnowledge>();
            services.AddSingleton<GameEngineTools.World.Knowledge.Subscribers.ObservationsFromInteractionsSubscriber>();
            return services;
        }

        public static IServiceCollection AddRelationships(this IServiceCollection services, IConfiguration cfg)
        {
            return services
                .AddSingleton<RelationshipManager>()
                .AddRelationshipsDecayLoop()
                .AddRelationshipsEventBridge()
                .AddSingleton<InteractionsSchedulerBackgroundService>()
                .AddHostedService(sp => sp.GetRequiredService<InteractionsSchedulerBackgroundService>())
                .AddWorldKnowledge()
                .AddSingleton<DailyDynamicsBackgroundService>()
                .AddHostedService(sp => sp.GetRequiredService<DailyDynamicsBackgroundService>())
                .Configure<SignatureMechanicsOptions>(opt => { });
        }
    }
}
