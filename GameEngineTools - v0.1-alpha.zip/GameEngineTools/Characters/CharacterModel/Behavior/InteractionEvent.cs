﻿// InteractionEvent.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior
{
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;
    using GameEngineTools.World.Utils.Time;

    public sealed class InteractionEvent
    {
        public InteractionContext? Context { get; init; }
        public IHuman From { get; init; }
        public bool IsMicro { get; init; }
        public float Magnitude => RelationshipTools.GetInteractionMagnitude(Type);
        public IHuman To { get; init; }
        public InteractionType Type { get; init; }
        public WDateTime When { get; set; }
    }
}
