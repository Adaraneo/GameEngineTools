﻿// Magic.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.MagicSystem
{
    using System.Text.Json.Serialization;
    using GameEngineTools.Characters.CharacterModel.Homo;

    public interface IMagic
    {
        public void SetCanCast(bool canCast);
    }

    public abstract class Magic
    {
        private Person person;

        private void OnMagicDone(MagicArguments e)
        {
            EventHandler<MagicArguments> handler = MagicDone;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        protected bool canCast;
        //private Timer timer;

        internal Person GetPerson { get => person; }

        internal void Do(object affected)
        {
            //timer.Start();
            OnMagicDone(new MagicArguments { Affectator = this.GetPerson, Affected = affected });
            //timer.Stop();
        }

        public Magic(Person person)
        {
            //timer = new Timer(500);
            this.person = person;
        }

        public event EventHandler<MagicArguments> MagicDone;

        public double AffectPoints { get; set; }

        [JsonIgnore]
        public MagicType MagicType { get; set; }

        public override string ToString()
        {
            switch (MagicType)
            {
                case MagicType.Water:
                    return "Aqua";

                case MagicType.Air:
                    return "Zephyrus";

                case MagicType.Fire:
                    return "Ignis";

                case MagicType.Earth:
                    return "Terra";

                default:
                    return base.ToString();
            }
        }

        public class MagicArguments : EventArgs
        {
            public Person Affectator { get; set; }
            public object Affected { get; set; }
        }
    }
}
