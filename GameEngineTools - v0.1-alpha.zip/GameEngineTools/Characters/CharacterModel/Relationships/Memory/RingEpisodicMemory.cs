﻿// RingEpisodicMemory.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships.Memory
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public sealed class RingEpisodicMemory : IEpisodicMemory
    {
        private readonly Episode[] _buf;
        private int _i;
        public RingEpisodicMemory(int capacity = 12)
        {
            if (capacity < 4) capacity = 4;
            _buf = new Episode[capacity];
        }
        public void Add(Episode e)
        { _buf[_i % _buf.Length] = e; _i++; }
        public float ResonanceScore(ThemeTag[] tags, float valence, float intimacy)
        {
            float acc = 0f, w = 0f;
            foreach (var ep in _buf)
            {
                if (ep is null) continue;
                var tagOverlap = ep.Tags.Count == 0 ? 0f : ep.Tags.Intersect(tags).Count() / (float)ep.Tags.Count;
                var vSim = 1f - MathF.Abs(ep.Valence - valence);
                var iSim = 1f - MathF.Abs(ep.Intimacy - intimacy);
                var score = (0.5f * tagOverlap + 0.3f * vSim + 0.2f * iSim) * ep.Salience;
                acc += score; w += ep.Salience;
            }
            return w <= 1e-5f ? 0f : Math.Clamp(acc / (w * 1.0f), 0f, 1f);
        }
    }
}
