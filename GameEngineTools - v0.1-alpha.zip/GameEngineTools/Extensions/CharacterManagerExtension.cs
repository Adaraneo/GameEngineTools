﻿// GameManagerExtension.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Extensions
{
    using GameEngineTools;
    using GameEngineTools.Characters.CharacterModel.Relationships;
    using GameEngineTools.Characters.GameObjects;

    public static class CharacterManagerExtension
    {
        public static void ConvertDNAToPeople(this IGameEngineToolsManager instance)
        {
            RelationshipModel? relationshipModel = null;

            foreach (var person in NPPC.People)
            {
                var relationKeys = person.ExportRelationships.Keys;
                foreach (var relationKey in relationKeys)
                {
                    if (person.ExportRelationships.TryGetValue(relationKey, out relationshipModel))
                    {
                        var to = NPPC.People.FindByDNA(relationKey);
                        instance.RelationshipManager.GetRelationship(person, to).LoadFromModel(relationshipModel);
                    }
                }

                relationshipModel = null;
            }

        }

        public static void ConvertPersonToDNA(this IGameEngineToolsManager manager, in NPPC nppc)
        {
            if (nppc == null) throw new ArgumentNullException();
            var relationships = manager.RelationshipManager.EnumerateFrom(nppc.Person).ToDictionary();
            Dictionary<Guid, RelationshipModel> dnaRelationshipMap = new Dictionary<Guid, RelationshipModel>();

            foreach (var relationship in relationships)
            {
                dnaRelationshipMap.Add(relationship.Key.Body.DNA, relationship.Value.GetModel());
            }

            nppc.Person.ExportRelationships = dnaRelationshipMap;
        }
    }
}
