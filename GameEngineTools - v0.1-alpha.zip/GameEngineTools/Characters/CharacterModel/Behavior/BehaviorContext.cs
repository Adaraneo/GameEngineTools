﻿// BehaviorContext.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;
    using GameEngineTools.World.Utils.Time;

    /// <summary>
    /// Sink pro zápis do vztahové vrstvy (viz adapter níže).
    /// </summary>
    public interface IInteractionSink
    {
        void Enqueue(InteractionEvent e);
    }

    /// <summary>
    /// Vstup pro výběr chování v daném okamžiku.
    /// </summary>
    public readonly struct BehaviorContext
    {
        public IHuman Actor { get; init; }
        public float CrowdNoise01 { get; init; }

        // hluk davu 0..1
        public BehaviorGoals Goals { get; init; }

        /// <summary>
        /// InteractionContext z tvé vztahové vrstvy – použivá se pro mapování na Relationship dopady
        /// </summary>
        public InteractionContext Ix { get; init; }

        // Doplňkové prostředí, když se hodí (není nutné – většinu nese Ix)
        public float NormPressure01 { get; init; }

        /// <summary>
        /// Volitelný snapshot vztahu k cíli (pokud Target != null)
        /// </summary>
        public RelationshipSnapshotForBehavior? Rel { get; init; }

        /// <summary>
        /// Kam posílat InteractionEventy (RelationshipSimulationService)
        /// </summary>
        public IInteractionSink Sink { get; init; }

        public SituationType Situation { get; init; }
        public IHuman? Target { get; init; }             // může být null (např. čistě intrapsychické/úhybné chování)
        public WDateTime When { get; init; }
        // tlak norem 0..1
    }

    public readonly struct BehaviorGoals
    {
        /// 0..1 – čím výš, tím víc agent „chce“ afiliační/pro-sociální akce
        public readonly float AffiliationNeed01;

        public BehaviorGoals(float affiliationNeed01)
            => AffiliationNeed01 = Math.Max(0f, Math.Min(1f, affiliationNeed01));
    }

    /// <summary>
    /// Read-only snapshot vztahu pro Behavior (ať se ti to nikde zbytečně nemutuje).
    /// </summary>
    public readonly struct RelationshipSnapshotForBehavior
    {
        public readonly float Attraction;
        public readonly float Closeness;
        public readonly bool HasActiveConflict;
        public readonly float Liking;
        public readonly BondStage Stage;
        public readonly float Trust;
        public readonly BondTag BondTags;

        public RelationshipSnapshotForBehavior(float liking, float trust, float closeness, float attraction, BondStage stage, BondTag tags, bool conflict = false)
        {
            Liking = liking; Trust = trust; Closeness = closeness; Attraction = attraction; Stage = stage; BondTags = tags; HasActiveConflict = conflict;
        }
    }
}
