﻿// EncounterProfiles.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.World.Encounters
{
    using System;
    using System.Collections.Generic;
    using GameEngineTools;
    using GameEngineTools.Characters.CharacterModel.Behavior;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    public enum PlaceArchetype
    { Corridor, Office, Workshop, Cafe, Church, Park, Home, StageBackstage, RehearsalRoom, PublicSquare }

    public readonly struct PlaceProfile
    {
        public readonly PlaceArchetype Archetype;
        public readonly float BaseDepth;
        public readonly float BasePrivacy;       // 0..1 (1 = velmi soukromé)

        // 0..1 (typicky roste s privacy)
        public readonly float BaseRisk;          // 0..1

        public readonly float BaseSharedGoal;    // 0..1 (pracoviště/rehearsal více)
        public readonly bool IsWorkLike;

        public PlaceProfile(PlaceArchetype a, float privacy, float depth, float risk, float sharedGoal, bool work)
        {
            Archetype = a; BasePrivacy = privacy; BaseDepth = depth; BaseRisk = risk; BaseSharedGoal = sharedGoal; IsWorkLike = work;
        }
    }

    public static class EncounterProfiles
    {
        public static readonly Dictionary<PlaceArchetype, PlaceProfile> Profiles = new()
        {
            [PlaceArchetype.Corridor] = new(PlaceArchetype.Corridor, 0.15f, 0.10f, 0.05f, 0.05f, false),
            [PlaceArchetype.Office] = new(PlaceArchetype.Office, 0.55f, 0.45f, 0.10f, 0.60f, true),
            [PlaceArchetype.Workshop] = new(PlaceArchetype.Workshop, 0.40f, 0.30f, 0.15f, 0.70f, true),
            [PlaceArchetype.Cafe] = new(PlaceArchetype.Cafe, 0.30f, 0.30f, 0.05f, 0.20f, false),
            [PlaceArchetype.Church] = new(PlaceArchetype.Church, 0.60f, 0.55f, 0.05f, 0.30f, false),
            [PlaceArchetype.Park] = new(PlaceArchetype.Park, 0.45f, 0.35f, 0.05f, 0.10f, false),
            [PlaceArchetype.Home] = new(PlaceArchetype.Home, 0.80f, 0.70f, 0.10f, 0.15f, false),
            [PlaceArchetype.StageBackstage] = new(PlaceArchetype.StageBackstage, 0.35f, 0.30f, 0.15f, 0.65f, true),
            [PlaceArchetype.RehearsalRoom] = new(PlaceArchetype.RehearsalRoom, 0.50f, 0.45f, 0.10f, 0.75f, true),
            [PlaceArchetype.PublicSquare] = new(PlaceArchetype.PublicSquare, 0.10f, 0.10f, 0.05f, 0.05f, false),
        };

        public static InteractionContext BuildIx(PlaceProfile p, int occupantCount, int maxCapacity, float moodShift = 0f)
        {
            // publikem zmenšujeme privacy, zvyšujeme audience
            float crowd = maxCapacity <= 1 ? 0f : Math.Clamp((float)occupantCount / Math.Max(2, maxCapacity), 0f, 1f);
            float privacy = Math.Clamp(p.BasePrivacy * (1f - 0.6f * crowd), 0f, 1f);
            float depth = Math.Clamp(p.BaseDepth * (1f - 0.3f * crowd), 0f, 1f);
            float audience = Math.Clamp(0.1f + 0.8f * crowd, 0f, 1f);

            return new InteractionContext
            {
                Privacy = privacy,
                Depth = depth,
                Risk = p.BaseRisk,
                SharedGoal = p.BaseSharedGoal,
                SocialAudience = audience,
                Physicality = 0f,
                Continuity = 0.3f,
                EmotionalTone = Math.Clamp(moodShift, -1f, 1f)
            };
        }

        public static SituationType ClassifySituation(PlaceProfile p, int occupantCount, bool isTransit, (RelationshipSnapshotForBehavior relAB, RelationshipSnapshotForBehavior relBA) mutualRelationship)
        {
            var areClose = mutualRelationship.relAB.BondTags.HasFlag(BondTag.Close) && mutualRelationship.relBA.BondTags.HasFlag(BondTag.Close);
            var sameTeamOrTask = mutualRelationship.relAB.BondTags.HasFlag(BondTag.Colleague) && mutualRelationship.relBA.BondTags.HasFlag(BondTag.Colleague);
            if (isTransit) return SituationType.ChanceEncounter;
            if (occupantCount <= 2 && p.BasePrivacy >= 0.5f) return SituationType.OneOnOnePrivate;
            if (p.IsWorkLike && sameTeamOrTask) return SituationType.WorkTask;
            if (p.Archetype is PlaceArchetype.RehearsalRoom or PlaceArchetype.StageBackstage) return SituationType.GroupSetting;
            if (p.Archetype is PlaceArchetype.Cafe or PlaceArchetype.Park) return areClose ? SituationType.FriendChat : SituationType.GroupSetting;
            return occupantCount > 2 ? SituationType.GroupSetting : SituationType.ChanceEncounter;
        }
    }
}
