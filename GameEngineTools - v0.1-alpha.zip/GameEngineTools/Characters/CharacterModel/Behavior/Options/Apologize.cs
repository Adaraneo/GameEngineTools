﻿// Apologize.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using System;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    public sealed class Apologize : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.Apologize;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Apology,
                When = ctx.When,
                IsMicro = false,
                Context = new InteractionContext
                {
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.25f, 0f, 1f),
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone - 0.05f, -1f, 1f),
                    Privacy = Math.Max(ctx.Ix.Privacy, 0.6f), // omluva spíš v soukromí
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.05f, 0f, 1f),
                    SocialAudience = 0f,
                    SharedGoal = ctx.Ix.SharedGoal,
                    Continuity = ctx.Ix.Continuity
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
                    => ctx.Target is not null && ctx.Rel.HasValue && ctx.Rel.Value.HasActiveConflict;

        public float Utility(in BehaviorContext ctx)
        {
            var psy = ctx.Actor.Psychology;
            double conscience = ctx.Actor.Personality.Morality.Scores.GetValueOrDefault(Homo.MoralDimension.Honesty); // pokud máš jinak, klidně uprav

            double u = 0.10 + 0.30 * conscience + 0.25 * (ctx.Rel!.Value.Trust / 100.0)
                       + 0.15 * (0.5 + 0.5 * psy.Mood) - 0.15 * psy.StressLevel;
            return Bx.Clamp01(u);
        }
    }
}
