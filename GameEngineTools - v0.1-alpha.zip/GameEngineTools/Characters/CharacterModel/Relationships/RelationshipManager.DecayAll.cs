﻿// RelationshipManager.DecayAll.cs
// Copyright (c) 50PSoftware

// Relationships/RelationshipManager.DecayAll.partial.cs
namespace GameEngineTools.Characters.CharacterModel.Relationships
{
    using GameEngineTools.World.Core.Time;
    using GameEngineTools.World.Utils.Time;

    public sealed partial class RelationshipManager
    {
        /// <summary>
        /// Aplikuje decay všem známým vztahům o daný časový krok a publikuje změny.
        /// </summary>
        public void TickDecay(IClock clock, WTimeSpan dt)
        {
            foreach (var kv in _relationships.ToArray())
            {
                var (from, to) = kv.Key;
                Decay(from, to, dt);
            }
        }
    }
}

