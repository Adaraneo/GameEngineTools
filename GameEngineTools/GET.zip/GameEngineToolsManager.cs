﻿// CharacterManager.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools
{
    using GameEngineTools.Armory;
    using GameEngineTools.Characters;
    using GameEngineTools.Characters.Core;
    using GameEngineTools.Characters.GameObjects;
    using GameEngineTools.Constants;
    using GameEngineTools.FileSystem;
    using GameEngineTools.World.Core.Time;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;

    public sealed class GameEngineToolsManager : IGameEngineToolsManager
    {
        private readonly ILogger<GameEngineToolsManager> _log;
        private readonly GameEngineToolsManagerOptions _opt;
        private List<ArmorPart> armorParts = new List<ArmorPart>();
        private List<Name> female_names = new List<Name>();
        private List<Name> male_names = new List<Name>();
        private List<Surname> surnames = new List<Surname>();
        private List<Weapon> weapons = new List<Weapon>();

        private void LoadResources()
        {
            SourceFile file = new SourceFile();
            file.SetFilenames(FileSystemConstant.SourceFilePath.maleNames, FileSystemConstant.SourceFilePath.femaleNames, FileSystemConstant.SourceFilePath.surnames, FileSystemConstant.SourceFilePath.weapons, FileSystemConstant.SourceFilePath.armorParts);
            file.Load(out male_names, 0);
            file.Load(out female_names, 1);
            file.Load(out surnames, 2);
            file.Load(out weapons, 3);
            file.Load(out armorParts, 4);
            _log.LogInformation("Names loaded: male={Male}, female={Female}, surnames={Surnames}", male_names.Count, female_names.Count, surnames.Count);
        }

        public GameEngineToolsManager(
            IClock clock,
            IOptions<GameEngineToolsManagerOptions> opt,
            ILogger<GameEngineToolsManager> log)
        {
            _opt = opt.Value;
            _log = log;
            _clock = clock;
        }

        /// <summary>
        /// For test purposes!
        /// </summary>
        public Dictionary<Type, object> Items { get; } = new Dictionary<Type, object>();

        public List<CharacterBase> NPPCs { get; } = new List<CharacterBase>();

        //public IServiceProvider ServiceProvider { get; private set; } = default!;

        private IClock _clock;

        public void Initialize()
        {
            _log.LogInformation("Initializing CharacterManager...");
            _log.LogInformation("CharacterManager init (logs: {0})", _opt.LogsRoot);
            _log.LogInformation("Initializing...");
            CharacterBase.People.Clear();
            NPPCs.Clear();
            Items.Clear();
            _log.LogInformation("Initialized");
            _log.LogInformation("Loading content...");
            LoadResources();
            Items.Add(typeof(Weapon), weapons);
            Items.Add(typeof(ArmorPart), armorParts);
            _log.LogInformation("Loaded");
        }
    }
}
