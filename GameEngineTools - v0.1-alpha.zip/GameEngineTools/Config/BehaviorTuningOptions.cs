﻿// BehaviorTuningOptions.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Config
{
    public sealed class BehaviorTuningOptions
    {
        public double W_Base { get; set; } = 1.00;
        public double W_Cost { get; set; } = 0.20;
        public double W_Moral { get; set; } = 0.25;
        public double W_Psycho { get; set; } = 0.30;
        public double W_Traits { get; set; } = 0.25;
        public double W_Variety { get; set; } = 0.20;
        public double W_Pref { get; set; } = 0.15;
        public double EpsilonGreedy { get; set; } = 0.06; // míra explorace
    }

}
