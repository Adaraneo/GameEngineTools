﻿// RelationshipManager.TimeHelpers.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships
{
    using GameEngineTools.Characters.CharacterModel.Events;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.World.Core.Time;
    using GameEngineTools.World.Utils.Time;

    public sealed partial class RelationshipManager
    {
        public void ApplyInteractionAt(
            IHuman from, IHuman to, InteractionType interaction, WDateTime when,
            float baseEffect = 1f, InteractionContext? context = null)
        {
            var prev = this.clock;
            try
            {
                this.clock = new FrozenClock(when);
                ApplyInteraction(from, to, interaction, baseEffect, context);

            }
            finally { this.clock = prev; }
        }

        private sealed class FrozenClock : IClock
        {
            public FrozenClock(WDateTime now) { Now = now; }
            public WDateTime Now { get; }

            public void Start()
            {
            }

            public void Stop()
            {
            }

            public void Tick(WTimeSpan step)
            {
            }
        }
    }

}
