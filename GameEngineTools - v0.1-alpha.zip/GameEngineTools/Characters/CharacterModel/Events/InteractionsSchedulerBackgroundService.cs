﻿// InteractionsSchedulerBackgroundService.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Events
{
    using System.Collections.Concurrent;
    using System.Diagnostics;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Logging;
    using GameEngineTools.Characters.CharacterModel.Events;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;
    using GameEngineTools.Logging;
    using GameEngineTools.World.Core.Time;
    using GameEngineTools.World.Utils.Time;

    public sealed class InteractionsSchedulerBackgroundService : BackgroundService
    {
        private readonly IEventBus _bus;
        private readonly RelationshipManager _rm;
        private readonly IHumanResolver _humans;
        private readonly IClock _clock;
        private readonly ILogger<InteractionsSchedulerBackgroundService> _log;

        private readonly SortedSet<(WDateTime when, Guid orderId, ScheduledInteractionEvent e)> _q =
            new(new WhenTieComparer());

        private sealed class WhenTieComparer : IComparer<(WDateTime when, Guid orderId, ScheduledInteractionEvent e)>
        {
            public int Compare((WDateTime when, Guid orderId, ScheduledInteractionEvent e) x,
                               (WDateTime when, Guid orderId, ScheduledInteractionEvent e) y)
            {
                int t = x.when.CompareTo(y.when);
                if (t != 0) return t;
                return x.orderId.CompareTo(y.orderId);
            }
        }

        public InteractionsSchedulerBackgroundService(
            IEventBus bus, RelationshipManager rm, IHumanResolver humans, IClock clock, ILogger<InteractionsSchedulerBackgroundService> log)
        {
            _log = log;
            _bus = bus;
            _rm = rm;
            _humans = humans;
            _clock = clock;
            _bus.Subscribe<ScheduledInteractionEvent>(OnScheduled);
        }

        public override Task StartAsync(CancellationToken cancellationToken)
        {
            _log.LogInformation(LogIds.SchedulerStarted, "{InteractionsSchedulerBackgroundService} starting…", nameof(InteractionsSchedulerBackgroundService));
            return base.StartAsync(cancellationToken);
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            _log.LogInformation(LogIds.SchedulerStarted, "{InteractionsSchedulerBackgroundService} stopping…", nameof(InteractionsSchedulerBackgroundService));
            return base.StopAsync(cancellationToken);
        }

        private void OnScheduled(ScheduledInteractionEvent e)
            => _q.Add((e.When, Guid.NewGuid(), e));

        protected override async Task ExecuteAsync(CancellationToken stop)
        {
            while (!stop.IsCancellationRequested)
            {
                var now = _clock.Now;

                using var scope = _log.BeginScope(new Dictionary<string, object>
                {
                    ["phase"] = "scheduler",
                    ["tick"] = now.ToString("O")
                });

                var sw = Stopwatch.StartNew();

                try
                {
                    DrainDue();
                }
                catch (Exception ex)
                {
                    _log.LogError(ex, "Error in {Service} while processing scheduled interactions.\n{Message}", nameof(InteractionsSchedulerBackgroundService), ex.Message);
                }

                await Task.Delay(100, stop); // klidně konfigurovatelný interval
            }
        }

        private void DrainDue()
        {
            if (_q.Count == 0) { _log?.LogDebug("Scheduler idle (queue empty)."); return; }

            // bezpečně čti current time
            var now = _clock.Now;
            int processed = 0;

            // dokud je nahoře něco „due“
            while (_q.Count > 0 && _q.Min!.when <= now)
            {
                var (_,_, e) = _q.Min!;
                _q.Remove(_q.Min!);

                if (!_humans.TryGet(e.ActorId, out var from)) continue;
                if (!_humans.TryGet(e.TargetId, out var to)) continue;

                _rm.ApplyInteractionAt(from, to, e.InteractionType, e.When, e.Magnitude, e.Context);
                processed++;
            }

            if (processed > 0)
                _log?.LogInformation(LogIds.SchedulerRun, "Scheduler processed {Count} interactions, next at {Next}.", processed, _q.Count > 0 ? _q.Min!.when.ToString("O") : "(none)");
            else
                _log?.LogDebug(LogIds.SchedulerIdle, "Scheduler idle (no due interactions, next at {Next}).", _q.Min!.when.ToString("O"));
        }
    }

}
