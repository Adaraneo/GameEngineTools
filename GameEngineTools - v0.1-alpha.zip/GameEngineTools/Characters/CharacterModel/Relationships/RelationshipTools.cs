﻿// RelationshipMath.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships
{
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.World.Utils.Time;
    public struct InteractionContext
    {
        public float Continuity;

        public float Depth;

        public float EmotionalTone;

        public float Physicality;

        public float Privacy;
        public float Risk;
        public float SharedGoal;

        public float SocialAudience;

        public float Surprise;
        public float Warmth;

        public float Sincerity;
        public Guid[]? AudienceWitnessIds;
        public float Noise;

        public bool HasConsentExplicit;
        public bool HasSincerityExplicit;

        public static InteractionContext Neutral => new()
        {
            Privacy = 0.4f,
            Risk = 0.0f,
            Surprise = 0.2f,
            SharedGoal = 0.3f,
            Warmth = 0.5f,
            EmotionalTone = 0.0f,
            Physicality = 0.0f,
            SocialAudience = 0.4f,
            Continuity = 0.5f,
            Depth = 0.5f,
            Noise = 0.1f,
            Sincerity = 0.4f
        };
    }

    public static class InteractionContextMath
    {
        public static void Apply(ref float dL, ref float dT, ref float dA, ref float dC, InteractionContext ctx, Relationship r)
        {
            // --- Stávající logika ---
            // intimita a teplo → closeness
            dC += 0.05f * ctx.Privacy + 0.02f * ctx.Warmth;

            // společné riziko/cíl → trust (a trošku closeness)
            dT += 0.04f * ctx.Risk + 0.05f * ctx.SharedGoal;
            dC += 0.02f * ctx.SharedGoal;

            // překvapení × potřeba novosti (Openness) → attraction
            float O = (float)r.From.Personality.BigFive[BigFiveTrait.Openness]; // 0..1
            dA += 0.06f * ctx.Surprise * O;

            // --- Nové dimenze ---

            // 1) Emoční valence situace: +valence jemně zvedá L/T/C, -valence naopak sráží
            //    (udrž to měkké – samotný interaction typ už řeší šoky)
            float emo = Math.Clamp(ctx.EmotionalTone, -1f, 1f);
            dL += 0.06f * emo;
            dT += 0.04f * emo;
            dC += 0.03f * emo;

            // 2) Fyzická blízkost: zvedá Attraction i Closeness, ale „bráněno“ důvěrou
            //    (bez důvěry se fyzická blízkost čte hůř)
            float trustGate = Math.Clamp(0.5f + r.Trust / 100f, 0.5f, 1.2f); // stejná logika jako GateByTrust :contentReference[oaicite:2]{index=2}
            float phys = Math.Clamp(ctx.Physicality, 0f, 1f);
            dA += 0.08f * phys * trustGate;
            dC += 0.04f * phys * trustGate;

            // 3) Publikum: veřejnost pomáhá „liking“ přes sociální signály (když je valence kladná),
            //    ale tlumí důvěru hlubokého sdílení (Depth) – citlivé věci na veřejnosti nepřidají na T.
            float aud = Math.Clamp(ctx.SocialAudience, 0f, 1f);
            dL += 0.02f * aud * Math.Max(0f, emo);           // „vypadalo to dobře před lidmi“
            dT -= 0.03f * aud * Math.Clamp(ctx.Depth, 0f, 1f); // hluboko a veřejně → nedůvěřivé

            // 4) Kontinuita: „navazujeme na naše“ – drobný, ale stabilní nárůst C a T
            float cont = Math.Clamp(ctx.Continuity, 0f, 1f);
            dC += 0.03f * cont;
            dT += 0.02f * cont;

            // 5) Hloubka sdílení: funguje hlavně v soukromí; zvyšuje T i C
            float depth = Math.Clamp(ctx.Depth, 0f, 1f);
            float privacyGate = 0.5f + 0.5f * Math.Clamp(ctx.Privacy, 0f, 1f); // veřejně má poloviční sílu
            dT += 0.06f * depth * privacyGate;
            dC += 0.05f * depth * privacyGate;

            // --- Bezpečné měkké ořezy, ať delty neulítnou (kontext je jen modulace, ne hlavní zdroj) ---
            dL = Math.Clamp(dL, -2f, +2f);
            dT = Math.Clamp(dT, -2f, +2f);
            dA = Math.Clamp(dA, -2f, +2f);
            dC = Math.Clamp(dC, -2f, +2f);
        }
    }

    // Presetové kontexty a helpery
    public static class InteractionContexts
    {
        public static InteractionContext WithContinuity(this InteractionContext c, float v)
        { c.Continuity = Math.Clamp(v, 0f, 1f); return c; }

        public static InteractionContext WithDepth(this InteractionContext c, float v)
        { c.Depth = Math.Clamp(v, 0f, 1f); return c; }

        public static InteractionContext WithEmotionalTone(this InteractionContext c, float v)
        { c.EmotionalTone = Math.Clamp(v, -1f, 1f); return c; }

        public static InteractionContext WithPhysicality(this InteractionContext c, float v)
        { c.Physicality = Math.Clamp(v, 0f, 1f); return c; }

        // --- Helpery: bezpečné „buildery“ nad structem ---
        public static InteractionContext WithPrivacy(this InteractionContext c, float v)
        { c.Privacy = Math.Clamp(v, 0f, 1f); return c; }

        public static InteractionContext WithRisk(this InteractionContext c, float v)
        { c.Risk = Math.Clamp(v, 0f, 1f); return c; }

        public static InteractionContext WithSharedGoal(this InteractionContext c, float v)
        { c.SharedGoal = Math.Clamp(v, 0f, 1f); return c; }

        public static InteractionContext WithSocialAudience(this InteractionContext c, float v)
        { c.SocialAudience = Math.Clamp(v, 0f, 1f); return c; }

        public static InteractionContext WithSurprise(this InteractionContext c, float v)
        { c.Surprise = Math.Clamp(v, 0f, 1f); return c; }

        public static InteractionContext WithWarmth(this InteractionContext c, float v)
        { c.Warmth = Math.Clamp(v, 0f, 1f); return c; }

        public static InteractionContext WithSincerity(this InteractionContext c, float v)
        { c.Sincerity = Math.Clamp(v, 0f, 1f); return c; }

        public static InteractionContext WithWitnesses(this InteractionContext c, Guid[] ids)
        { c.AudienceWitnessIds = ids; return c; }

        public static InteractionContext WithNoise(this InteractionContext c, float v)
        { c.Noise = Math.Clamp(v, 0f, 1f); return c; }

        #region UniBuilder

        // --- Univerzální builder pro všechny InteractionType ---
        // (vložit do public static class InteractionContexts)

        public enum Modality
        {
            Verbal,         // rozhovor, omluva, kompliment
            Practical,      // společná práce, dárky, pomoc s věcmi
            Emotional,      // sdílení, podpora, intimní témata
            Playful,        // flirt, lehká hra
            Romantic,       // rande, sex-kontekst
            Conflict,       // hádka, napětí
            PhysicalForce   // agrese, strkanice atd.
        }

        public enum SeverityLevel
        { Trivial, Minor, Moderate, Major, Extreme }

        public enum Venue
        { Public, SemiPrivate, Private }

        /// <summary>
        /// Volitelné override pro jemné doladění – zadaj jen to, co chceš změnit.
        /// </summary>
        public record InteractionContextOptions(
            SeverityLevel Severity = SeverityLevel.Moderate,
            Venue Venue = Venue.SemiPrivate,
            Modality Modality = Modality.Practical,
            bool Ongoing = false,
            float? Surprise = null,
            float? Warmth = null,
            float? Depth = null,
            float? Physicality = null,
            float? Privacy = null,
            float? SocialAudience = null,
            float? EmotionalTone = null,
            float? SharedGoal = null,
            float? Risk = null,
            float? Continuity = null
        );

        public static InteractionContext BuildContextFor(InteractionType type, InteractionContextOptions? o = null)
        {
            o ??= new InteractionContextOptions();

            // --- Venue → Privacy/Audience ---
            float privacy = o.Venue switch
            {
                Venue.Public => 0.20f,
                Venue.SemiPrivate => 0.60f,
                Venue.Private => 0.90f,
                _ => 0.40f
            };
            float audience = 1f - privacy;

            // --- Severity → Risk/Surprise (jemně) ---
            (float sevRisk, float sevSurp) = o.Severity switch
            {
                SeverityLevel.Trivial => (0.05f, 0.10f),
                SeverityLevel.Minor => (0.15f, 0.20f),
                SeverityLevel.Moderate => (0.30f, 0.35f),
                SeverityLevel.Major => (0.55f, 0.55f),
                SeverityLevel.Extreme => (0.85f, 0.80f),
                _ => (0.20f, 0.25f)
            };

            // --- Modality baseline (teplo, valence, fyzikalita, hloubka) ---
            float warmth = o.Modality switch
            {
                Modality.Emotional => 0.85f,
                Modality.Romantic => 0.80f,
                Modality.Playful => 0.75f,
                Modality.Practical => 0.65f,
                Modality.Verbal => 0.60f,
                Modality.Conflict => 0.25f,
                Modality.PhysicalForce => 0.10f,
                _ => 0.60f
            };

            float emoTone = o.Modality switch
            {
                Modality.Emotional => +0.70f,
                Modality.Romantic => +0.60f,
                Modality.Playful => +0.50f,
                Modality.Practical => +0.40f,
                Modality.Verbal => +0.30f,
                Modality.Conflict => -0.60f,
                Modality.PhysicalForce => -0.85f,
                _ => +0.30f
            };

            float physicality = o.Modality switch
            {
                Modality.Romantic => 0.70f,
                Modality.Playful => 0.35f,
                Modality.Emotional => 0.30f, // objetí
                Modality.Practical => 0.20f,
                Modality.Verbal => 0.05f,
                Modality.Conflict => 0.15f, // „lean-in“/tension
                Modality.PhysicalForce => 0.80f,
                _ => 0.15f
            };

            float baseDepth = o.Modality switch
            {
                Modality.Emotional => 0.60f,
                Modality.Romantic => 0.55f,
                Modality.Practical => 0.40f,
                Modality.Verbal => 0.35f,
                Modality.Playful => 0.30f,
                Modality.Conflict => 0.45f,
                Modality.PhysicalForce => 0.25f,
                _ => 0.40f
            };
            float continuity = o.Ongoing ? 0.80f : 0.30f;
            float depth = Math.Clamp(baseDepth + 0.20f * privacy + (o.Ongoing ? 0.15f : 0f), 0f, 1f);

            // --- Typová mapa: posune baseline pro daný InteractionType ---
            float sharedGoal = 0.30f;
            float risk = sevRisk;
            float surprise = sevSurp;

            switch (type)
            {
                case InteractionType.Help:
                    sharedGoal = 0.75f + (o.Severity >= SeverityLevel.Major ? 0.15f : 0f);
                    if (o.Severity == SeverityLevel.Extreme) physicality = Math.Min(1f, physicality + 0.20f);
                    break;

                case InteractionType.Gift:
                    surprise = Math.Max(surprise, 0.55f);
                    warmth = Math.Max(warmth, 0.70f);
                    sharedGoal = 0.40f;
                    depth = Math.Min(depth, 0.45f);
                    break;

                case InteractionType.Honesty:
                    depth = Math.Max(depth, 0.70f);
                    warmth = Math.Max(warmth, 0.65f);
                    emoTone = Math.Max(emoTone, +0.40f);
                    risk = Math.Max(risk, 0.25f);          // zranitelnost
                    privacy = Math.Max(privacy, 0.70f);    // lépe v soukromí
                    audience = 1f - privacy;
                    break;

                case InteractionType.Cooperation:
                    sharedGoal = Math.Max(sharedGoal, 0.90f);
                    warmth = Math.Max(warmth, 0.60f);
                    risk = Math.Max(risk, 0.30f);
                    break;

                case InteractionType.Betrayal:
                    emoTone = -0.90f;
                    warmth = 0.05f;
                    risk = Math.Max(risk, 0.50f);
                    surprise = Math.Max(surprise, 0.70f);
                    depth = Math.Max(depth, 0.50f); // čím bližší, tím horší dopad; kontext zachytí „hloubku“
                    break;

                case InteractionType.Insult:
                    emoTone = -0.70f;
                    warmth = 0.10f;
                    surprise = Math.Max(surprise, 0.45f);
                    depth = Math.Min(depth, 0.40f);
                    break;

                case InteractionType.Lie:
                    emoTone = -0.65f;
                    warmth = 0.10f;
                    risk = Math.Max(risk, 0.35f);
                    surprise = Math.Max(surprise, 0.60f);
                    break;

                case InteractionType.Aggression:
                    o = o with { Modality = Modality.PhysicalForce }; // pro jistotu
                    emoTone = -0.90f;
                    warmth = 0.05f;
                    physicality = Math.Max(physicality, 0.80f);
                    risk = Math.Max(risk, 0.80f);
                    privacy = Math.Min(privacy, 0.40f); // často veřejné/tlak
                    audience = 1f - privacy;
                    break;

                case InteractionType.Compliment:
                    o = o with { Modality = Modality.Verbal, Venue = o.Venue };
                    warmth = Math.Max(warmth, 0.70f);
                    emoTone = Math.Max(emoTone, +0.50f);
                    surprise = Math.Max(surprise, 0.40f);
                    depth = Math.Min(depth, 0.40f);
                    physicality = Math.Max(physicality, 0.10f);
                    break;

                case InteractionType.Flirt:
                    o = o with { Modality = Modality.Playful };
                    surprise = Math.Max(surprise, 0.55f);
                    warmth = Math.Max(warmth, 0.75f);
                    physicality = Math.Max(physicality, 0.35f);
                    depth = Math.Min(depth, 0.45f);
                    break;

                case InteractionType.SpendTime:
                    sharedGoal = Math.Max(sharedGoal, 0.50f);
                    continuity = Math.Max(continuity, 0.70f);
                    warmth = Math.Max(warmth, 0.65f);
                    break;

                case InteractionType.Apology:
                    o = o with { Modality = Modality.Verbal };
                    privacy = Math.Max(privacy, 0.70f);
                    audience = 1f - privacy;
                    depth = Math.Max(depth, 0.55f);
                    warmth = Math.Max(warmth, 0.65f);
                    emoTone = Math.Max(emoTone, +0.45f);
                    risk = Math.Max(risk, 0.20f); // zranitelnost
                    break;

                case InteractionType.SharedActivity:
                    sharedGoal = Math.Max(sharedGoal, 0.90f);
                    warmth = Math.Max(warmth, 0.65f);
                    surprise = Math.Max(surprise, 0.30f);
                    continuity = Math.Max(continuity, 0.60f);
                    break;

                case InteractionType.Conversation:
                    o = o with { Modality = Modality.Verbal };
                    depth = Math.Clamp(depth, 0.40f, 0.70f);
                    warmth = Math.Max(warmth, 0.60f);
                    break;

                case InteractionType.SmallTalk:
                    o = o with { Modality = Modality.Verbal, Venue = o.Venue };
                    depth = Math.Min(depth, 0.30f);
                    warmth = Math.Max(warmth, 0.55f);
                    surprise = Math.Min(surprise, 0.25f);
                    physicality = Math.Min(physicality, 0.05f);
                    break;

                case InteractionType.Sex:
                    o = o with { Modality = Modality.Romantic, Venue = Venue.Private };
                    privacy = 0.95f; audience = 0.05f;
                    physicality = 0.95f;
                    warmth = Math.Max(warmth, 0.85f);
                    depth = Math.Max(depth, 0.65f);
                    surprise = Math.Max(surprise, 0.40f);
                    sharedGoal = Math.Max(sharedGoal, 0.60f);
                    break;

                default:
                    break;
            }

            // --- Složení do výsledného kontextu (od Neutral) ---
            var ctx = InteractionContext.Neutral
                .WithPrivacy(privacy)
                .WithRisk(risk)
                .WithSharedGoal(sharedGoal)
                .WithSurprise(surprise)
                .WithWarmth(warmth)
                .WithEmotionalTone(emoTone)
                .WithPhysicality(physicality)
                .WithSocialAudience(audience)
                .WithContinuity(continuity)
                .WithDepth(depth);

            // --- Aplikuj explicitní overrides z options (pokud jsou vyplněny) ---
            if (o.Privacy is float p) ctx = ctx.WithPrivacy(p);
            if (o.Risk is float r1) ctx = ctx.WithRisk(r1);
            if (o.SharedGoal is float sg) ctx = ctx.WithSharedGoal(sg);
            if (o.Surprise is float sp) ctx = ctx.WithSurprise(sp);
            if (o.Warmth is float w) ctx = ctx.WithWarmth(w);
            if (o.EmotionalTone is float et) ctx = ctx.WithEmotionalTone(et);
            if (o.Physicality is float ph) ctx = ctx.WithPhysicality(ph);
            if (o.SocialAudience is float au) ctx = ctx.WithSocialAudience(au);
            if (o.Continuity is float co) ctx = ctx.WithContinuity(co);
            if (o.Depth is float de) ctx = ctx.WithDepth(de);

            return ctx;
        }

        public static InteractionContext BuildForApology(Venue venue = Venue.Private)
                    => BuildContextFor(InteractionType.Apology, new InteractionContextOptions(Venue: venue, Modality: Modality.Verbal));

        // --- Shortcuty pro čitelné použití v kódu (volitelné) ---
        public static InteractionContext BuildForFlirt(Venue venue = Venue.SemiPrivate)
            => BuildContextFor(InteractionType.Flirt, new InteractionContextOptions(Venue: venue, Modality: Modality.Playful));

        public static InteractionContext BuildForHelp(SeverityLevel severity = SeverityLevel.Moderate, Venue venue = Venue.SemiPrivate, bool ongoing = false, Modality modality = Modality.Practical)
            => BuildContextFor(InteractionType.Help, new InteractionContextOptions(Severity: severity, Venue: venue, Modality: modality, Ongoing: ongoing));

        public static InteractionContext BuildForSex()
                    => BuildContextFor(InteractionType.Sex, new InteractionContextOptions(Venue: Venue.Private, Modality: Modality.Romantic));

        #endregion UniBuilder
    }

    public static class RelationshipMath
    {
        public static float DecayLambda(float value, float lambdaPerDay, float dtDays)
            => value * (float)Math.Exp(-Math.Max(0f, lambdaPerDay) * Math.Max(0f, dtDays));

        public static float ComputeConsentAuto(in InteractionContext ix, Relationship rel)
        {
            var trust01 = rel.MaxTrust > 0 ? rel.Trust / rel.MaxTrust : 0.5f;
            var stage01 = rel.Stage switch { BondStage.Stranger => 0.2f, BondStage.Familiar => 0.5f, BondStage.Friend => 0.75f, BondStage.Intimate => 0.95f, _ => 0.6f };
            var privacy = Math.Clamp(ix.Privacy, 0f, 1f);
            var warmth = Math.Clamp(ix.Warmth, 0f, 1f);
            var energy = Math.Clamp((float)(rel.To.Psychology?.SocialDrive ?? 0.5), 0f, 1f);

            var raw = 0.35f * trust01 + 0.25f * stage01 + 0.20f * privacy + 0.10f * warmth + 0.10f * energy;
            return Math.Clamp(0.3f + raw, 0.30f, 1.10f);
        }

        public static float ComputeSincerityAuto(in InteractionContext ix, IHuman actor, Relationship rel)
        {
            // 1) pokud je v ctx explicitní hodnota, použij ji
            if (ix.HasSincerityExplicit) return Math.Clamp(ix.Sincerity, 0f, 1f);

            // 2) inference z rysů a situace
            var bf = actor.Personality?.BigFive;
            float con = bf != null ? (float)bf[BigFiveTrait.Conscientiousness] : 0.5f;
            float agr = bf != null ? (float)bf[BigFiveTrait.Agreeableness] : 0.5f;
            float emo = bf != null ? 1f - (float)bf[BigFiveTrait.Neuroticism] : 0.5f; // emo stabilita
            float tone = Math.Clamp(0.5f + 0.5f * ix.EmotionalTone, 0f, 1f); // [-1..1] → [0..1]

            // Penalizace za „serial apologizer“
            float repairDebt = rel.Repair?.Debt ?? 0f; // 0..1; pokud nemáš, dej 0
            var raw = 0.25f * con + 0.25f * agr + 0.15f * emo + 0.20f * tone + 0.15f * (1f - repairDebt);

            return Math.Clamp(raw, 0f, 1f);
        }

        /// <summary>
        /// „Aktivační energie“ – když je jednotlivec KO, kladné zisky omez
        /// </summary>
        /// <param name="baseGain"></param>
        /// <param name="energy"></param>
        /// <param name="stress"></param>
        /// <returns></returns>
        public static float ActivationGate(float baseGain, float energy, float stress)
        {
            if (energy < 30f || stress > 70f) return baseGain * 0.75f;
            return baseGain;
        }

        public static float ApplyShock(float value, float severity, bool positive, float trust01)
        {
            // Negativa děláme konvexní (těžší ocas), pozitiva jemnější.
            float amp = positive
                ? 0.6f * severity                                  // jemnější růst
                : (0.8f + 1.6f * severity) * MathF.Max(0.6f, trust01); // „zrada bolí víc, když je důvěra“
            float delta = (positive ? +1f : -1f) * amp;
            return Math.Clamp(value + delta, 0f, 100f);
        }

        public static float Clamp(float v, float min = -100f, float max = 100f) => v < min ? min : (v > max ? max : v);
        // --- Lightweight kontext + sjednocená novost ---

        public static float ContextScaleLite(in InteractionContext ix)
        {
            // Privacy ↑; Audience ↓
            float privacy = Lerp(0.85f, 1.15f, Clamp(ix.Privacy));
            float audience = Lerp(1.10f, 0.90f, Clamp(ix.SocialAudience));
            // Tone ±10 %
            float tone = ix.EmotionalTone >= 0f
                ? Lerp(1.00f, 1.10f, Clamp(ix.EmotionalTone))
                : Lerp(0.90f, 1.00f, Clamp(1f + ix.EmotionalTone));
            // Depth/Physicality podpořené soukromím
            float depthPhys = Lerp(0.95f, 1.10f, 0.5f * Clamp(ix.Depth + ix.Physicality) * Clamp(ix.Privacy));

            float s = privacy * audience * tone * depthPhys;
            return Math.Clamp(s, 0.70f, 1.30f);
        }

        // repeatIdx: 0 = poprvé, 1 = podruhé, 2 = potřetí…
        public static float NoveltyFactor(int repeatIdx)
        {
            if (repeatIdx <= 0) return 1.20f; // +20 %
            if (repeatIdx == 1) return 1.10f; // +10 %
            if (repeatIdx == 2) return 1.05f; // +5 %
                                              // po třetím opakování jemná saturace k 0.95
            return Lerp(1.00f, 0.95f, Clamp((repeatIdx - 2) / 5f));
        }

        // Váhy pro skládání složek kompatibility
        public readonly struct CompatibilityWeights
        {
            // makro-složky (musí dávat smysl 0..1)
            public readonly float BigFive;      // default 0.70
            public readonly float Morality;     // default 0.20
            public readonly float SocialEnergy; // default 0.10

            // jemné váhy uvnitř Big Five (normalizace uvnitř funkce)
            public readonly float W_Agreeableness;      // default 1.00
            public readonly float W_Conscientiousness;  // default 0.90
            public readonly float W_Extraversion;       // default 0.80
            public readonly float W_Openness;           // default 0.85
            public readonly float W_Neuroticism;        // default 1.10  (přepočítá se na „emoc. stabilitu“)

            public CompatibilityWeights(
                float bigFive = 0.70f,
                float morality = 0.20f,
                float socialEnergy = 0.10f,
                float wA = 1.00f,
                float wC = 0.90f,
                float wE = 0.80f,
                float wO = 0.85f,
                float wN = 1.10f)
            {
                BigFive = bigFive;
                Morality = morality;
                SocialEnergy = socialEnergy;
                W_Agreeableness = wA;
                W_Conscientiousness = wC;
                W_Extraversion = wE;
                W_Openness = wO;
                W_Neuroticism = wN;
            }

            public static CompatibilityWeights Default => new();
        }

        // ---------------------------
        // 1) Big Five → podobnost 0..1
        // ---------------------------

        /// <summary>
        /// Kompatibilita čistě podle Big Five (0..1). Neuroticism je transformován na „emoc. stabilitu“ (1-N).
        /// </summary>
        public static float CalculateCompatibility(
            IDictionary<BigFiveTrait, double> a,
            IDictionary<BigFiveTrait, double> b,
            CompatibilityWeights? weights = null)
        {
            var w = weights ?? CompatibilityWeights.Default;

            // vytáhni rysy 0..1 (případně si zde uprav přístup, pokud indexuješ jinak)
            float AgrA = (float)a[BigFiveTrait.Agreeableness];
            float ConA = (float)a[BigFiveTrait.Conscientiousness];
            float ExtA = (float)a[BigFiveTrait.Extraversion];
            float OpnA = (float)a[BigFiveTrait.Openness];
            float NeuA = (float)a[BigFiveTrait.Neuroticism];

            float AgrB = (float)b[BigFiveTrait.Agreeableness];
            float ConB = (float)b[BigFiveTrait.Conscientiousness];
            float ExtB = (float)b[BigFiveTrait.Extraversion];
            float OpnB = (float)b[BigFiveTrait.Openness];
            float NeuB = (float)b[BigFiveTrait.Neuroticism];

            // Neuroticism → stabilita
            float StabA = 1f - NeuA;
            float StabB = 1f - NeuB;

            // podobnosti po osách (L1)
            float sAgr = Similarity01(AgrA, AgrB);
            float sCon = Similarity01(ConA, ConB);
            float sExt = Similarity01(ExtA, ExtB);
            float sOpn = Similarity01(OpnA, OpnB);
            float sStb = Similarity01(StabA, StabB);

            // normalizované váhy uvnitř Big Five
            float sum = w.W_Agreeableness + w.W_Conscientiousness + w.W_Extraversion + w.W_Openness + w.W_Neuroticism;
            if (sum <= 1e-6f) sum = 1f;

            float bigFiveSim =
                (w.W_Agreeableness * sAgr +
                 w.W_Conscientiousness * sCon +
                 w.W_Extraversion * sExt +
                 w.W_Openness * sOpn +
                 w.W_Neuroticism * sStb) / sum;

            // jemné zklidnění extrémů (gamma)
            bigFiveSim = PowSafe(bigFiveSim, 0.90f);
            return Clamp01(bigFiveSim);
        }

        // ------------------------------------------------
        // 2) IHuman → Big Five + Morálka + Sociální energie
        // ------------------------------------------------

        public static float CalculateCompatibility(IHuman A, IHuman B)
        {
            // Big Five podobnost (0..1) – použij svoji existující funkci nad dictionary:
            float big = CalculateCompatibility(A.Personality.BigFive, B.Personality.BigFive);

            // Morální podobnost z MoralProfile.Scores:
            float moral = MoralAlignment01(A, B); // viz níže

            // „Sociální energie“ jako podobnost SocialDrive:
            float seA = (float)(A.Psychology?.SocialDrive ?? 0.5);
            float seB = (float)(B.Psychology?.SocialDrive ?? 0.5);
            float energySim = 1f - MathF.Abs(seA - seB);

            // Směs (klidné defaulty):
            return Math.Clamp(0.70f * big + 0.20f * moral + 0.10f * energySim, 0f, 1f);
        }

        public static float MoralAlignment01(IHuman A, IHuman B)
        {
            var a = A.Personality?.Morality?.Scores;
            var b = B.Personality?.Morality?.Scores;
            if (a == null || b == null || a.Count == 0) return 0.5f;

            float sum = 0f; int n = 0;
            foreach (var dim in a.Keys)
            {
                if (b.TryGetValue(dim, out var vb)) { sum += MathF.Abs((float)a[dim] - (float)vb); n++; }
            }
            return n > 0 ? 1f - (sum / n) : 0.5f;
        }




        // ---------------------------
        // Helpers (lokální, čisté)
        // ---------------------------

        private static float Similarity01(float x01, float y01)
        {
            if (!float.IsFinite(x01)) x01 = 0.5f;
            if (!float.IsFinite(y01)) y01 = 0.5f;
            x01 = Clamp01(x01); y01 = Clamp01(y01);
            return 1f - MathF.Abs(x01 - y01); // L1
        }

        private static float PowSafe(float x, float gamma) => MathF.Pow(Clamp01(x), gamma);

        private static float Clamp01(float v) => Math.Clamp(v, 0f, 1f);

        /// <summary>
        /// Kontexťák z fyzio/psyche (0..100). Vstupy si vytáhni z vlastních modelů.
        /// </summary>
        /// <param name="energy"></param>
        /// <param name="stress"></param>
        /// <param name="mood"></param>
        /// <returns></returns>
        public static float ContextMultiplier(float energy, float stress, float mood /* -50..+50 nebo 0..100? */)
        {
            // Příklad: energy a mood 0..100, mood přemapujeme na -50..+50, stress 0..100
            float e = Math.Clamp(energy / 100f, 0.5f, 1.1f);
            float s = Lerp(1.1f, 0.7f, Math.Clamp(stress / 100f, 0f, 1f));
            float m = Lerp(0.8f, 1.2f, Math.Clamp((mood + 50f) / 100f, 0f, 1f));
            return e * s * m;
        }

        public static (float p, float s) CrossLagCouple(float p, float s, float kappaPerDay, float deadband, float trustGate01, float dtDays)
        {
            float diff = s - p;
            if (MathF.Abs(diff) <= deadband && trustGate01 > 0.4f)
            {
                float k = MathF.Max(0f, kappaPerDay) * dtDays * trustGate01; // velmi malé (třeba 0.002)
                p += k * diff;
                s -= k * diff;
            }
            return (p, s);
        }

        public static float DeadbandEma(float value, float target, float halfLifeDays, float deadband, float dtDays)
        {
            float diff = target - value;
            if (MathF.Abs(diff) < deadband) return value; // držet „plateau“
            float k = 1f - MathF.Pow(2f, -dtDays / MathF.Max(halfLifeDays, 0.0001f));
            return value + k * diff;
        }

        /// <summary>
        /// Čistý rozpad bez baseline (např. na vnitřní "odchylkové" paměti)
        /// </summary>
        /// <param name="value"></param>
        /// <param name="dtDays"></param>
        /// <param name="halfLifeDays"></param>
        /// <returns></returns>
        public static float Decay(float value, float dtDays, float halfLifeDays)
        {
            if (halfLifeDays <= 0f) return 0f;
            return value * (float)Math.Pow(0.5, dtDays / halfLifeDays);
        }

        public static float DecayLogTowards(float x, float dtDays, float lambdaPerDay, float target = 0f, float softness = 30f)
        {
            // Měníme „vzdálenost k cíli“ (|x - target|) v log-prostoru a pak ji mapujeme zpět.
            // softness: větší číslo = pomalejší úbytek daleko od cíle (20–60 typicky).
            if (dtDays <= 0f || lambdaPerDay <= 0f) return x;

            float keep = (float)Math.Exp(-lambdaPerDay * dtDays);

            float d = x - target;                  // vzdálenost k cíli (se znaménkem)
            float s = MathF.Max(1e-3f, softness);  // „měkkost“ log mapy
            float y = MathF.Log(1f + MathF.Abs(d) / s);
            float y2 = y * keep;
            float newAbs = s * (MathF.Exp(y2) - 1f);

            return target + MathF.Sign(d) * newAbs;
        }

        // ---------- Hladké EMA pro rozhodování stage / prahů ----------
        public static float EmaStep(float ema, float sample, float holdDays)
        {
            float a = 1f / Math.Max(1f, holdDays); // jednoduché EMA: t=1/holdDays
            return Lerp(ema, sample, a);
        }

        /// <summary>
        /// Negativní afekt po „kyselé“ události (např. insult < 3 dny)
        /// </summary>
        public static float GateByAversive(float mult, float daysSince)
        {
            if (daysSince <= 0f) return 0f;
            // ease-in k 1.0 ~ za 14 dní
            float k = 1f - MathF.Exp(-daysSince / 5f);
            return mult * Math.Clamp(k, 0, 1);
        }

        // ---------- Kontexťáky / brány účinnosti ----------
        /// <summary>
        /// Bez důvěry se špatně flirtuje apod. (Trust ~ 0..100)
        /// </summary>
        /// <param name="baseGain"></param>
        /// <param name="trust"></param>
        /// <returns></returns>
        public static float GateByTrust(float baseGain, float trust)
            //=> baseGain * Math.Clamp(trust / 50f, 0.5f, 1.2f);
            => baseGain * Math.Clamp(0.5f + trust / 100f, 0.5f, 1.2f);

        // Hystereze: vyhodnocení „nad prahem / pod prahem“ s pásmem ±band
        public static bool Hysteresis(bool wasOn, float value, float threshold, float band)
        {
            float hi = threshold + Math.Max(0f, band);
            float lo = threshold - Math.Max(0f, band);
            if (wasOn) return value > lo; // zůstávej zapnuto, dokud neklesne pod lo
            else return value > hi; // zapni až nad hi
        }

        /// <summary>
        /// Gauss šum (Box–Muller). Použij pro drobnou „živost“.
        /// </summary>
        /// <param name="rng"></param>
        /// <param name="amplitude"></param>
        /// <returns></returns>
        public static float Jitter(Random rng, float amplitude = 0.4f)
        {
            float u1 = 1f - (float)rng.NextDouble();
            float u2 = 1f - (float)rng.NextDouble();
            float z = (float)Math.Sqrt(-2f * Math.Log(u1)) * (float)Math.Cos(2f * Math.PI * u2);
            return amplitude * z;
        }

        /// <summary>
        /// λ z half-life (dny) – hodí se, když bys chtěl modelovat spojitě
        /// </summary>
        /// <param name="halfLifeDays"></param>
        /// <returns></returns>
        public static float LambdaFromHalfLife(float halfLifeDays)
            => (float)(Math.Log(2.0) / Math.Max(halfLifeDays, 1e-6));

        // ---------- Základní utility ----------
        public static float Lerp(float a, float b, float t) => a + (b - a) * Math.Clamp(t, 0f, 1f);

        /// <summary>
        /// Morální shoda: porovná alignment / hodnoty
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <returns></returns>
        public static float MoralAlignmentFactor(IHuman from, IHuman to)
        {
            if (from.Personality?.Morality == null || to.Personality?.Morality == null)
                return 1f; // fallback, když chybí profil

            double sum = 0;
            int count = 0;

            foreach (MoralDimension dim in Enum.GetValues(typeof(MoralDimension)))
            {
                double a = from.Personality.Morality[dim];
                double b = to.Personality.Morality[dim];
                // čím menší rozdíl, tím vyšší faktor
                sum += 1.0 - Math.Abs(a - b); // 1 = stejné hodnoty, 0 = úplně opačné
                count++;
            }

            return (float)(sum / count); // průměr 0–1
        }

        /// <summary>
        /// Penalizace opakování stejného typu akce v krátkém horizontu
        /// </summary>
        /// <param name="repeatIndex"></param>
        /// <param name="beta"></param>
        /// <returns></returns>
        public static float NoveltyMultiplier(int repeatIndex, float beta = 0.35f)
            => 1f / (1f + beta * Math.Max(0, repeatIndex - 1));

        /// <summary>
        /// Měkký strop – konkávní saturace místo tvrdého clampu
        /// </summary>
        /// <param name="x"></param>
        /// <param name="cap"></param>
        /// <param name="sharp"></param>
        /// <returns></returns>
        public static float SoftCap(float x, float cap = 100f, float sharp = 0.02f)
            => cap - (cap * (float)Math.Exp(-sharp * Math.Max(0f, x)));

        public static float SoftFloor(float x, float min, float softness)
        {
            // hladká aproximace dna: min + softness * log(1 + exp((x - min)/softness))
            // pro x<<min se přibližuje min, ale gradient nezmizí
            return min + softness * (float)Math.Log(1.0 + Math.Exp((x - min) / softness));
        }

        /// <summary>
        /// Měkké dorovnávání symetrie (A↔B). inertia ~ 0.90f = 10% přitažení za tick
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="inertia"></param>
        public static void SoftSymmetry(ref float a, ref float b, float inertia = 0.90f)
        {
            float gamma = 1f - Math.Clamp(inertia, 0f, 1f);
            float mean = 0.5f * (a + b);
            a += gamma * (mean - a);
            b += gamma * (mean - b);
        }

        /// <summary>
        /// S-křivka pro agregovaný „SpendTime“ efekt (škáluj výstup dle potřeby)
        /// </summary>
        /// <param name="hours"></param>
        /// <param name="k"></param>
        /// <param name="maxEff"></param>
        /// <param name="hardCapH"></param>
        /// <returns></returns>
        public static float SpendTimeDelta(float hours, float k = 1.4f, float maxEff = 10f, float hardCapH = 5f)
            => maxEff * (1f - (float)Math.Exp(-k * Math.Min(Math.Max(0f, hours), hardCapH)));

        /// <summary>
        /// Marginal gain podle času spolu (první hodiny nejvíc, pak saturace)
        /// </summary>
        /// <param name="hours"></param>
        /// <param name="cap"></param>
        /// <returns></returns>
        public static float SpendTimeMarginalGain(float hours, float cap = 2f)
            => (float)(1.0 - Math.Exp(-Math.Max(0f, hours) / Math.Max(0.1f, cap)));

        public static float StageGainFactor(int stageLevel) => stageLevel switch
        {
            0 => 0.6f,
            1 => 0.85f,
            2 => 1.00f,
            3 => 1.10f,
            _ => 1.00f
        };

        // ---------- Stage/hloubka vazby → multiplikátory ----------
        /// <summary>
        /// Pokud máš enum Stage, namapuj si ho na "level" 0..3 (Stranger..Intimate) a použij tyto faktory:
        /// </summary>
        /// <param name="stageLevel"></param>
        /// <returns></returns>
        public static float StageHalfLifeFactor(int stageLevel) => stageLevel switch
        {
            0 => 0.8f, // Stranger
            1 => 1f, // Familiar
            2 => 1.20f, // Friend
            3 => 1.5f, // Intimate
            _ => 1.00f
        };

        /// <summary>
        /// Rozpad směrem k baseline přes half-life
        /// </summary>
        /// <param name="value"></param>
        /// <param name="baseline"></param>
        /// <param name="dtDays"></param>
        /// <param name="halfLifeDays"></param>
        /// <returns></returns>
        public static float StepHalfLife(float value, float baseline, float dtDays, float halfLifeDays)
        {
            if (halfLifeDays <= 0f) return baseline;
            float k = (float)Math.Pow(0.5, dtDays / halfLifeDays);
            return baseline + (value - baseline) * k;
        }

        public static bool TryRupture(float trust, float negSeverity, out float likeDrop, out float attachDrop, out int lockoutDays)
        {
            float threshold = 0.55f * trust + 0.25f;    // čím větší důvěra, tím vyšší práh – ale když ho překonáš, bolí to
            if (negSeverity >= threshold)
            {
                likeDrop = 30f + 50f * negSeverity;  // -30 až -80
                attachDrop = 25f + 40f * negSeverity;  // -25 až -65
                lockoutDays = 14 + (int)(90f * negSeverity); // 2–~100 dní nižší citlivost na pozitiva
                return true;
            }

            likeDrop = attachDrop = 0f; lockoutDays = 0;
            return false;
        }

        /// <summary>
        /// ---------- Dvourychlostní paměť („fast/slow trace“) ----------
        /// </summary>
        // Drž „odchylku“ od baseline v rychlé a pomalé stopě, hodnotu počítej jako mix.
        public struct TwoTrace
        {
            public float Fast;   // krátkodobý otisk (rychle nabývá, rychle mizí)
            public float Slow;   // dlouhodobý otisk (pomalý růst, dlouhá paměť)

            // Rozpad obou stop half-lifem (dny)
            public void Decay(float dtDays, float hlFast = 7f, float hlSlow = 120f)
            {
                Fast = RelationshipMath.Decay(Fast, dtDays, hlFast);
                Slow = RelationshipMath.Decay(Slow, dtDays, hlSlow);
            }

            // Zápis události (delta je „čistý“ přírůstek, klidně už vynásobený kontextem/novelty)
            public void Kick(float delta, float alphaFast = 1.0f, float alphaSlow = 0.15f)
            {
                Fast += alphaFast * delta;
                Slow += alphaSlow * delta;
            }

            public float Value(float baseline, float wFast = 0.4f, float wSlow = 0.6f)
                                        => baseline + wFast * Fast + wSlow * Slow;
        }
    }

    public static class RelationshipTools
    {
        public static float GetInteractionMagnitude(InteractionType interaction)
        {
            return interaction switch
            {
                InteractionType.None => 0f,

                // prosociální / spolupráce
                InteractionType.Help => 12.5f,
                InteractionType.Gift => 8.3f,
                InteractionType.Honesty => 14.2f,
                InteractionType.Cooperation => 18.7f,
                InteractionType.Encourage => 15.6f,
                InteractionType.SharedActivity => 21.5f,
                InteractionType.SpendTime => 16.8f,
                InteractionType.SingTogether => 18.3f,
                InteractionType.PrayTogether => 17.4f,
                InteractionType.Conversation => 11.4f,
                InteractionType.Talk => 7.9f,
                InteractionType.SmallTalk => 3.2f,
                InteractionType.Generic => 4.1f,

                // repair
                InteractionType.Apology => 9.9f,
                InteractionType.MakeAmends => 13.7f,
                InteractionType.Aftercare => 16.0f,

                // romance / fyzické
                InteractionType.Compliment => 6.7f,
                InteractionType.Flirt => 20.3f,
                InteractionType.Touch => 24.2f,
                InteractionType.Kiss => 33.8f,
                InteractionType.Sex => 47.8f,

                // negativní
                InteractionType.Argument => -11.2f,
                InteractionType.Insult => -15.4f,
                InteractionType.Lie => -22.1f,
                InteractionType.NoShow => -19.4f,
                InteractionType.Breach => -27.9f,
                InteractionType.Aggression => -38.9f,
                InteractionType.Attack => -46.9f,
                InteractionType.Betrayal => -45.6f,

                _ => 0f
            };
        }

        internal static BondStage ProposeStageFromAxes(Relationship relationship, BondStageVector bondStageVector)
        {
            var axes = bondStageVector.Axes;

            var q = from a in axes
                    where relationship.Closeness >= a.Value.ClosenessMin &&
                    relationship.Liking >= a.Value.LikingMin &&
                    relationship.Trust >= a.Value.TrustMin
                    select a.Key;
            return q.Any() ? q.Max() : BondStage.Stranger;
        }
    }

    // ---------- Reciprocity ledger pro dvojici A↔B ----------
    // Metrika „fairness“: boost gainu, když druhý nedávno pomáhal víc než já (a naopak).
    public sealed class ReciprocityLedger
    {
        private readonly List<WDateTime> _myHelps = new();
        private readonly WTimeSpan _window;
        private readonly List<WDateTime> _yourHelps = new();

        private void Prune(List<WDateTime> list, WDateTime now)
        {
            int idx = 0;
            while (idx < list.Count && now - list[idx] > _window) idx++;
            if (idx > 0) list.RemoveRange(0, idx);
        }

        public ReciprocityLedger(int windowDays = 14) => _window = WTimeSpan.FromDays(Math.Max(1, windowDays));

        public float Boost(WDateTime now, float posCoef = 0.05f, float negCoef = 0.08f)
        {
            var snap = Snapshot(now);
            return snap.balance >= 0
                ? 1f + posCoef * snap.balance
                : 1f / (1f + negCoef * (-snap.balance));
        }

        public void NoteMyHelp(WDateTime when) => _myHelps.Add(when);

        public void NoteYourHelp(WDateTime when) => _yourHelps.Add(when);

        public float Resentment(WDateTime now, float horizonDays = 21f)
        {
            var snap = Snapshot(now);
            // když já pomáhám výrazně víc (balance << 0), roste „zášť“
            int deficit = Math.Max(0, snap.mine - snap.yours);
            float x = Math.Clamp(deficit / (horizonDays * 0.3f), 0f, 1f); // ~měkké škálování
            return 0.05f * x; // 0..0.05
        }

        public (int mine, int yours, int balance) Snapshot(WDateTime now)
        {
            Prune(_myHelps, now); Prune(_yourHelps, now);
            int mine = _myHelps.Count, yours = _yourHelps.Count;
            return (mine, yours, yours - mine);
        }
    }

    // ---------- Rolling log pro novelty / počty v okně ----------
    // Použij pro "kolikrát se stalo X (Compliment, Flirt...) za posledních N dní?"
    public sealed class RollingCounter<TKey> where TKey : notnull
    {
        private readonly Dictionary<TKey, List<WDateTime>> _logs = new();
        private readonly WTimeSpan _window;

        private void Prune(List<WDateTime> list, WDateTime now)
        {
            int idx = 0;
            while (idx < list.Count && now - list[idx] > _window) idx++;
            if (idx > 0) list.RemoveRange(0, idx);
        }

        public RollingCounter(int windowDays = 7) => _window = WTimeSpan.FromDays(Math.Max(1, windowDays));

        public int Count(TKey key, WDateTime now)
        {
            if (!_logs.TryGetValue(key, out var list)) return 0;
            Prune(list, now);
            return list.Count;
        }

        public int CountSince(TKey key, WDateTime since)
        {
            if (!_logs.TryGetValue(key, out var list)) return 0;
            int c = 0;
            for (int i = list.Count - 1; i >= 0; --i)
            {
                if (list[i] >= since) c++; else break; // předpoklad: appendujeme v čase
            }
            return c;
        }

        public void Note(TKey key, WDateTime when)
        {
            if (!_logs.TryGetValue(key, out var list))
                _logs[key] = list = new List<WDateTime>(4);
            list.Add(when);
            Prune(list, when);
        }
    }
}
