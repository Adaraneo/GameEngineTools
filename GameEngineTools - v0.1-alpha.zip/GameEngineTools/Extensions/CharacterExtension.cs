﻿// CharacterExtension.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Extensions
{
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.Homo;

    public static class HumanPhysiologyExtensions
    {
        /// <summary>
        /// Computes a normalized "Energy" score (0..100) from vital signs.
        /// 100 = plná energie, 0 = vyčerpání.
        /// </summary>
        public static double ComputeEnergy(this VitalSigns v)
        {
            // Hydratace a kyslík jsou kritické → váha vysoká
            double hydration = v.Hydration;            // 0..1
            double oxygen = v.OxygenSaturation;        // 0..1

            // Tepová frekvence – optimum kolem 60–100 bpm
            double hr = 1.0 - Math.Min(Math.Abs(v.HeartRate - 80) / 100.0, 1.0);

            // Teplota – optimum kolem 36.6 °C ±0.5
            double temp = 1.0 - Math.Min(Math.Abs(v.Temperature - 36.6) / 2.0, 1.0);

            // Respirační frekvence – optimum kolem 12–20
            double resp = 1.0 - Math.Min(Math.Abs(v.RespirationRate - 16) / 20.0, 1.0);

            // Složený průměr (vážený)
            double raw = (hydration * 0.30 + oxygen * 0.25 + hr * 0.20 + temp * 0.15 + resp * 0.10);

            return Math.Clamp(raw * 100.0, 0.0, 100.0);
        }
    }

    public static class CharacterExtension
    {
        public static Person FindByDNA(this IEnumerable<Person> people, Guid dna)
        {
            foreach (var person in people)
            {
                if (person.Body.DNA == dna)
                {
                    return person;
                }
            }
            throw new Exception("No person was found!");
        }

        public static string ToString(this Surname surname, GenusType genus)
        {
            if (genus == GenusType.Male)
            {
                return surname.Male;
            }
            else
            {
                return surname.Female;
            }
        }
    }
}
