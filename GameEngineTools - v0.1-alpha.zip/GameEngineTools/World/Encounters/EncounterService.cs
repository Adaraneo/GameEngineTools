﻿// EncounterService.cs
// Copyright (c) 50PSoftware

using GameEngineTools.Characters.CharacterModel.Behavior;
using GameEngineTools.Characters.CharacterModel.Homo;
using GameEngineTools.Characters.CharacterModel.Relationships;
using GameEngineTools.World.Utils.Time;

namespace GameEngineTools.World.Encounters
{
    /// <summary>
    /// Minimální rozhraní na svět a místa – přizpůsob si na své typy
    /// </summary>
    public interface IPlaceLite
    {
        PlaceArchetype Archetype { get; }
        int CapacityHint { get; }
        Guid Id { get; }

        // 8, 12, 50… (jen heuristika)
        bool IsTransit { get; }      // chodby, foyer

        // Když máš vlastní API, přidej, co potřebuješ (IsQuiet, IsWork apod.)
    }

    public interface IWorldPresenceProvider
    {
        /// <summary>
        /// Vrať denní přítomnosti všech postav (např. z kalendáře, směn, rutin)
        /// </summary>
        /// <param name="dayStartUtc"></param>
        /// <param name="dayEndUtc"></param>
        /// <returns></returns>
        IEnumerable<PresenceSegment> BuildPresence(WDateTime dayStartUtc, WDateTime dayEndUtc);

        IPlaceLite GetPlace(Guid placeId);
    }

    public sealed class EncounterService
    {
        private readonly IWorldPresenceProvider _presence;
        private readonly IRelationshipSnapshotProvider _relView;
        private readonly Random _rng;

        private static double AffinityBoost(RelationshipSnapshotForBehavior? rel)
        {
            if (!rel.HasValue) return 1.0;
            var r = rel.Value;
            // liking/closeness přidají trochu šance
            double likeF = 0.8 + 0.6 * (r.Liking / 100.0);
            double closeF = 0.8 + 0.6 * (r.Closeness / 100.0);
            return likeF * closeF * 0.9 + 0.1; // jemně stlačeno
        }

        private static double BaseHitProbability(PlaceProfile p, int occupants, WTimeSpan blockDuration)
        {
            // čím soukromější a menší skupina, tím vyšší šance, že vznikne konkrétní párová interakce
            double crowd = Math.Clamp(occupants / 8.0, 0.0, 1.5); // hrubá saturace
            double baseP = 0.25 + 0.35 * p.BasePrivacy + 0.15 * p.BaseSharedGoal - 0.20 * crowd;
            double durF = Math.Clamp(blockDuration.TotalMinutes / 30.0, 0.4, 1.2);
            return Math.Clamp(baseP * durF, 0.05, 0.85);
        }

        // --- Utils ---
        private static WDateTime RoundDown(WDateTime dt, int minutes)
            => dt.AddTicks(-(dt.WorldTicks % WTimeSpan.FromMinutes(minutes).Ticks));

        private IEnumerable<SceneBlock> BuildSceneBlocks(List<PresenceSegment> segs, int blockMinutes)
        {
            var blocks = new List<SceneBlock>();
            if (segs.Count == 0) return blocks;

            // Vytvoříme časové sloty a pro každý placeId plníme účastníky
            WDateTime minT = segs.Min(s => s.Start);
            WDateTime maxT = segs.Max(s => s.End);
            if (blockMinutes < 10) blockMinutes = 10;

            for (var t = RoundDown(minT, blockMinutes); t < maxT; t = t.AddMinutes(blockMinutes))
            {
                var t2 = t.AddMinutes(blockMinutes);
                var byPlace = segs.Where(s => s.Overlaps(t, t2))
                                  .GroupBy(s => s.PlaceId);
                foreach (var grp in byPlace)
                {
                    int cap = grp.First().CapacityHint;
                    var people = grp.Select(s => s.Human).Distinct().ToList();
                    if (people.Count == 0) continue;
                    blocks.Add(new SceneBlock(grp.Key, t, t2, cap, people));
                }
            }

            return blocks;
        }

        private IEnumerable<Encounter> BuildTransitEncounters(List<PresenceSegment> segs, WDateTime dayStart, WDateTime dayEnd)
        {
            // kde se dvě osoby krátce „míjí“ v čase okolo změny místa
            // jednoduché: pro každého aktéra vezmeme konec jednoho segmentu a začátek dalšího
            var byHuman = segs.GroupBy(s => s.Human.DNA);
            foreach (var g in byHuman)
            {
                var ordered = g.OrderBy(s => s.Start).ToList();
                for (int i = 0; i < ordered.Count - 1; i++)
                {
                    var leave = ordered[i].End;
                    var nextStart = ordered[i + 1].Start;
                    // krátká mezera? užitečné pro chodbu
                    if ((nextStart - leave).TotalMinutes is > -5 and < 15)
                    {
                        // vyber náhodně někoho dalšího, kdo má v tom čase také „přechod“
                        var others = segs.Where(s => s.Human.DNA != g.Key && Math.Abs((s.Start - leave).TotalMinutes) < 10).ToList();
                        if (others.Count == 0 || _rng.NextDouble() > 0.25) continue;

                        var other = others[_rng.Next(others.Count)];
                        yield return new Encounter
                        {
                            A = ordered[i].Human,
                            B = other.Human,
                            When = leave.AddMinutes(_rng.Next(-3, 4)),
                            Situation = SituationType.ChanceEncounter,
                            Ix = new InteractionContext { Privacy = 0.15f, SocialAudience = 0.5f, Depth = 0.1f, Risk = 0.05f, SharedGoal = 0.05f, Physicality = 0f, Continuity = 0.2f, EmotionalTone = 0f }
                        };
                    }
                }
            }
        }

        private IEnumerable<(IHuman A, IHuman B)> PairSample(List<IHuman> people, int targetPairs)
        {
            // náhodně mírně biasuj ke známějším dyadikám (vyšší šance opakovaně se bavit)
            var allPairs = new List<(IHuman, IHuman)>();
            for (int i = 0; i < people.Count; i++)
                for (int j = i + 1; j < people.Count; j++)
                    allPairs.Add((people[i], people[j]));

            // malý shuffle
            for (int i = allPairs.Count - 1; i > 0; i--)
            {
                int k = _rng.Next(i + 1);
                (allPairs[i], allPairs[k]) = (allPairs[k], allPairs[i]);
            }

            return allPairs.Take(targetPairs);
        }

        // --- Scény ---
        // --- Párování ---
        // --- Pravděpodobnosti ---
        // --- Transit encounters ---
        private WDateTime RandTime(WDateTime a, WDateTime b)
        {
            var span = b - a;
            var r = _rng.NextDouble();
            return a + WTimeSpan.FromSeconds(span.TotalSeconds * r);
        }

        public EncounterService(IWorldPresenceProvider presence, IRelationshipSnapshotProvider relView, int? seed = null)
        {
            _presence = presence;
            _relView = relView;
            _rng = seed.HasValue ? new Random(seed.Value) : new Random();
        }

        public IEnumerable<Encounter> BuildEncountersForDay(WDateTime dayStartUtc)
        {
            var dayEnd = dayStartUtc.AddDays(1);
            var segments = _presence.BuildPresence(dayStartUtc, dayEnd).ToList();

            // 1) Zsegmentuj čas po blocích (např. 30 min) a seskup per (Place, TimeBlock)
            var blocks = BuildSceneBlocks(segments, blockMinutes: 30);

            // 2) Z každého SceneBlocku vyber pravděpodobné páry
            foreach (var block in blocks)
            {
                var place = _presence.GetPlace(block.PlaceId);
                var prof = EncounterProfiles.Profiles[place.Archetype];

                if (block.OccupantCount < 2) continue;

                // Kolik interakcí z tohoto bloku maximálně generovat?
                int targetPairs = Math.Clamp(block.OccupantCount - 1, 1, 6);

                // Vytvoř kandidát páry (kombinace), ale omez náhodným samplingem
                var pairs = PairSample(block.Participants, targetPairs);

                foreach (var (a, b) in pairs)
                {
                    // Relace A↔B ovlivní situaci a baseline hloubku
                    var relAB = _relView.TryGet(a, b);
                    var relBA = _relView.TryGet(b, a);

                    // Heuristika: pravděpodobnost, že si v tomto bloku skutečně "šáhnou" (projeví se encounterem)
                    double pHit = BaseHitProbability(prof, block.OccupantCount, block.Duration) * AffinityBoost(relAB);

                    if (_rng.NextDouble() > pHit) continue;

                    // Postav InteractionContext z profilu a crowding
                    var ix = EncounterProfiles.BuildIx(prof, block.OccupantCount, Math.Max(2, place.CapacityHint));

                    // Vymyšlíme Situation
                    var sit = EncounterProfiles.ClassifySituation(prof, block.OccupantCount, isTransit: place.IsTransit, (relAB.GetValueOrDefault(), relBA.GetValueOrDefault()));

                    // Vyber čas někde uprostřed bloku
                    var when = RandTime(block.Start, block.End);

                    yield return new Encounter
                    {
                        A = a,
                        B = b,
                        Situation = sit,
                        Ix = ix,
                        When = when
                    };
                }
            }

            // 3) BONUS: transit encounters (na přechodech segmentů) – krátké šance potkat se v chodbě
            foreach (var e in BuildTransitEncounters(segments, dayStartUtc, dayEnd))
                yield return e;
        }
    }
}
