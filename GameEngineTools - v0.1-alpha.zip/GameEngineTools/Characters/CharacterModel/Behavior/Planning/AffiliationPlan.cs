﻿// AffiliationPlan.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Planning
{
    public sealed class AffiliationPlan : IBehaviorPlan
    {
        private int _i;
        private static readonly BehaviorType[] Seq =
            { BehaviorType.AskOpenQuestion, BehaviorType.ComplimentLight, BehaviorType.SuggestSharedActivity, BehaviorType.CheckIn };

        public string Name => "Affiliation";

        public bool CanStart(BehaviorContext ctx)
            => ctx.Target is not null
               && !(ctx.Rel?.HasActiveConflict ?? false)
               && ctx.Goals.AffiliationNeed01 >= 0.55f;

        public PlanStatus Tick(BehaviorContext ctx, Func<BehaviorType, BehaviorContext, bool> enact)
        {
            while (_i < Seq.Length)
            {
                if (!enact(Seq[_i], ctx)) return PlanStatus.Failed;
                _i++;
            }
            return PlanStatus.Succeeded;
        }
    }
}

