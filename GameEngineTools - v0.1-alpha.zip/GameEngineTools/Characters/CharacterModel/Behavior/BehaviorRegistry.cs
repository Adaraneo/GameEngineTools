﻿// BehaviorRegistry.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior
{
    using System.Collections.Generic;
    using GameEngineTools.Characters.CharacterModel.Behavior.Options;

    public static class BehaviorRegistry
    {
        /// Základní sada – můžeš přidávat/ubírat dle potřeby.
        public static readonly List<IBehaviorOption> Default = new()
        {
            new PoliteNod(),
            new AskOpenQuestion(),
            new ComplimentLight(),
            new Withdraw(),
            new SetBoundary(),
            new OfferHelp(),
            new Apologize(),
            new HonestDisclosureLight(),
            new FlirtLight(),
            new FlirtBold(),
            new AcknowledgePraise(),
            new DeescalateConflict(),
            new Retort(),
            new RefuseHelp(),
            new ReturnCompliment(),
            new ModestDownplay(),
            new DeferReply(),
            new ChangeTopic(),
            new CheckIn(),
            new InviteSharedActivity(),
            new DeflectQuestion(),
            new GracefulExit()
        };

        public static readonly List<IBehaviorOption> Extended = Default.Concat(new IBehaviorOption[]
        {
            new InsultDirect(),
            new UndermineInPublic(),
            new LieWhite(),
            new BreakPromise(),
            new InitiateIntimacySoft(),
            new InitiateIntimacyBold(),
            new AskForConsent(),
            new AftercareCuddle(),
            new AskForConsentHard(),
            new Kiss(),
            new KissLight(),
            new SelfDisclosureDeep(),
            new AskForPersonalDisclosureDeep()
        }).ToList();
    }
}
