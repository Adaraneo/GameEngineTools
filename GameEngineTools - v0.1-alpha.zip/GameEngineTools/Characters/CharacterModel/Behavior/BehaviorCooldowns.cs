﻿// BehaviorCooldowns.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior
{
    using System;
    using System.Collections.Generic;
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;
    using GameEngineTools.World.Utils.Time;

    /// Jednoduché cooldowny per (actorId, targetId, behaviorType).
    public sealed class BehaviorCooldowns
    {
        // === Category-level cooldown (InteractionType) ===============================
        private readonly Dictionary<(Guid actor, Guid? target, InteractionType cat), (WDateTime until, int streak)> _cat = new();

        // === No-immediate-repeat guard (minimální odstup mezi dvěma stejnými kategoriemi) ===
        private readonly Dictionary<(Guid actor, Guid? target), (InteractionType last, WDateTime until)> _lastCat = new();

        private readonly Dictionary<(IHuman actor, IHuman? target, BehaviorType type), (WDateTime until, int streak)> _state = new();
        private readonly Dictionary<(Guid actor, Guid? target, BehaviorType type), WDateTime> _until = new();

        public void Bump(IHuman actor, IHuman? target, BehaviorType type, WTimeSpan baseDuration, WDateTime now)
        {
            var key = (actor, target, type);
            _state.TryGetValue(key, out var cur);
            int streak = (cur.until > now) ? cur.streak + 1 : 1;
            double mult = Math.Min(3.0, 1.0 + 0.5 * (streak - 1)); // 1.0×, 1.5×, 2.0×, 2.5×…
            var dur = WTimeSpan.FromTicks((long)(baseDuration.Ticks * mult));
            _state[key] = (now + dur, streak);
        }

        // Volání jako u typů – s kumulací při spamu stejné kategorie
        public void BumpCategory(IHuman actor, IHuman? target, InteractionType cat, WTimeSpan baseDuration, WDateTime now)
        {
            var key = (actor.DNA, target?.DNA, cat);
            _cat.TryGetValue(key, out var cur);
            int streak = (cur.until > now) ? cur.streak + 1 : 1;
            double mult = Math.Min(3.0, 1.0 + 0.5 * (streak - 1)); // 1.0×, 1.5×, 2.0×, ...
            var dur = WTimeSpan.FromTicks((long)(baseDuration.Ticks * mult));
            _cat[key] = (now + dur, streak);
        }

        public bool IsImmediateRepeat(IHuman actor, IHuman? target, InteractionType cat, WDateTime now)
        {
            if (!_lastCat.TryGetValue((actor.DNA, target?.DNA), out var t)) return false;
            return t.last == cat && now < t.until;
        }

        public bool IsOnCategoryCooldown(IHuman actor, IHuman? target, InteractionType cat, WDateTime now)
            => _cat.TryGetValue((actor.DNA, target?.DNA, cat), out var until) && now < until.until;

        public bool IsOnCooldown(Guid actor, Guid? target, BehaviorType type, WDateTime nowUtc)
        {
            return _until.TryGetValue((actor, target, type), out var until) && nowUtc < until;
        }

        public new bool IsOnCooldown(IHuman actor, IHuman? target, BehaviorType type, WDateTime now)
        {
            return _state.TryGetValue((actor, target, type), out var until) && now < until.until;
        }

        public void MarkLastCategory(IHuman actor, IHuman? target, InteractionType cat, WTimeSpan minSeparation, WDateTime now)
            => _lastCat[(actor.DNA, target?.DNA)] = (cat, now + minSeparation);

        public void Set(Guid actor, Guid? target, BehaviorType type, WTimeSpan duration, WDateTime nowUtc)
        {
            _until[(actor, target, type)] = nowUtc + duration;
        }
    }
}
