﻿// Personality.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Homo
{
    using System;
    using System.Collections.Generic;
    using GameEngineTools.Characters.Homo;

    #region Enums & Records

    /// <summary>
    /// Pět základních faktorů osobnosti (Big Five)
    /// </summary>
    public enum BigFiveTrait
    {
        Openness,
        Conscientiousness,
        Extraversion,
        Agreeableness,
        Neuroticism
    }

    /// <summary>
    /// Jakým stylem se postava rozhoduje
    /// </summary>
    public enum DecisionStyle
    {
        Analytical,
        Intuitive,
        Impulsive,
        Balanced,
        Reflective,
        Deliberate
    }

    /// <summary>
    /// Rozdělení
    /// </summary>
    public enum ElementalPersonalityType
    {
        Fire,
        Water,
        Earth,
        Air
    }

    /// <summary>
    /// Dimenze morálních hodnot podle teorie „Moral Foundations“ (Haidt et al.)
    /// </summary>
    public enum MoralDimension
    {
        Care,        // soucit vs. ubližování
        Fairness,    // spravedlnost vs. podvádění
        Loyalty,     // loajalita vs. zrada
        Authority,   // respekt vs. podkopávání autorit
        Sanctity,     // čistota vs. degradace (‚Purity‘)
        Liberty,     // svoboda vs. útlak
        Honesty      // čestnost vs. klam
    }

    /// <summary>
    /// Kombinovatelné charakterové rysy postavy (bit‑flag enumerace)
    /// </summary>
    [Flags]
    public enum PersonalityTrait
    {
        None = 0,
        Brave = 1 << 0,
        Greedy = 1 << 1,
        Curious = 1 << 2,
        Paranoid = 1 << 3,
        Loyal = 1 << 4,
        Lazy = 1 << 5,
        Kind = 1 << 6,
        Bold = 1 << 7,
        Impulsive = 1 << 8,
        Empathetic = 1 << 9,
        Introspective = 1 << 10,
        Steady = 1 << 11,
        Practical = 1 << 12,
        Inquisitive = 1 << 13,
        Idealistic = 1 << 14,
        Aesthetic = 1 << 15
    }

    /// <summary>
    /// Klasické temperamentové typy
    /// </summary>
    public enum TemperamentType
    {
        Sanguine,
        Choleric,
        Phlegmatic,
        Melancholic,
        Mixed
    }

    /// <summary>
    /// Kvantitativní profil morálních hodnot (0‒1 pro každou dimenzi)
    /// </summary>
    public class MoralProfile
    {
        public MoralProfile()
        {
            Scores = new Dictionary<MoralDimension, double>();
            foreach (MoralDimension dim in Enum.GetValues(typeof(MoralDimension)))
            {
                Scores[dim] = 0.5; // neutrální střed
            }
        }

        /// <summary>
        /// Mapa &lt;dimenze, hodnota 0‒1&gt;
        /// </summary>
        public Dictionary<MoralDimension, double> Scores { get; }

        public double this[MoralDimension dim]
        {
            get => Scores[dim];
            set => Scores[dim] = Math.Clamp(value, 0.0, 1.0);
        }
    }

    // Jednoduché record‑typy pro rozšiřitelnost
    public record CoreValue(string Name, string? Description = null);

    public record Goal(string Name, string? Description = null, double Priority = 0.5);

    public record Experience(string Name, string? Description = null);

    public record Fear(string Name, string? Description = null);

    public record Hobby(string Name, string? Description = null);

    #endregion Enums & Records

    #region Personality class

    /// <summary>
    /// Dlouhodobá osobnost postavy – doplňuje <see cref="HumanPsychology"/> (krátkodobé nálady).
    /// </summary>
    public class Personality
    {
        public Personality()
        {
            // Big‑Five začíná na neutrálních hodnotách 0.5
            BigFive = new Dictionary<BigFiveTrait, double>
            {
                { BigFiveTrait.Openness, 0.5 },
                { BigFiveTrait.Conscientiousness, 0.5 },
                { BigFiveTrait.Extraversion, 0.5 },
                { BigFiveTrait.Agreeableness, 0.5 },
                { BigFiveTrait.Neuroticism, 0.5 }
            };

            Traits = new HashSet<PersonalityTrait>();
            Values = new List<CoreValue>();
            Fears = new List<Fear>();
            Hobbies = new List<Hobby>();
            Experiences = new List<Experience>();

            Temperament = TemperamentType.Sanguine;
            Morality = new MoralProfile();
            DecisionStyle = DecisionStyle.Balanced;
        }

        #region Properties

        public Dictionary<BigFiveTrait, double> BigFive { get; }

        public DecisionStyle DecisionStyle { get; set; }
        public List<Experience> Experiences { get; }
        public List<Fear> Fears { get; }
        public List<Hobby> Hobbies { get; }

        /// <summary>
        /// Kvantitativní morální profil postavy
        /// </summary>
        public MoralProfile Morality { get; }

        public Goal? PrimaryGoal { get; set; }
        public TemperamentType Temperament { get; set; }
        public HashSet<PersonalityTrait> Traits { get; }

        public List<CoreValue> Values { get; }

        #endregion Properties

        #region Events

        public event EventHandler<TraitChangedEventArgs>? TraitChanged;

        #endregion Events

        #region Methods

        protected virtual void OnTraitChanged(PersonalityTrait trait)
        {
            TraitChanged?.Invoke(this, new TraitChangedEventArgs { Trait = trait });
        }

        internal double GetBigFiveTrait(BigFiveTrait trait)
        {
            return BigFive[trait];
        }

        public void AdjustTrait(PersonalityTrait trait, bool add = true)
        {
            bool changed = add ? Traits.Add(trait) : Traits.Remove(trait);
            if (changed)
            {
                OnTraitChanged(trait);
            }
        }

        public void ApplyExperience(Experience exp)
        {
            Experiences.Add(exp);
            // TODO: upravit Big‑Five/Trait/Morality na základě zkušenosti
        }

        #endregion Methods

        public class TraitChangedEventArgs : EventArgs
        {
            public PersonalityTrait Trait { get; set; }
        }

        #endregion Personality class
    }
}
