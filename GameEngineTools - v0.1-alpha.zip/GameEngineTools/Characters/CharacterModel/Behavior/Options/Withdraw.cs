﻿// Withdraw.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    /// <summary>
    /// Úhyb – nic do vztahů neposílá (nepřímé dopady můžeš později řešit přes „IndirectInteraction“).
    /// </summary>
    public sealed class Withdraw : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.Withdraw;

        public void Apply(in BehaviorContext ctx)
        {
            // žádný InteractionEvent
            // můžeš si tady zvednout/ponížit trochu psychiku přes Appraise/Remember, pokud chceš
        }

        public bool IsApplicable(in BehaviorContext ctx) => true;

        public float Utility(in BehaviorContext ctx)
        {
            var psy = ctx.Actor.Psychology;
            // Úhyb se preferuje při vyšší únavě, stresu, úzkosti a nízké extraverzi
            var bf = ctx.Actor.Personality;
            double E = bf.BigFive[Homo.BigFiveTrait.Extraversion];

            double u = 0.15 + 0.35 * psy.Anxiety + 0.25 * psy.StressLevel + 0.20 * psy.Fatigue - 0.30 * E;
            return Bx.Clamp01(u);
        }
    }
}
