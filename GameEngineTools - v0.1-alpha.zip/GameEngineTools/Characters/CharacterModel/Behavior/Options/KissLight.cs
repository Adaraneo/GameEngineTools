﻿// KissLight.cs
// Copyright (c) 50PSoftware

using GameEngineTools.Characters.CharacterModel.Homo;
using GameEngineTools.Characters.CharacterModel.Relationships;

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    /// Krátké, jemné políbení – mikro fyzická eskalace.
    /// Bez úprav Relationships: používá InteractionType.Flirt (nebo Kiss, pokud existuje).
    public sealed class KissLight : IBehaviorOption
    {
        // Sdílí cooldown s lehkým flirtem
        public BehaviorType Type => BehaviorType.KissLight;

        public void Apply(in BehaviorContext ctx)
        {
            // Pokud nemáš InteractionType.Kiss, použij Flirt a vytáhni "kiss" kontextem (Physicality/Warmth/Depth).
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.Flirt, // nebo InteractionType.Kiss, pokud ho máš
                When = ctx.When,
                IsMicro = true,
                Context = new InteractionContext
                {
                    Privacy = Math.Max(ctx.Ix.Privacy, 0.45f),
                    SocialAudience = 0.0f,
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.06f, 0f, 1f),
                    Warmth = Math.Clamp(ctx.Ix.Warmth + 0.12f, 0f, 1f),
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.12f, -1f, 1f),
                    Physicality = Math.Clamp(ctx.Ix.Physicality + 0.20f, 0f, 1f),
                    Risk = Math.Clamp(ctx.Ix.Risk + 0.03f, 0f, 1f),
                    SharedGoal = Math.Clamp(ctx.Ix.SharedGoal + 0.06f, 0f, 1f),
                    Continuity = Math.Clamp(ctx.Ix.Continuity + 0.08f, 0f, 1f),
                    Surprise = Math.Clamp(ctx.Ix.Surprise + 0.04f, 0f, 1f)
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
        {
            if (ctx.Target is null || !ctx.Rel.HasValue) return false;
            var r = ctx.Rel.Value;

            bool stageOk = r.Stage >= BondStage.Friend;
            bool trustOk = r.Trust >= 50f;
            bool attractOk = r.Attraction >= 55f;
            bool privacyOk = ctx.Ix.Privacy >= 0.40f && ctx.Ix.SocialAudience <= 0.20f;
            bool toneOk = ctx.Ix.EmotionalTone >= 0.00f;          // ne u negativního tónu
            bool arousalOk = ctx.Actor.Psychology.Arousal >= 0.25f;  // lehká připravenost

            return stageOk && trustOk && attractOk && privacyOk && toneOk && arousalOk;
        }

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality;
            var psy = ctx.Actor.Psychology;
            var r = ctx.Rel!.Value;

            double E = per.BigFive[BigFiveTrait.Extraversion];

            double u =
                0.08
              + 0.24 * E
              + 0.20 * (r.Attraction / 100.0)
              + 0.15 * (r.Closeness / 100.0)
              + 0.10 * ctx.Ix.Privacy
              + 0.10 * psy.Arousal
              + 0.08 * (0.5 + 0.5 * psy.Mood)
              - 0.08 * psy.StressLevel
              - 0.06 * psy.Fatigue;

            return Bx.Clamp01(u);
        }
    }
}
