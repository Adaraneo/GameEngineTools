﻿// SelfDisclosureDeep.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    using GameEngineTools.Characters.CharacterModel.Relationships;

    public sealed class SelfDisclosureDeep : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.SelfDisclosureDeep;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = Relationships.InteractionType.Talk,
                When = ctx.When,
                IsMicro = false,
                Context = ctx.Ix
                    .WithDepth(Math.Max(ctx.Ix.Depth, 0.70f))
                    .WithSincerity(Math.Max(ctx.Ix.Sincerity, 0.70f))
                    .WithPrivacy(Math.Max(ctx.Ix.Privacy, 0.60f))
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx)
            => ctx.Target is not null
               && (ctx.Rel?.Trust ?? 0f) >= 35f
               && ctx.Ix.Privacy >= 0.60f;

        public float Utility(in BehaviorContext ctx)
        {
            var p = ctx.Actor.Personality.BigFive;
            var N = (float)p[Homo.BigFiveTrait.Neuroticism];
            var O = (float)p[Homo.BigFiveTrait.Openness];
            var mood01 = 0.5f + 0.5f * ctx.Actor.Psychology.Mood;
            var trust01 = (ctx.Rel?.Trust ?? 0f) / 100f;

            var u =
                0.08f + 0.30f * trust01 + 0.18f * mood01 + 0.20f * O - 0.12f * N
                - 0.20f * (1f - ctx.Ix.Privacy)
                - 0.10f * ctx.Actor.Psychology.StressLevel;

            return Bx.Clamp01(u);
        }
    }
}

