﻿// InviteSharedActivity.cs
// Copyright (c) 50PSoftware

using GameEngineTools.Characters.CharacterModel.Homo;
using GameEngineTools.Characters.CharacterModel.Relationships;

namespace GameEngineTools.Characters.CharacterModel.Behavior.Options
{
    /// Pozvání na drobnou společnou činnost (protiklad pasivního tlachání).
    public sealed class InviteSharedActivity : IBehaviorOption
    {
        public BehaviorType Type => BehaviorType.SuggestSharedActivity;

        public void Apply(in BehaviorContext ctx)
        {
            var ev = new InteractionEvent
            {
                From = ctx.Actor,
                To = ctx.Target!,
                Type = InteractionType.SpendTime,
                When = ctx.When,
                IsMicro = false,
                Context = new InteractionContext
                {
                    Privacy = ctx.Ix.Privacy,
                    Risk = Math.Max(0f, ctx.Ix.Risk - 0.05f),
                    SharedGoal = Math.Clamp(ctx.Ix.SharedGoal + 0.35f, 0f, 1f),
                    SocialAudience = ctx.Ix.SocialAudience,
                    Continuity = Math.Clamp(ctx.Ix.Continuity + 0.15f, 0f, 1f),
                    Depth = Math.Clamp(ctx.Ix.Depth + 0.10f, 0f, 1f),
                    EmotionalTone = Math.Clamp(ctx.Ix.EmotionalTone + 0.10f, -1f, 1f),
                    Warmth = Math.Clamp(ctx.Ix.Warmth + 0.10f, 0f, 1f)
                }
            };
            ctx.Sink.Enqueue(ev);
        }

        public bool IsApplicable(in BehaviorContext ctx) => ctx.Target is not null;

        public float Utility(in BehaviorContext ctx)
        {
            var per = ctx.Actor.Personality; var psy = ctx.Actor.Psychology;
            double E = per.BigFive[BigFiveTrait.Extraversion];
            double C = per.BigFive[BigFiveTrait.Conscientiousness];
            double u = 0.10 + 0.25 * E + 0.20 * C + 0.20 * (1 - ctx.Ix.SocialAudience)
                       + 0.10 * ctx.Goals.AffiliationNeed01 - 0.10 * psy.Fatigue;
            return Bx.Clamp01(u);
        }
    }
}
