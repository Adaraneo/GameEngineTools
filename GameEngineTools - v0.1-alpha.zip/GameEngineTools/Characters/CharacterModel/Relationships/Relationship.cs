﻿// Relationship.cs
// Copyright (c) 50PSoftware

#nullable enable

using System;
using System.Collections.Generic;
using GameEngineTools;
using GameEngineTools.Characters.CharacterModel.Homo;
using GameEngineTools.Characters.Homo;
using GameEngineTools.Characters.CharacterModel.Relationships.Memory;
using GameEngineTools.World.Utils.Time;
using static GameEngineTools.Characters.CharacterModel.Relationships.RelationshipMath;
using GameEngineTools.World.Core.Time;

namespace GameEngineTools.Characters.CharacterModel.Relationships
{
    /// <summary>
    /// Typy interakcí – držíme je zde (stejně jako dřív), protože po nich sahají další vrstvy.
    /// </summary>
    public enum InteractionType
    {
        None = 0,
        Help,
        Gift,
        Honesty,
        Cooperation,
        Betrayal,
        Insult,
        Lie,
        Aggression,
        Compliment,
        Flirt,
        SpendTime,
        Apology,
        SharedActivity,
        Conversation,
        SmallTalk,
        Sex,
        Attack,
        Encourage,
        Generic,
        Talk,
        Kiss,
        PrayTogether,
        Touch,
        MakeAmends,
        Aftercare,
        SingTogether,
        Argument,
        Breach,
        NoShow
    }

    /// <summary>
    /// Směrový vztah A→B (From→To). Tenký orchestrátor, veškerá těžká matematika je v RelationshipTools.cs.
    /// </summary>
    public sealed class Relationship
    {
        // ─────────────────────────────────────────────
        // Tunables (realističnost/„feel“)
        // ─────────────────────────────────────────────
        private const float MAX_PER_DAY_L = 6f, MAX_PER_DAY_T = 4f, MAX_PER_DAY_A = 5f, MAX_PER_DAY_C = 7f;
        private const float EMA_LIKE = 0.60f, EMA_TRUST = 0.18f, EMA_ATTR = 0.35f, EMA_CLOSE = 0.40f;
        private const float JITTER_AMPL = 0.12f;         // ±6 %
        private const float CONSENT_MIN = 0.30f, CONSENT_MAX = 1.10f;
        private const float CAPACITY_MIN = 0.30f, CAPACITY_MAX = 1.10f;
        private const int NOVELTY_WINDOW_DAYS = 7;

        // ─────────────────────────────────────────────
        // Stav
        // ─────────────────────────────────────────────
        public IHuman From { get; }
        public IHuman To { get; }

        // Osy (0..100; min/max dynamické)
        public float Liking { get; private set; }
        public float Trust { get; private set; }
        public float Attraction { get; private set; }
        public float Closeness { get; private set; }

        public float MaxLiking { get; private set; } = 100f;
        public float MinLiking { get; private set; } = -100f;
        public float MaxTrust { get; private set; } = 100f;
        public float MinTrust { get; private set; } = -100f;
        public float MaxAttraction { get; private set; } = 100f;
        public float MinAttraction { get; private set; } = 0f;
        public float MaxCloseness { get; private set; } = 100f;
        public float MinCloseness { get; private set; } = -100f;

        // EMA + „zobrazené“ hodnoty (měkké dno)
        public float TrustEma { get; private set; }
        public float LikingEma { get; private set; }
        public float ClosenessEma { get; private set; }
        public float AttractionEma { get; private set; }

        public float TrustDisplayed => SoftFloor(Trust, MinTrust, softness: 20f);
        public float LikingDisplayed => SoftFloor(Liking, MinLiking, softness: 20f);
        public float ClosenessDisplayed => SoftFloor(Closeness, MinCloseness, softness: 20f);
        public float AttractionDisplayed => SoftFloor(Attraction, MinAttraction, softness: 15f);

        // Biasy (0..1; drž střed 0.5)
        public double LikeBias { get; set; } = 0.5;
        public double TrustBias { get; set; } = 0.5;
        public double AttractionBias { get; set; } = 0.5;
        public double ClosenessBias { get; set; } = 0.5;

        // Globální koeficienty
        public float Compatibility { get; private set; } = 0.5f;     // 0..1
        public float PhysicalAffinity { get; private set; } = 0.5f;  // 0..1 (párová fyz. afinita)
        public float Friction { get; private set; } = 1.0f;          // ~0.6..1.4 – tlumí růst
        public float SecurityBuffer { get; private set; } = 20f;     // pohlcovač čerstvých šrámů

        // Etikety
        public BondKind Kind { get; private set; } = BondKind.Neutral;
        public BondStage Stage { get; private set; } = BondStage.Stranger;
        public BondTag Tags { get; private set; } = BondTag.None;
        public KinshipRole Kinship { get; private set; } = KinshipRole.Unknown;

        // Čas
        public WDateTime? TrustLockoutUntil { get; private set; }
        public WDateTime LastInteraction { get; private set; }
        public WDateTime LastUpdate { get; private set; }
        public float HoursTogetherToday { get; private set; }

        // Doplňky
        private readonly RollingCounter<InteractionType> _recent = new(NOVELTY_WINDOW_DAYS);
        private readonly ReciprocityLedger _reciprocity = new(14);
        private readonly IEpisodicMemory _memory = new RingEpisodicMemory();
        public IEpisodicMemory Memory => _memory;
        public Repair.RepairAccount Repair { get; } = new();
        public float StageHoldDays { get; internal set; }

        private RelationshipMath.TwoTrace _likeFastSlow, _trustFastSlow, _closeFastSlow;

        // ─────────────────────────────────────────────
        // Konstrukce
        // ─────────────────────────────────────────────
        public Relationship(IHuman from, IHuman to)
        {
            From = from ?? throw new ArgumentNullException(nameof(from));
            To = to ?? throw new ArgumentNullException(nameof(to));
            InitializeCompatibility(from, to);
            RecalculateCaps();
        }

        // ─────────────────────────────────────────────
        // Veřejné utility
        // ─────────────────────────────────────────────

        public void SetStage(BondStage s) => Stage = s;
        public void SetHoursTogether(float hours) => HoursTogetherToday = MathF.Max(0f, hours);

        public void SetLiking(float v) => Liking = Clamp(v, MinLiking, MaxLiking);
        public void SetTrust(float v) => Trust = Clamp(v, MinTrust, MaxTrust);
        public void SetCloseness(float v) => Closeness = Clamp(v, MinCloseness, MaxCloseness);
        public void SetAttraction(float v) => Attraction = Clamp(v, MinAttraction, MaxAttraction);

        public RelationshipModel GetModel() => new()
        {
            Kind = Kind,
            KinshipRole = Kinship,
            Stage = Stage,
            Tags = Tags,
            LastInteraction = LastInteraction,
            LastUpdate = LastUpdate,

            Liking = Liking,
            Trust = Trust,
            Attraction = Attraction,
            Closeness = Closeness,

            MinLiking = MinLiking,
            MaxLiking = MaxLiking,
            MinTrust = MinTrust,
            MaxTrust = MaxTrust,
            MinCloseness = MinCloseness,
            MaxCloseness = MaxCloseness,
            MinAttraction = MinAttraction,
            MaxAttraction = MaxAttraction,

            SecurityBuffer = SecurityBuffer,
            Friction = Friction,
            Compatibility = Compatibility,
            PhysicalAffinity = PhysicalAffinity,

            LikeBias = LikeBias,
            TrustBias = TrustBias,
            AttractionBias = AttractionBias,
            ClosenessBias = ClosenessBias,
            TrustLockoutUntil = TrustLockoutUntil
        };

        /// <summary>EMA (zobrazovací) – dělej jednou denně nebo po větším updatu.</summary>
        public void UpdateEma(float holdDays = 7f)
        {
            TrustEma = EmaStep(TrustEma, TrustDisplayed, holdDays);
            LikingEma = EmaStep(LikingEma, LikingDisplayed, holdDays);
            ClosenessEma = EmaStep(ClosenessEma, ClosenessDisplayed, holdDays);
            AttractionEma = EmaStep(AttractionEma, AttractionDisplayed, holdDays);
        }

        /// <summary>
        /// Pomalu rozpouští osy v čase (při absenci interakcí); drží se tvých utilit.
        /// </summary>
        public void DecayAxes(IClock clock, WTimeSpan deltaTime)
        {
            if (deltaTime.TotalDays <= 0) return;

            var dt = (float)deltaTime.TotalDays;
            // dynamická lambda podle BigFive/psychiky (už hotové v RelationshipTools – použijeme „lite“ mix zde)
            (float l, float t, float c, float a) = GetDecayLambdasPerDays();
            Liking = Clamp(RelationshipMath.DecayLambda(Liking, l, dt), MinLiking, MaxLiking);
            Trust = Clamp(RelationshipMath.DecayLambda(Trust, t, dt), MinTrust, MaxTrust);
            Closeness = Clamp(RelationshipMath.DecayLambda(Closeness, c, dt), MinCloseness, MaxCloseness);
            Attraction = Clamp(RelationshipMath.DecayLambda(Attraction, a, dt), MinAttraction, MaxAttraction);

            // TwoTrace pomalu dotuje osy
            _likeFastSlow.Decay(dt, hlFast: 4.3f, hlSlow: 120f);
            _trustFastSlow.Decay(dt, hlFast: 4.3f, hlSlow: 120f);
            _closeFastSlow.Decay(dt, hlFast: 4.3f, hlSlow: 120f);

            var leak = 0.10f;
            AddLiking(leak * _likeFastSlow.Value(0));
            AddTrust(leak * _trustFastSlow.Value(0));
            AddCloseness(leak * _closeFastSlow.Value(0));

            // Bezpečnostní polštář se obnovuje
            SecurityBuffer = MathF.Min(SecurityBuffer + 0.5f + 0.02f * Trust, 30f);

            // Strávený čas ➜ closeness přes saturující křivku, jednou denně
            if (HoursTogetherToday > 1e-3f)
            {
                float dC = SpendTimeDelta(HoursTogetherToday, k: 0.9f, maxEff: 4f, hardCapH: 6f);
                AddCloseness(dC);
                HoursTogetherToday = 0f;
            }

            LastUpdate = clock.Now;
        }

        /// <summary>
        /// Jediný „gate“ pro aplikaci interakcí. Mapuje se na RelationshipManager.ApplyInteraction* a Behavior layer.
        /// </summary>
        internal void ApplyInteraction(IClock clock, InteractionType interaction, float magnitude = 1f, InteractionContext? interactionContext = null)
        {
            var now = clock.Now;
            var ix = interactionContext ?? default;

            // 0) Lockout (např. po útoku) – pokud běží, ignoruj kladné T
            bool trustLockedOut = TrustLockoutUntil.HasValue && now < TrustLockoutUntil.Value;

            // 1) Základní delty (bez kontextu)
            float dL = 0f, dT = 0f, dA = 0f, dC = 0f;
            (dL, dT, dA, dC) = BaseDeltas(interaction);

            // 2) Kontext – InteractionContextMath.Apply(...) z RelationshipTools (už je připravené na tvůj model)
            InteractionContextMath.Apply(ref dL, ref dT, ref dA, ref dC, ix, this);

            // 3) Stage/novelty + mikro-fit + deterministický jitter
            int stageLevel = Stage switch { BondStage.Stranger => 0, BondStage.Familiar => 1, BondStage.Friend => 2, BondStage.Intimate => 3, _ => 1 };
            float stageGain = StageGainFactor(stageLevel);
            int repeats = _recent.Count(interaction, now); // za okno 7 dní
            float novelty = NoveltyFactor(repeats);
            float moralFit = MoralAlignmentFactor(From, To); // 0..1
            float fitMacro = 0.85f + 0.30f * (0.60f * Compatibility + 0.40f * moralFit); // ~0.85..1.15

            // hormonální/cyklický multiplikátor u cíle
            float cycleMul = CycleRelMultiplier(To, interaction);

            // deterministický jitter
            int seed = Hash(now, From, To, interaction);
            float jitter = 1f + Jitter(new Random(seed), amplitude: JITTER_AMPL);

            float gain = MathF.Max(0.1f, MathF.Abs(magnitude)) * stageGain * novelty * fitMacro * jitter * cycleMul;

            // 4) Percepce (např. doteky při nízkém trustu)
            if (IsPhysical(interaction))
            {
                var t01 = MaxTrust > 0 ? Math.Clamp(Trust / MaxTrust, 0f, 1f) : 0f;
                float k = Lerp(0.5f, 1.0f, t01 / 0.4f);
                if (t01 < 0.4f) { dA *= k; dC *= k; }
            }

            // 5) Consent/Capacity gate (měkké prahy; pokud ix nepřenáší consent, nech 0.5)
            float consent = IsPhysical(interaction) ? ComputeConsentAuto(ix, this) : 1f;
            float capacity = Math.Clamp(CapacityOf(To), CAPACITY_MIN, CAPACITY_MAX);
            float gate = consent * capacity;

            // 6) Aplikuj gain a gate
            dL *= gain * gate;
            dT *= gain * gate;
            dA *= gain * gate;
            dC *= gain * gate;

            // 7) Paměťová rezonance (jemná modulace) + Reciprocity
            var tags = MapThemeTags(interaction, in ix);
            float valence = Math.Clamp(ix.EmotionalTone, -1f, 1f);
            float intimacy = Math.Clamp(0.5f * ix.Depth + 0.5f * (1f - ix.Privacy), 0f, 1f);
            float resonance = _memory.ResonanceScore(tags, valence, intimacy);
            dT *= 1f + 0.25f * resonance;
            dC *= 1f + 0.35f * resonance;
            dA *= 1f + 0.15f * resonance;

            // reciprocity: posiluj prosociální, tlum jiné
            float reci = (interaction is InteractionType.Help or InteractionType.Cooperation) ? _reciprocity.Boost(now) : 1f;
            dL *= reci; dT *= reci; dC *= reci;

            // 8) Lockout na trust (jen tlum kladné T, negativní vždy projde)
            if (trustLockedOut && dT > 0) dT = 0;

            //if (interaction is InteractionType.Attack or InteractionType.Aggression or InteractionType.Betrayal)
            //{
            //    TrustLockoutUntil = clock.Now + WTimeSpan.FromDays(3);
            //}

            // 9) Denní limity + měkké stropy pro Attraction
            dL = Math.Clamp(dL, -MAX_PER_DAY_L, +MAX_PER_DAY_L);
            dT = Math.Clamp(dT, -MAX_PER_DAY_T, +MAX_PER_DAY_T);
            dA = Math.Clamp(dA, -MAX_PER_DAY_A, +MAX_PER_DAY_A);
            dC = Math.Clamp(dC, -MAX_PER_DAY_C, +MAX_PER_DAY_C);

            float comfort01 = 0.5f + 0.5f * (MaxCloseness > 0 ? Closeness / MaxCloseness : 0f);
            float stageCeil = Stage switch { BondStage.Stranger => 0.40f, BondStage.Familiar => 0.65f, BondStage.Friend => 0.85f, BondStage.Intimate => 1.00f, _ => 0.75f };
            float aCeil = MathF.Min(stageCeil, 0.5f + 0.5f * comfort01);
            float aNorm = MaxAttraction > 0 ? Attraction / MaxAttraction : 0f;
            float head = MathF.Max(0f, aCeil - aNorm);
            dA *= 0.5f + 0.5f * head / MathF.Max(1e-3f, aCeil);

            // 10) Aplikace do os + bezpečnostní buffer + tření
            // fast/slow otisk (pro pozdější „přítok“)
            _likeFastSlow.Kick(dL, 0.5f);
            _trustFastSlow.Kick(dT, 0.5f);
            _closeFastSlow.Kick(dC, 0.5f);

            AddLiking(dL * EMA_LIKE);
            AddTrust(dT * EMA_TRUST);
            AddAttraction(dA * EMA_ATTR);
            AddCloseness(dC * EMA_CLOSE);

            // Repair/Rupture účet
            var sincerity = ComputeSincerityAuto(ix, From, this);
            ApplyRepairRupture(interaction, sincerity: sincerity);

            // Logging do paměti (epizoda)
            _memory.Add(new Episode
            {
                ActorId = From.Body.DNA,
                TargetId = To.Body.DNA,
                When = now,
                Valence = valence,
                Intimacy = intimacy,
                Surprise = ix.Surprise,
                Tags = new HashSet<ThemeTag>(tags)
            });

            // housekeeping
            LastInteraction = now;
            LastUpdate = now;
            _recent.Note(interaction, now);
        }

        private void InitializeCompatibility(IHuman a, IHuman b)
        {
            // BigFive + morálka → podobnost
            var big = CalculateCompatibility(a, b);
            var moral = MoralAlignmentFactor(a, b);
            Compatibility = Math.Clamp(0.7f * big + 0.3f * (float)moral, 0f, 1f);

            // Fyzická afinita (párové – BMI/obecné vitály – drž při zemi)
            PhysicalAffinity = PairPhysicalAffinity(a, b);

            // tření a bezpečnostní polštář
            Friction = 0.6f + (1f - Compatibility) * 0.6f;
            SecurityBuffer = 30f - (1f - Compatibility) * 25f;

            RecalculateCaps();
        }

        public void RecalculateCaps()
        {
            MaxLiking = 70f + 30f * Compatibility;
            MaxTrust = 60f + 40f * Compatibility;
            MaxCloseness = 40f + 60f * Compatibility;

            var attractBase = 50f + 50f * (0.75f * Compatibility + 0.25f * PhysicalAffinity);
            MaxAttraction = MathF.Min(100f, attractBase);

            MinLiking = -30f - 40f * (1f - Compatibility);
            MinTrust = -20f - 80f * (1f - Compatibility);
            MinCloseness = -10f - 50f * (1f - Compatibility);
            MinAttraction = 0f;
        }

        private static bool IsPhysical(InteractionType t)
            => t is InteractionType.Touch or InteractionType.Kiss or InteractionType.Sex;

        private long _lastSeedTick;
        private int _tickNonce;
        private WDateTime? _partnerSince;

        private int NextNonce(WDateTime now)
        {
            if (now.Ticks != _lastSeedTick)
            {
                _lastSeedTick = now.Ticks;
                _tickNonce = 0;
            }
            return _tickNonce++;
        }

        private static float CapacityOf(IHuman target)
        {
            var energy = (float)(target.Psychology?.SocialDrive ?? 0.5); // místo SocialEnergy01
            var stress = (float)(target.Psychology?.StressLevel ?? 0.3);
            return Math.Clamp(energy * (1f - 0.5f * stress), CAPACITY_MIN, CAPACITY_MAX);
        }

        private int Hash(WDateTime now, IHuman a, IHuman b, InteractionType t)
        {
            var nonce = NextNonce(now); // rozlišení víc interakcí ve stejném čase
            var key = $"{a.Body.DNA}|{b.Body.DNA}|{now.Ticks}|{(int)t}|{nonce}";
            return Fnv1a32(key);
        }

        private static int Fnv1a32(string s)
        {
            unchecked
            {
                const uint P = 16777619u;
                uint h = 2166136261u;
                foreach (var ch in s)
                {
                    h ^= ch;
                    h *= P;
                }
                return (int)h;
            }
        }

        private static ThemeTag[] MapThemeTags(InteractionType type, in InteractionContext ix) => type switch
        {
            InteractionType.Compliment => new[] { ThemeTag.Humor },
            InteractionType.Apology or InteractionType.MakeAmends or InteractionType.Aftercare => new[] { ThemeTag.Care, ThemeTag.Vulnerability },
            InteractionType.Kiss or InteractionType.Touch => new[] { ThemeTag.Touch },
            InteractionType.PrayTogether => new[] { ThemeTag.Faith },
            InteractionType.SingTogether => new[] { ThemeTag.Music },
            InteractionType.Argument or InteractionType.Breach or InteractionType.Aggression or InteractionType.Attack => new[] { ThemeTag.Conflict },
            _ => Array.Empty<ThemeTag>()
        };

        private static (float dL, float dT, float dA, float dC) BaseDeltas(InteractionType type) => type switch
        {
            // prosociální
            InteractionType.Help => (+0.50f, +0.70f, +0.10f, +0.40f),
            InteractionType.Gift => (+0.35f, +0.10f, +0.25f, +0.25f),
            InteractionType.Honesty => (+0.10f, +0.60f, +0.00f, +0.20f),
            InteractionType.Cooperation => (+0.30f, +0.55f, +0.10f, +0.45f),
            InteractionType.Encourage => (+0.40f, +0.30f, +0.10f, +0.40f),

            InteractionType.SpendTime => (+0.20f, +0.10f, +0.10f, +0.35f),
            InteractionType.SharedActivity => (+0.30f, +0.25f, +0.10f, +0.45f),
            InteractionType.Conversation => (+0.25f, +0.15f, +0.10f, +0.30f),
            InteractionType.SmallTalk => (+0.10f, +0.05f, +0.05f, +0.15f),
            InteractionType.Talk => (+0.15f, +0.10f, +0.05f, +0.20f),

            // romance/fyzické
            InteractionType.Compliment => (+0.45f, +0.10f, +0.30f, +0.15f),
            InteractionType.Flirt => (+0.20f, +0.00f, +0.70f, +0.20f),
            InteractionType.Touch => (+0.10f, +0.00f, +0.80f, +0.50f),
            InteractionType.Kiss => (+0.25f, +0.15f, +1.60f, +0.80f),
            InteractionType.Sex => (+0.30f, +0.20f, +2.50f, +1.20f),

            // repair
            InteractionType.Apology => (+0.15f, +0.60f, -0.05f, +0.15f),
            InteractionType.MakeAmends => (+0.20f, +0.70f, -0.05f, +0.20f),
            InteractionType.Aftercare => (+0.30f, +0.30f, +0.10f, +0.60f),

            // negatives
            InteractionType.Insult => (-0.60f, -0.40f, -0.20f, -0.30f),
            InteractionType.Aggression => (-1.00f, -1.00f, -0.40f, -0.60f),
            InteractionType.Attack => (-1.30f, -1.60f, -0.50f, -0.90f),
            InteractionType.Betrayal => (-0.80f, -1.40f, -0.30f, -0.60f),
            InteractionType.Lie => (-0.25f, -1.00f, -0.10f, -0.25f),
            InteractionType.Argument => (-0.20f, -0.30f, -0.10f, -0.30f),
            InteractionType.Breach => (-0.30f, -0.60f, -0.15f, -0.40f),
            InteractionType.NoShow => (-0.25f, -0.50f, -0.10f, -0.30f),

            _ => (+0.10f, +0.05f, +0.10f, +0.10f)
        };

        private void ApplyRepairRupture(InteractionType type, float sincerity)
        {
            switch (type)
            {
                case InteractionType.Argument: Repair.AddRupture(0.20f); break;
                case InteractionType.Breach: Repair.AddRupture(0.45f); break;
                case InteractionType.NoShow: Repair.AddRupture(0.30f); break;
                case InteractionType.Apology: Repair.ApplyRepair(sincerity, effort01: 0.6f); break;
                case InteractionType.MakeAmends: Repair.ApplyRepair(sincerity, effort01: 0.9f); break;
                case InteractionType.Aftercare: Repair.ApplyRepair(sincerity, effort01: 0.5f); break;
            }
        }

        private float PairPhysicalAffinity(IHuman a, IHuman b)
        {
            var pa = a.Body; var pb = b.Body;
            if (pa is null || pb is null) return 0.5f;

            // BMI podobnost (gauss kolem 0 rozdílu), plus lehký vliv výšky a vitality
            double bmiDiff = Math.Abs(pa.BMI - pb.BMI);
            double bmiAff = Math.Exp(-(bmiDiff * bmiDiff) / (2.0 * 9.0)); // σ≈3 BMI
            double vit = 0.5 * (pa.Vitals.Hydration + pb.Vitals.Hydration);
            return (float)Math.Clamp(0.4 + 0.4 * bmiAff + 0.2 * vit, 0.0, 1.0);
        }

        private float CycleRelMultiplier(IHuman target, InteractionType type)
        {
            var cy = target.Body?.Cycle;
            if (cy is null) return 1.0f;

            float m = 1.0f;
            if (cy.Phase == CyclePhase.PeriOvulatory)
            {
                if (type is InteractionType.Flirt or InteractionType.Kiss or InteractionType.Touch or InteractionType.Sex)
                    m *= 1.06f;
                if (type is InteractionType.Honesty or InteractionType.SpendTime or InteractionType.SharedActivity)
                    m *= 1.03f;
            }
            if (cy.Phase == CyclePhase.Menstruation)
            {
                if (type is InteractionType.Help or InteractionType.SpendTime or InteractionType.SharedActivity)
                    m *= 1.05f;
                if (type is InteractionType.Flirt)
                    m *= 0.97f;
            }
            return MathF.Min(1.15f, MathF.Max(0.85f, m));
        }

        private (float likeLam, float trustLam, float closeLam, float attrLam) GetDecayLambdasPerDays()
        {
            // BigFive cíle – drž zažitou logiku: A/C drží vztah, N zvyšuje volatilitu
            var bf = To.Personality.BigFive;
            float A = (float)bf[BigFiveTrait.Agreeableness];
            float Cc = (float)bf[BigFiveTrait.Conscientiousness];
            float E = (float)bf[BigFiveTrait.Extraversion];
            float N = (float)bf[BigFiveTrait.Neuroticism];
            float O = (float)bf[BigFiveTrait.Openness];

            float l = LambdaFromHalfLife(Lerp(50f, 25f, 0.5f * A + 0.3f * Cc)); // dny
            float t = LambdaFromHalfLife(Lerp(60f, 28f, 0.6f * Cc + 0.2f * A));
            float c = LambdaFromHalfLife(Lerp(55f, 30f, 0.5f * A + 0.2f * E + 0.2f * N));
            float a = LambdaFromHalfLife(Lerp(45f, 25f, 0.4f * O + 0.2f * N));

            float fr = Math.Clamp(Friction, 0.6f, 1.4f);
            l *= fr; t *= fr; c *= fr; a *= Lerp(1.0f, 1.15f, N);

            // Hranice sanity
            static float ClampLam(float x) => MathF.Min(0.030f, MathF.Max(0.002f, x));
            return (ClampLam(l), ClampLam(t), ClampLam(c), ClampLam(a));
        }

        private void AddLiking(float delta)
        {
            if (delta > 0 && Friction > 0f) delta /= MathF.Max(0.5f, Friction);
            Liking = Clamp(Liking + delta, MinLiking, MaxLiking);
        }

        private void AddTrust(float delta)
        {
            if (delta > 0 && Friction > 0f) delta /= MathF.Max(0.5f, Friction);
            if (delta < 0 && SecurityBuffer > 0f)
            {
                var absorbed = MathF.Min(-delta, SecurityBuffer);
                delta += absorbed;
                SecurityBuffer -= absorbed;
            }
            Trust = Clamp(Trust + delta, MinTrust, MaxTrust);
        }

        private void AddCloseness(float delta)
        {
            if (delta > 0 && Friction > 0f) delta /= MathF.Max(0.5f, Friction);
            if (delta < 0 && SecurityBuffer > 0f)
            {
                var absorbed = MathF.Min(-delta, SecurityBuffer);
                delta += absorbed;
                SecurityBuffer -= absorbed;
            }
            Closeness = Clamp(Closeness + delta, MinCloseness, MaxCloseness);
        }

        private void AddAttraction(float delta)
        {
            if (delta > 0 && Friction > 0f) delta /= MathF.Max(0.5f, Friction);
            Attraction = Clamp(Attraction + delta, MinAttraction, MaxAttraction);
        }

        internal void SetKinship(KinshipRole role)
        {
            Kinship = role;
        }

        internal void SetBiases(double likeBias, double trustBias, double attractionBias, double closenessBias)
        {
            LikeBias = Math.Clamp(likeBias, 0.0, 1.0);
            TrustBias = Math.Clamp(trustBias, 0.0, 1.0);
            AttractionBias = Math.Clamp(attractionBias, 0.0, 1.0);
            ClosenessBias = Math.Clamp(closenessBias, 0.0, 1.0);
        }

        internal void LoadFromModel(RelationshipModel relationshipModel)
        {
            if (relationshipModel == null) return;
            LikeBias = relationshipModel.LikeBias;
            TrustBias = relationshipModel.TrustBias;
            AttractionBias = relationshipModel.AttractionBias;
            ClosenessBias = relationshipModel.ClosenessBias;
            Kind = relationshipModel.Kind;
            Kinship = relationshipModel.KinshipRole;
            Stage = relationshipModel.Stage;
            Tags = relationshipModel.Tags;
            LastInteraction = relationshipModel.LastInteraction.GetValueOrDefault();
            LastUpdate = relationshipModel.LastUpdate;
            Liking = relationshipModel.Liking;
            Trust = relationshipModel.Trust;
            Attraction = relationshipModel.Attraction;
            Closeness = relationshipModel.Closeness;
            MinLiking = relationshipModel.MinLiking;
            MaxLiking = relationshipModel.MaxLiking;
            MinTrust = relationshipModel.MinTrust;
            MaxTrust = relationshipModel.MaxTrust;
            MinCloseness = relationshipModel.MinCloseness;
            MaxCloseness = relationshipModel.MaxCloseness;
            MinAttraction = relationshipModel.MinAttraction;
            MaxAttraction = relationshipModel.MaxAttraction;
            SecurityBuffer = relationshipModel.SecurityBuffer;
            Friction = relationshipModel.Friction;
            Compatibility = relationshipModel.Compatibility;
            PhysicalAffinity = relationshipModel.PhysicalAffinity;
            TrustLockoutUntil = relationshipModel.TrustLockoutUntil;
            RecalculateCaps();

            // EMA init
            TrustEma = TrustDisplayed;
            LikingEma = LikingDisplayed;
            ClosenessEma = ClosenessDisplayed;
            AttractionEma = AttractionDisplayed;
        }

        public void AddTags(BondTag tag)
        {
            Tags |= tag;
        }

        internal void SetKind(BondKind kind)
        {
            Kind = kind;
        }

        internal void RemoveTags(BondTag tag)
        {
            Tags &= ~tag;
        }

        internal void EvaluateStage(BondStageVector thresholds, float stageEmaDays)
        {
            if (thresholds?.Axes is null || thresholds.Axes.Count == 0)
                return;

            bool Has(BondStage s, out (float C, float L, float T, float? A) v)
            {
                if (thresholds.Axes.TryGetValue(s, out var t))
                {
                    v = (t.ClosenessMin, t.LikingMin, t.TrustMin, t.AttractionMin);
                    return true;
                }
                v = default;
                return false;
            }

            // EMA hodnoty os
            float c = ClosenessEma;
            float l = LikingEma;
            float t = TrustEma;
            float a = AttractionEma;

            // Gate pro jednotlivé cílové stage
            bool toFamiliar = Has(BondStage.Familiar, out var fam) && c >= fam.C && l >= fam.L && t >= fam.T;
            bool toFriend = Has(BondStage.Friend, out var fr) && c >= fr.C && l >= fr.L && t >= fr.T;
            bool toIntimate = Has(BondStage.Intimate, out var in_) && c >= in_.C && l >= in_.L && t >= in_.T && a >= in_.A;

            // hystereze – převod dnů na pásmo (4 dny → ±0.20)
            float band = Math.Clamp(stageEmaDays * 0.05f, 0.05f, 0.40f);

            bool wasFamiliar = Stage >= BondStage.Familiar;
            bool wasFriend = Stage >= BondStage.Friend;
            bool wasIntimate = Stage >= BondStage.Intimate;

            bool familiarOn = RelationshipMath.Hysteresis(wasFamiliar, toFamiliar ? 1f : 0f, 0.5f, band);
            bool friendOn = RelationshipMath.Hysteresis(wasFriend, toFriend ? 1f : 0f, 0.5f, band);
            bool intimateOn = RelationshipMath.Hysteresis(wasIntimate, toIntimate ? 1f : 0f, 0.5f, band);

            var target = BondStage.Stranger;
            if (familiarOn) target = BondStage.Familiar;
            if (friendOn) target = BondStage.Friend;
            if (intimateOn) target = BondStage.Intimate;

            if (target != Stage)
                SetStage(target);
        }
        internal void MarkPartnerAddedNow(IClock clock)
        {
            _partnerSince = clock?.Now ?? default;
        }

        internal bool CanLosePartnerTag(IClock clock, WTimeSpan partnerMinDuration)
        {
            // když nemám Partner, nic nedrží
            if ((Tags & BondTag.Partner) == 0)
                return true;

            if (_partnerSince is null)
                return false; // nevíme od kdy → raději nedovolit

            var now = clock?.Now ?? default;
            var held = now - _partnerSince.Value;
            return held >= partnerMinDuration;
        }


        internal void ClearPartnerSince()
        {
            _partnerSince = null;
        }
    }
}

