﻿// SocialWellbeingService.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Homo.Services
{
    using GameEngineTools.Characters.CharacterModel.Homo;
    using GameEngineTools.Characters.CharacterModel.Relationships;

    /// Výpočet sociální pohody z aktuálních vztahů.
    public sealed class SocialWellbeingService
    {
        private static double Clamp01(double v) => v < 0 ? 0 : v > 1 ? 1 : v;

        private static double Mix(double a, double b, double t) => a + (b - a) * Clamp01(t);

        // --- helpers ---
        private static double SafeNorm(double v, double max) => max <= 0 ? 0 : Clamp01(v / max);

        private static double Smooth(double x) => x * x * (3.0 - 2.0 * x);

        public (double social, double attachment, double loneliness)
                                            Compute(IHuman self, IEnumerable<Relationship> rels)
        {
            if (rels == null) return (0.35, 0.35, 0.65);

            double sum = 0, wsum = 0;

            foreach (var r in rels)
            {
                double cN = SafeNorm(r.Closeness, r.MaxCloseness);
                double lN = SafeNorm(r.Liking, r.MaxLiking);
                double tN = SafeNorm(r.Trust, r.MaxTrust);
                double aN = SafeNorm(r.Attraction, r.MaxAttraction);

                // Váha podle blízkosti (nejbližší vztahy víc ovlivní)
                double w = 0.2 + 0.8 * cN;

                // Základ: Trust nejvíc, pak Like/Closeness, Attraction jemně
                double unit = 0.30 * lN + 0.45 * tN + 0.10 * aN + 0.15 * cN;

                // Kompatibilita zjemňuje (zmenšuje volatilitu)
                unit = Mix(unit, Smooth(unit), 0.35 * r.Compatibility);

                sum += unit * w;
                wsum += w;
            }

            double social = wsum <= 0 ? 0.35 : Clamp01(sum / wsum);

            // AttachmentSecurity – bezpečí z TOP 2 blízkých vztahů
            double attach = rels
                .OrderByDescending(r => r.Closeness)
                .Take(2)
                .Select(r =>
                {
                    double t = SafeNorm(r.Trust, r.MaxTrust);
                    double c = SafeNorm(r.Closeness, r.MaxCloseness);
                    double shield = Clamp01(r.SecurityBuffer / 30.0); // rezilience
                    return Clamp01(0.6 * t + 0.4 * c + 0.1 * shield - 0.1 * (1.0 - r.Compatibility));
                })
                .DefaultIfEmpty(0.3)
                .Average();

            // Loneliness – „pokrytí“ blízkosti z TOP 3 vztahů
            double closenessCoverage = rels
                .Select(r => SafeNorm(r.Closeness, r.MaxCloseness))
                .OrderByDescending(x => x)
                .Take(3)
                .DefaultIfEmpty(0.0)
                .Average();

            double loneliness = Clamp01(1.0 - closenessCoverage);

            return (social, attach, loneliness);
        }
    }
}
