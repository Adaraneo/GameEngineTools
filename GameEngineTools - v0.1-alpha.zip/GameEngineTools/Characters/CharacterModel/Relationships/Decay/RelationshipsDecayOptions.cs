﻿// RelationshipsDecayOptions.cs
// Copyright (c) 50PSoftware

namespace GameEngineTools.Characters.CharacterModel.Relationships.Decay
{
    using GameEngineTools.World.Utils.Time;

    public sealed class RelationshipsDecayOptions
    {
        /// <summary>Jak často se má služba probudit.</summary>
        public WTimeSpan WakeInterval { get; set; } = WTimeSpan.FromMinutes(5);

        /// <summary>Jak velký Δt aplikovat na decay v jednom běhu.</summary>
        public WTimeSpan DecayStep { get; set; } = WTimeSpan.FromHours(1);

        /// <summary>Maximální „dohnání“ času po delší pauze (ochrana proti obřím skokům).</summary>
        public WTimeSpan MaxCatchUp { get; set; } = WTimeSpan.FromDays(2);
    }
}
